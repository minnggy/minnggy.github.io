# Movie Sequel Feature Engineering Specification v1.2

Status: **SPECIFICATION_REVIEW**  
Specification date: 2026-09-13  
Parent specification: `reports/movie_sequel_feature_engineering_spec_v1.1.md`  
Parent registry: `reports/movie_sequel_feature_registry_v1.1.csv`

## 1. Purpose

This document governs feature eligibility and future deterministic feature construction. It separates retrospective association from prediction at a defined pre-release cutoff. It does not construct a feature dataset, modify source data, run EDA, or train a model.

The governing principle is not to maximize feature count. Every candidate must have a defensible research meaning, T−1 availability, leakage status, provenance, missingness policy, redundancy assessment, and model-compatible representation. If any element is unresolved, the field remains `REQUIRES_REVIEW` or `EXCLUDED_FROM_MODEL`.



### v1.2 controlled amendments

This revision makes three limited design clarifications and authorizes the Feature Engineering v1 output contract:

1. `上映年` remains Tier 1 as `TEMPORAL_CONTROL_CANDIDATE`. It controls for differences in market, rating environment, industry context, and franchise culture across periods. It is not a general content feature and must not be interpreted as year causing rating decline.
2. `前作評分` remains an eligible predecessor/baseline predictor. Because Y is defined from `續集評分 - 前作評分`, it is mathematically coupled to Y and may exhibit regression-to-the-mean. It may support prediction, but its coefficient or importance must not be interpreted as a causal effect of prior rating.
3. Existing continuity fields (`導演是否更換`, `主演是否更換`, `與前作共同主演數`) remain priority candidates but are not implemented in v1 because the registry still marks them `REQUIRES_REVIEW / PROVENANCE_REVIEW_REQUIRED`. Raw person-name fields (`導演`, `前作導演`, `主演1`–`主演3`) remain provenance/QA references and must not be label encoded in the first model version. Any future person-identity feature requires a separate identity-representation specification.

**Authorized Feature Engineering v1 output:** preserve all 44 input fields and append only `sequel_number`, `release_year`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, and `previous_runtime` as exact value-preserving aliases. No continuity or proposed feature is authorized.

## 2. Research Questions

- **Research Question A:** Which factors are associated with a sequel's rating decline relative to its predecessor?
- **Research Question B:** Can information known before a sequel's release predict its rating-decline risk?

Association analysis may include clearly labeled retrospective/descriptive information. Post-release association must not be described as causal. Pre-release prediction uses only information demonstrably available by the cutoff and not derived from the outcome.

## 3. Input Dataset

- Path: `data/processed/movie_sequel_analysis_v1.csv`
- Approved SHA256: `d4e3ecf47eed76da1247e0daa4e136af14359b8b7e11d2884b46debcfd8e09b7`
- Verified shape: 6,481 rows × 44 columns
- TMDB ID: 0 missing and 0 duplicate-affected rows
- IMDb ID: 6,138 nonempty unique values; 343 missing
- `rating_valid` / `rating_drop`: present; 0 row-level logic mismatches
- The input is immutable and remained byte-identical while v1.1 was authored.

The v1.1 registry contains each input column once in original schema order, followed by eight `PROPOSED` rows that do not claim to exist in the input.

## 4. Target Definition

The formal Y is `rating_drop`:

```text
rating_drop = 1  when rating_valid = TRUE and 與前作評分差 <= -0.2
rating_drop = 0  when rating_valid = TRUE and 與前作評分差 >  -0.2
rating_drop = NA when rating_valid = FALSE
```

The threshold is formally approved. No threshold optimization, data-driven search, class-balance adjustment, model-driven change, or test-outcome revision is allowed. `rating_valid` only defines target eligibility and is never X. `口碑是否下滑` remains `LEGACY_REFERENCE` and is neither formal Y nor X.

## 5. Prediction Cutoff

**T−1 = the calendar day immediately before the theatrical release date.**

The prediction task asks what could be predicted using information known by T−1. Every pre-release feature must establish:

1. the information existed by T−1;
2. the recorded value reasonably represents that T−1 state;
3. it was not created or materially updated after release; and
4. provenance supports the temporal claim.

A value's presence in the dataset is not proof of T−1 availability. Unverified fields remain `REQUIRES_REVIEW`.

## 6. Feature Eligibility Framework

The registry maintains separate `association_eligible` and `prerelease_eligible` decisions. `YES` for association does not imply causality or model inclusion. Only Tier 1 fields currently have `prerelease_eligible=YES`. `REQUIRES_REVIEW` is not approval.

Identity, grouping, source, eligibility, and target fields remain available for QA and validation design even when excluded from X.

## 7. Tier Definitions

| Tier | Meaning | Existing fields |
|---|---|---:|
| `READY_FOR_FEATURE_ENGINEERING` | Existing, interpretable, no direct leakage, and conceptually available by T−1 | 6 |
| `REQUIRES_REVIEW` | Existing but temporal availability, provenance, semantics, or representation is unresolved | 18 |
| `ASSOCIATION_ONLY` | Retrospective/descriptive use only; not pre-release X | 2 |
| `EXCLUDED_FROM_MODEL` | Target, target component, identifier, direct leakage, or excluded metadata | 18 |

These tiers classify potential X usage. `rating_drop` remains the formal Y even though it is excluded from model X.

## 8. Leakage Policy

Leakage statuses are `NONE`, `POTENTIAL`, `DIRECT`, and `UNKNOWN`.

The following are explicitly prohibited from pre-release X: `平均評分`, `評分人數`, `與前作評分差`, `口碑是否下滑`, `評分樣本是否足夠`, `人氣`, `票房`, `與前作票房差`, `票房變化率`, `rating_valid`, and `rating_drop`.

`rating_drop` is Y. `rating_valid` is target eligibility. `人氣` is limited to retrospective description. No feature may be created from Y, legacy target, current rating/votes, held-out outcomes, target encoding, outcome-informed bins, or model importance computed after seeing held-out data.

## 9. Temporal Availability Policy

Temporal statuses are `AVAILABLE_BEFORE_RELEASE`, `LIKELY_AVAILABLE_BEFORE_RELEASE`, `UNKNOWN`, `POST_RELEASE`, and `NOT_APPLICABLE`.

- Tier 1 fields are conceptually available by T−1.
- Director/cast fields are now classified as `POTENTIALLY_PRE_RELEASE_ELIGIBLE`, not permanently unknown. Current credits and continuity fields are `LIKELY_AVAILABLE_BEFORE_RELEASE`; provenance and snapshot review remain mandatory.
- Current runtime and its change fields remain `UNKNOWN` until T−1 representation is demonstrated.
- Current rating, current votes, popularity, current box office, rating outcomes, and box-office changes are `POST_RELEASE`.
- A database value backfilled after release cannot be treated as T−1 information merely because its subject matter existed earlier.

## 10. Missing Value Policy

No imputation or row deletion is authorized. `NA` is not `0`, `FALSE`, or `Unknown`. All existing NA values remain unchanged.

Any future median imputation, missing category, missing indicator, or other treatment requires a separate preprocessing specification and must be **fit on training data only**. Validation/test distributions cannot determine imputation values, vocabularies, or missingness strategies. Tier 1 readiness does not imply complete data: `前作評分` and `前作評分人數` each have 32.48% missingness.

## 11. Financial Policy

`預算`, `前作預算`, `與前作預算差`, `預算變化率`, and `前作票房` remain `REQUIRES_REVIEW / EXPLORATORY_ONLY`. `票房`, `與前作票房差`, and `票房變化率` are post-release and excluded from pre-release X.

Currency, unit, geography, gross definition, snapshot, source, row-level provenance, and T−1 representation remain unresolved. No conversion, inflation adjustment, log transform, cap, winsorization, imputation, or promotion based on apparent predictive strength is allowed.

## 12. Series Policy

`電影系列ID` must be preserved as a nonnumeric grouping identifier for franchise-aware validation. It is not one-hot encoded and is never a predictor. `電影系列` remains a reference label. `第幾部` is used as recorded and no pairing/numbering is rebuilt.

`系列總部數` is association-only because it lacks an as-of-date definition. It cannot become pre-release X unless a separately supported `series_total_as_of_Tminus1` is approved. Current group size or maximum sequel number must not be substituted.

## 13. Genre Policy

`類型` remains raw `、`-delimited text. No tokenization, one-hot, or multi-hot encoding is performed. Future genre work must define delimiter, whitespace, duplicates, missingness, vocabulary, rare categories, unknown categories, and train-only vocabulary fitting.

`genre_count`, `genre_primary_category`, and `genre_token_indicators` remain proposed and require review. `genre_overlap_with_previous` and `genre_similarity` have `NO_CURRENT_INPUT`: no approved previous-genres field exists. External joins/APIs, fuzzy/title matching, or reconstructed pairing are prohibited.

## 14. Director/Cast Policy

`導演`, `前作導演`, `主演1`–`主演3`, `導演是否更換`, `主演是否更換`, and `與前作共同主演數` are `POTENTIALLY_PRE_RELEASE_ELIGIBLE` at T−1 but remain Tier 2 with `PROVENANCE_REVIEW_REQUIRED`. Therefore none is implemented in Feature Engineering v1.

Existing deterministic continuity fields take precedence if later approved. They must not be recomputed through name matching, fuzzy matching, external lookup, or pairing reconstruction. Raw names are provenance/QA references and must not be label encoded in the first version; person identity requires a separate identity-representation specification.

## 15. Runtime Policy

`前作片長` is Tier 1. `片長(分鐘)`, `與前作片長差`, and `片長變化率` remain Tier 2 until current runtime is proven available at T−1. Recorded derived values cannot be overwritten.

There are 39 runtime-rate rows with a previous-runtime denominator below 10 minutes. Preserve these rows and values. Do not delete, cap, winsorize, replace, or impute them. Runtime difference and rate remain a redundancy-review pair.

## 16. Calendar Feature Policy

`上映日期` remains Tier 2. `release_month` (1–12) and `release_quarter` (Q1–Q4) are proposed only. They require a stated research purpose and `REDUNDANCY_REVIEW`; do not include both without justification.

No cyclic encoding, target encoding, or outcome-informed binning is approved. `上映年` is Tier 1 but is a `TEMPORAL_CONTROL_CANDIDATE`, not evidence that year causes rating decline. It may absorb ecosystem, industry, franchise-culture, or other temporal confounding.

## 17. Redundancy Policy

Review, but do not automatically remove:

1. `與前作上映間隔(年)` versus a proposed `years_since_previous` alias — prefer the existing recorded representation;
2. `與前作片長差` versus `片長變化率`;
3. `release_month` versus `release_quarter`;
4. director/cast names versus existing continuity fields — prefer deterministic continuity fields;
5. financial differences versus rates — none currently enters the formal pre-release model.

No target-driven correlation, held-out performance, or post-hoc feature importance may determine redundancy handling.

## 18. Model-aware Design Constraints

Planned models are:

1. Logistic Regression — interpretable linear baseline;
2. Random Forest — nonlinear tree-ensemble comparison;
3. XGBoost — primary nonlinear boosting candidate;
4. EBM — optional explainable nonlinear model, not required for the first version.

Feature construction must not be tailored after observing a model's feature importance or held-out outcomes. The raw eligible information must be representable consistently across comparison models; model-specific encoding, scaling, imputation, and tuning belong to a later train-only preprocessing specification.

## 19. Validation Design

Primary validation is **TIME-BASED SPLIT**: earlier theatrical releases train the model; later releases form validation/test periods. Random split alone is insufficient.

A **FRANCHISE-AWARE ROBUSTNESS CHECK** must use `電影系列ID` as the grouping key so a franchise is not split across train and test in that check. The key is preserved, not numerical, not one-hot encoded, and not X. No split is executed in this stage.

## 20. Evaluation Metrics

Future model evaluation must include:

- Primary: ROC-AUC.
- Secondary: PR-AUC, precision, recall, F1, specificity, and Brier score.
- Risk-quality assessment: calibration and calibration curve.

The research predicts risk probabilities, not only hard labels. No metric is calculated in this specification.

## 21. Tier 1 Features

- `第幾部`
- `上映年`
- `前作評分`
- `前作評分人數`
- `與前作上映間隔(年)`
- `前作片長`

These six fields are implemented as exact value-preserving English aliases without imputation, encoding, scaling, or re-pairing. Their NA values remain. `上映年` is a temporal control, not a causal exposure. `前作評分` is a predecessor/baseline rating that is mathematically coupled to Y and may reflect regression-to-the-mean; it is predictive, not causal evidence.

## 22. Tier 2 Features

- `上映日期`
- `類型`
- `片長(分鐘)`
- `預算`
- `導演`
- `主演1`
- `主演2`
- `主演3`
- `前作導演`
- `導演是否更換`
- `與前作共同主演數`
- `主演是否更換`
- `與前作片長差`
- `片長變化率`
- `前作預算`
- `與前作預算差`
- `預算變化率`
- `前作票房`

These fields exist but cannot enter the pre-release model until their row-level temporal/provenance/representation questions are resolved. Presence in the dataset is not sufficient evidence.

## 23. Association-only Features

- `系列總部數`
- `人氣`

`系列總部數` lacks an as-of-date definition. `人氣` is post-release with undefined snapshot timing. Associations are retrospective and noncausal.

## 24. Excluded Features

- `電影系列`
- `電影系列ID`
- `電影名稱`
- `中文片名`
- `票房`
- `平均評分`
- `評分人數`
- `與前作評分差`
- `口碑是否下滑`
- `評分樣本是否足夠`
- `TMDB ID`
- `IMDb ID`
- `資料來源`
- `與前作票房差`
- `票房變化率`
- `target_status`
- `rating_valid`
- `rating_drop`

This list includes identifiers and metadata retained for QA/grouping, direct leakage fields, target components, and the formal target. `rating_drop` is excluded only as X and remains Y.

## 25. Proposed Future Features

All eight rows below have `status=PROPOSED`; none exists in the input or is authorized for construction.

| Proposed field | Source requirement | Pre-release status | Proposed rule | Required review |
|---|---|---|---|---|
| release_month | 上映日期 | REQUIRES_REVIEW | PROPOSED only: release_month=1-12 or release_quarter=Q1-Q4 from valid 上映日期 after one representation is approved. | Researcher approval and a separate deterministic construction/test specification are required. |
| release_quarter | 上映日期 | REQUIRES_REVIEW | PROPOSED only: release_month=1-12 or release_quarter=Q1-Q4 from valid 上映日期 after one representation is approved. | Researcher approval and a separate deterministic construction/test specification are required. |
| genre_count | 類型 | REQUIRES_REVIEW | Count nonempty unique tokens split only on approved 、 delimiter policy. | Approve genre tokenization, missingness, vocabulary, rare/unknown handling, and train-only fitting policy. |
| genre_primary_category | 類型 | REQUIRES_REVIEW | Use first token only if source ordering is proven to mean primary genre. | Approve genre tokenization, missingness, vocabulary, rare/unknown handling, and train-only fitting policy. |
| genre_token_indicators | 類型 | REQUIRES_REVIEW | Future tokenization/encoding specification required; no one-hot/multi-hot now. | Approve genre tokenization, missingness, vocabulary, rare/unknown handling, and train-only fitting policy. |
| genre_overlap_with_previous | 類型 + unavailable previous genres | NO_CURRENT_INPUT | Do not construct unless a reliable existing previous-genres field is approved. | Approved previous-genres input is absent; external lookup, fuzzy/title matching, and pairing reconstruction are prohibited. |
| genre_similarity | 類型 + unavailable previous genres | NO_CURRENT_INPUT | Do not construct until previous-genres and similarity formula are approved. | Approved previous-genres input is absent; external lookup, fuzzy/title matching, and pairing reconstruction are prohibited. |
| sequel_stage | 第幾部 | REQUIRES_REVIEW | Future mapping from recorded sequel number only; never renumber or infer pair. | Researcher approval and a separate deterministic construction/test specification are required. |

## 26. Researcher Review Items

1. Confirm T−1 provenance/snapshot support for director, cast, continuity, current runtime, budget, and previous box office.
2. Approve one calendar representation and its research purpose.
3. Approve genre tokenization, rare/unknown handling, and train-only vocabulary policy.
4. Decide whether any stable name-identity representation is justified; continuity fields are preferred.
5. Resolve all financial metric/provenance fields before promotion.
6. Decide whether to obtain a defensible as-of-T−1 series-size source; never reconstruct it from final group size.
7. Resolve difference/rate redundancy without using held-out outcomes.
8. Write a separate train-only preprocessing/missingness specification.

## 27. Downstream Workflow

1. Researcher review v1.1.
2. Deterministic feature-engineering implementation.
3. Feature QA, leakage tests, and temporal tests.
4. Association EDA and descriptive analysis.
5. Separate ML preprocessing specification.
6. Time-based train/validation/test design.
7. Franchise-aware robustness check.
8. Logistic Regression baseline.
9. Random Forest comparison.
10. XGBoost main nonlinear model.
11. Model comparison.
12. Interpretation: Logistic coefficients/odds ratios, XGBoost SHAP, and calibration.

EBM may be added as an optional explainable nonlinear comparison after the required workflow.

## 28. Explicit Out-of-scope Items

This version authorizes one deterministic feature CSV containing all 44 unchanged input fields plus the six approved aliases. It does not modify analysis v1 or master data, run EDA/visualization/correlation/hypothesis testing, impute, encode, scale, split data, apply SMOTE/class weights, train/tune models, optimize thresholds, call external APIs, enrich with IMDb/TMDB/Wikidata, fuzzy/title match, or reconstruct pairing.

**STATUS = APPROVED_FOR_FEATURE_ENGINEERING_V1**
