# Movie Sequel Association EDA v1

## Executive Summary

- **DATASET DESCRIPTION:** The immutable input contains 6,481 sequel-pair rows and 50 columns. The formal binary outcome is available for 4,058 pairs; 2,423 rows remain retained but outside target analyses.
- **DATASET DESCRIPTION:** Within the valid target population, 2,014 pairs meet the fixed `rating_drop` definition and 2,044 do not. Drop prevalence is **49.6%** (Wilson 95% CI 48.1%–51.2%).
- **UNADJUSTED ASSOCIATION:** Core relationships are descriptive and unadjusted. They do not establish causality or out-of-sample predictive performance.
- **PREDICTIVE-RELEVANCE CANDIDATE:** The five core Tier 1 variables can proceed to researcher review, but EDA alone does not select them. `previous_rating` needs special treatment because it is mathematically coupled to the change-based target.

## 1. Research Questions

- **RQ1:** Which factors are associated with a sequel receiving a lower rating than its predecessor?
- **RQ2:** Which historical variables merit later evaluation as pre-release predictors of rating decline?

This report separates dataset description, unadjusted association, and predictive-relevance review. It does not perform feature selection, preprocessing, splitting, or ML.

## 2. Data and Population

- Input: `<PROJECT_ROOT>/data/processed/movie_sequel_features_v1.csv`
- Input SHA256: `a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6`
- Shape: 6,481 × 50
- Binary-target population: `rating_valid = TRUE` and `rating_drop` nonmissing.
- Target threshold: recorded `與前作評分差 <= -0.2`; unchanged and not optimized.
- All-row population: 6,481.
- Valid target population: 4,058.
- Invalid/missing target rows retained: 2,423.
- TMDB ID coverage: 6,481/6,481; duplicates: 0.
- IMDb ID coverage: 6,138/6,481; nonempty duplicates: 0.
- Release year maximum is 2026; **2026 is an incomplete year and must not be interpreted as a complete annual cohort.**

## 3. Dataset Distribution

Core field availability:

- `rating_change`: n=4,376; missing=2,105 (32.5%).
- `previous_rating`: n=4,376; missing=2,105 (32.5%).
- `previous_rating_votes`: n=4,376; missing=2,105 (32.5%).
- `years_since_previous`: n=4,376; missing=2,105 (32.5%).
- `previous_runtime`: n=4,273; missing=2,208 (34.1%).
- `sequel_number`: n=6,481; missing=0 (0.0%).

Population-comparison tables retain separate denominators for all rows and target-valid rows. Differences are population description only; this report does not label them selection bias.

The all-row population includes recorded part-1 rows (`sequel_number` minimum 1), whereas the valid target population begins at part 2 because a predecessor rating is required. Median sequel number is 2 in all rows and 3 in the valid target population. This is a structural population difference, not by itself evidence of selection bias.

Exact `資料來源` labels were retained without consolidation. Detailed year, decade, source, missingness, numeric-distribution, and population-comparison results are in `reports/tables/movie_sequel_eda_v1/`.

## 4. Target Distribution

| Target status | n | Share of valid target population |
|---|---:|---:|
| `rating_drop = 1` | 2,014 | 49.6% |
| `rating_drop = 0` | 2,044 | 50.4% |
| Invalid/missing | 2,423 | Not in target denominator |

The continuous outcome description uses the recorded `與前作評分差` only for rating-valid pairs. The histogram marks the fixed −0.2 threshold. No alternate threshold was searched.

## 5. Core Association Results

### 5.1 Sequel number

**UNADJUSTED ASSOCIATION.** The prespecified groups were retained exactly.

| Sequel group | Eligible n | Drop prevalence | Difference vs part 2 | Odds ratio vs part 2 (95% CI) |
|---|---:|---:|---:|---|
| 2 | 1,993 | 55.2% | reference | reference |
| 3 | 886 | 46.3% | -9.0% | OR 0.70 (0.60–0.82) |
| 4 | 387 | 47.8% | -7.4% | OR 0.74 (0.60–0.92) |
| 5+ | 792 | 40.2% | -15.1% | OR 0.54 (0.46–0.64) |

These estimates may reflect franchise survival, era, and within-franchise dependence. They do not show that sequel stage causes rating decline.

### 5.2 Continuous Tier 1 variables

| Variable | Eligible n | Spearman rho | OR per stated unit | 95% CI | Unit | Interpretation warning |
|---|---:|---:|---:|---|---:|---|
| `previous_rating` | 4,058 | 0.192 | 1.486 | 1.399–1.579 | 1 | Mathematical coupling / regression-to-the-mean |
| `previous_rating_votes` | 4,058 | 0.113 | 0.912 | 0.650–1.277 | 10000 | Unadjusted; descriptive |
| `years_since_previous` | 4,058 | 0.104 | 1.029 | 1.016–1.042 | 1 | Unadjusted; descriptive |
| `previous_runtime` | 3,991 | 0.075 | 1.045 | 1.021–1.069 | 10 | Unadjusted; descriptive |

Odds ratios are from separate one-predictor, unadjusted logistic models. Units are 1 rating point, 10,000 votes, 1 year, and 10 runtime minutes, respectively. Rescaling is only for coefficient interpretation; stored values were unchanged.

`previous_rating` is a predecessor/baseline measure mathematically embedded in `current rating − previous rating`. Its association may reflect mathematical coupling and regression-to-the-mean. A predictive association is not a causal effect.

## 6. Temporal / Source Robustness

`release_year` remains a **TEMPORAL_CONTROL_CANDIDATE**. Era differences may represent rating-system, market, franchise, source, or industry composition.

| Era | Eligible n | Drop prevalence |
|---|---:|---:|
| ≤1959 | 198 | 46.0% |
| 1960–1989 | 626 | 57.8% |
| 1990–2009 | 1,185 | 59.8% |
| 2010–2019 | 992 | 45.6% |
| 2020–2026 | 1,057 | 37.8% |

Source composition:

| Exact source label | All rows | Valid target n | Drop prevalence |
|---|---:|---:|---:|
| Kaggle歷史資料 | 4,127 | 2,732 | 55.2% |
| TMDB 2018–2020補充 | 681 | 404 | 38.1% |
| TMDB API 2021-2026 | 1,420 | 921 | 38.1% |
| Kaggle歷史資料 + TMDB API 2021-2026 | 1 | 1 | 0.0% |
| TMDB API 2018-2020 | 252 | 0 | NA |

Source differences are descriptive. They are not evidence of source bias or a causal source effect.

## 7. Secondary Retrospective Results

The director-change, lead-cast-change, shared-cast-count, current-runtime, raw-genre, release-date, and franchise-structure analyses are labeled **RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED**.

| Recorded continuity field | Group | Eligible n | Drop prevalence |
|---|---|---:|---:|
| 導演是否更換 | FALSE | 1,808 | 47.1% |
| 導演是否更換 | TRUE | 2,200 | 51.8% |
| 主演是否更換 | FALSE | 605 | 42.6% |
| 主演是否更換 | TRUE | 3,341 | 51.2% |

For recorded shared lead-cast count, observed drop prevalence ranges from 42.6% to 52.5% across the available exact counts. This remains retrospective and does not prove T−1 availability or an independent association.

- Continuity analyses use the recorded flags/count only; no names were rematched.
- Genre analysis uses exact raw `、`-delimited strings. No tokenization, count feature, one-hot, or multi-hot encoding occurred.
- Current runtime and its recorded difference/rate remain temporally unresolved at T−1. The known 39-row small-denominator warning for runtime rate remains; no row was removed or altered.
- `電影系列ID` was used only to describe clustering structure and remains excluded as X.

## 8. Financial Exploratory Results

Financial fields remain **EXPLORATORY_ONLY / PROVENANCE_UNRESOLVED**.

| Variable | Available n | Missing rate | Median | Q1 | Q3 | Minimum | Maximum |
|---|---:|---:|---:|---:|---:|---:|---:|
| 預算 | 2,435 | 62.4% | 13000000.00 | 3500000.00 | 40000000.00 | 7.00 | 658800000.00 |
| 前作預算 | 1,751 | 73.0% | 11000000.00 | 3000000.00 | 35000000.00 | 7.00 | 658800000.00 |
| 與前作預算差 | 1,223 | 81.1% | 2000000.00 | -675000.00 | 12000000.00 | -478800000.00 | 488800000.00 |
| 預算變化率 | 1,223 | 81.1% | 0.22 | -0.07 | 0.81 | -1.00 | 967.86 |
| 前作票房 | 1,966 | 69.7% | 34457903.00 | 8600000.00 | 141493976.75 | 2.00 | 2923706026.00 |

Currency, unit, geography, gross definition, snapshot timing, and row-level provenance remain unresolved. No currency conversion, inflation adjustment, log transformation, winsorization, capping, imputation, or outlier deletion was performed. Financial associations do not promote these variables to formal predictors.

## 9. Main Findings

1. **DATASET DESCRIPTION:** The fixed binary target is available for 4,058 of 6,481 rows; missing-target rows remain part of the source population but not the target denominator.
2. **DATASET DESCRIPTION:** Rating-drop prevalence under the approved ≤−0.2 rule is 49.6% among valid pairs.
3. **UNADJUSTED ASSOCIATION:** Prespecified sequel groups show different observed drop prevalences; interpretation must account for era, franchise survival, and repeated franchise observations.
4. **UNADJUSTED ASSOCIATION:** `previous_rating` shows a change-outcome relationship that is structurally vulnerable to mathematical coupling and regression-to-the-mean.
5. **DATASET DESCRIPTION:** Source/era composition is material: one recorded source group has no valid target pairs, while observed prevalence differs across other source and era groups. These differences are descriptive and require design review, not a source-effect interpretation.

## 10. Limitations

- 2026 is an incomplete year; annual results are cumulative rather than a full-year cohort.
- `previous_rating` is mathematically coupled to the change-based Y and may reflect regression-to-the-mean.
- All associations are unadjusted and may reflect era, source composition, franchise survival, or within-franchise dependence.
- Core-feature missingness uses pairwise eligible populations; no imputation or global listwise deletion occurred.
- Director/cast continuity and current-runtime analyses are retrospective and require T−1 provenance review.
- Financial metrics have unresolved currency, geography, definition, snapshot, and row-level provenance.
- Raw genre labels were not tokenized; exact label combinations are descriptive only.
- No p-values were used for selection; no multiple-comparison correction was required in this effect-size-first execution.
- Recorded source group(s) with zero valid target pairs: TMDB API 2018-2020. Their rating-drop prevalence is NOT ESTIMABLE, not 0%.

No inferential p-values are reported. Therefore there is no multiple-comparison p-value family or post-hoc significance selection in this execution. Effect sizes and 95% intervals are descriptive and unadjusted.

## 11. Variables Worth Researcher Review

- Tier 1 candidates: `sequel_number`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, and `previous_runtime`.
- Temporal control candidate: `release_year`.
- Provenance/temporal review: recorded director/cast continuity and current-runtime measures.
- Representation review: raw genre labels require a separate tokenization policy before use.
- Financial fields remain exploratory until provenance is resolved.

“Worth review” is not feature selection. Advancement still requires T−1 eligibility, leakage, provenance, missing-data, redundancy, and validation review.

## 12. What EDA Does NOT Establish

This EDA does not establish causality, independent effects, temporal availability at T−1, out-of-sample prediction, calibrated risk estimates, a final feature set, or model performance. It does not modify the target, source data, pairing, or threshold. It performs no imputation, encoding, scaling, train/test split, Logistic Regression model development, Random Forest, XGBoost, SHAP, or threshold optimization.

**STATUS = EDA_COMPLETE_WITH_WARNINGS**
