# Explanatory Association Extension — Candidate Feature Construct / Version / Missingness Gate Review v1

## Executive decision

**三個候選均為 DEFER；目前不能進入 EA implementation specification。** 這不是推翻上階段方案B，也不是否定回溯關聯研究；方案B原本即以構念與版本gate通過為前提。此次證據比上一輪更完整，但仍未達到必要gate。

已確認原始Excel明文描述導演同異、top-3共同主演數、片長差公式；不得再把這些構念說成完全沒有定義。然而「有文字定義」與「既有值確實依完整、一致規則生成」是不同層級。三欄的記錄與保存可信，細部構念/版本的來源證據仍不足。

本次只核对metadata、資料表示與availability；未計算新regression、ML、correlation、p-value或R²。不重新比較導演姓名、不重新計算cast intersection或runtime difference，不改任何資料。

審查時間：2026-09-13T23:42:44.910275+08:00  
RQ1：目前可觀察電影／系列特徵與recorded rating_change的條件關聯；不是因果推論或T−1 prediction。  
審查範圍僅新增三欄；不重新審查五個既有core X，不重跑LR-A/LR-B，不評估模型績效。

## 1. Input與固定母體

Input：`data/processed/movie_sequel_features_v1.csv`  
實測SHA256：`a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6`  
Shape：6,481×50。CLEAN依已核准current>0、previous>0、recorded change非缺失的唯讀遮罩，仍為4,058。遮罩內rating_valid均TRUE。既有recorded `與前作評分差`保持不變，沒有相減重建Y或寫入新target。

原始工作簿：`<USER_HOME>/Downloads/電影續集疲乏_完整分析主檔.xlsx.xlsx`  
SHA256：`85f270877fc88a0eae3375e28db3280469725542d8d234ad7cbd8e17f0f4e4cf`，與master manifest紀錄相同。不是此次新增的外部資料，而是既有master的同一原始來源。

### 證據等級

1. 原始Excel的「分析特徵說明」：可以證明作者宣告的語意，**不是本次執行指令**。其「核心X」「Y」建議不取代現行研究決策。
2. master build / transformation / feature build：可證明原值保存與技術型別，不能代替上游生成演算法。
3. 既有Model C QA：Boolean/range/formula通過是資料內部一致性，不是多導演、演員身分、影片版本皆已認證。
4. 本次availability QA：只檢查已有值、NA、範圍、來源及分組，不能從模式反推所有上游規則。

## 2. Lineage：原始recorded derived field，而非本次衍生

工作簿「完整主檔」原有41欄，其中：
- Y/AC/AD欄：導演、前作導演、導演是否更換。
- Z/AA/AB/AE/AF欄：主演1/2/3、與前作共同主演數、主演是否更換。
- J/AG/AH/AI欄：片長(分鐘)、前作片長、與前作片長差、片長變化率。

master build report記錄工作簿無公式；這些欄位是**上游已衍生、在原始工作簿中儲存為值的recorded fields**，不是Excel內可追formula的活公式。接管時只作型別/缺失表示整理，新增target_status；analysis加rating_valid/rating_drop；features只追加六個既有numeric aliases。三個候選沒有在此鏈中重新生成，也没有對應已實作的英文continuity alias。

本次在原有src中定位到一個導演集合比较及top-5演員規則（`src/build_ml_dataset.py`），但它的預設來源是另一份「電影續集疲乏 _ML分析資料版.xlsx」，輸出v2，並非本次classmate master lineage。**不能把那段top-5／集合正規化程式借來證明此top-3資料的生成規則。** 未執行該程式，也未讀其外部cache補欄位。

原工作簿說明B2提到「同系列依上映日期排序後上一部」是來源描述；本次沒有據此排序或重新找前作。50欄未包含可直接稽核的前作top-3名單、cast person IDs或版本/剪輯欄。

## 3. Candidate 1：導演是否更換

### 已明確的構念

原始Excel「分析特徵說明」A3:C3：0＝導演相同，1＝導演不同，缺資料留白。B2把前作導演描述為既有前作的導演。因此意圖是「本集相對前作的導演是否改變」，不是當期導演知名度、片商變更或演員變更。

features序列化為TRUE/FALSE/空白；是既有0/1/NA的表示轉換，不是從姓名再計算。對應解釋為1/TRUE changed、0/FALSE same，空白missing。

### 十個問題的判定

| 問題 | 審查結論 |
|---|---|
| 0/1定義 | 有作者文字定義，非憑欄名猜測 |
| current vs previous一致生成 | 宣告意圖支持，未找到適用於此原始workbook的完整生成程式/逐列來源log；尚不能確認實作一致 |
| 多導演如何處理 | UNKNOWN：整個集合一致、任一重疊、首位導演、串接文字相等，均可能產生不同旗標 |
| 名稱順序是否影響 | UNKNOWN；未證實order-invariant set comparison，不自行拆分/排序測試新旗標 |
| 名稱格式差異 | 有中文/拉丁字元與多值文本；別名/譯名/字形差可能造成假更換，實際錯判數未知 |
| director缺失處理 | 檔內可見missing與FALSE分開；沒有旗標有值而任一導演文字缺失的列 |
| NA與未更換是否可區分 | **儲存層YES**；上游未記錄的別名/unknown情形是否曾編成0仍不能完全排除 |
| recorded還是後算 | 原Excel已有的上游derived recorded欄；後續保存，非本次或FE新計算 |
| construct QA是否充分 | Boolean/NA匹配支持表示一致性；不足以驗證姓名身分、多導演與比較語意 |
| 是否代表導演從前作更換 | 作者意圖YES；目前只能稱「來源記錄的導演同異旗標」，尚不足以無條件當一致製作構念 |

### Missingness與raw證據

CLEAN：導演missing40、前作導演missing30；任一缺失聯集50。旗標missing50（1.23%），有值4,008，TRUE2,200、FALSE1,808。
- 旗標有值且任一name缺失：0。
- 兩側name皆有值但旗標NA：0。
以上與既有Pre-Transformation Audit的全檔零衝突結果一致，未重新用姓名生成旗標。

原值例：TMDB ID166426的導演文字為「Espen Sandberg、喬阿吉姆·羅恩尼」，前作「Rob Marshall」，recorded TRUE。這只能證明多導演文本確實存在，不能證明集合比較、排序或別名處理方式。未把文字格式差視為已確認資料錯誤。

**Gate grade=C；Decision=DEFER；Can enter EA-core? NO。**  
未通過：精確比較定義、person representation與上游construct provenance。需要原提供者適用於本檔的生成規則/程式、版本記錄與多導演/順序/別名/缺失政策；不是讓研究者現在憑空選一套新規則套回舊值。

## 4. Candidate 2：與前作共同主演數

### 本次補足的原始定義

原始Excel「分析特徵說明」A4:C4明示：比較本集與前作的主演1～3，共同出現幾人（0～3）。A5:C5明示：共同數3時主演是否更換=0，少於3時=1，資料不足留白。

因此**top-3構念意圖已被原始metadata支持**，比上一輪僅由0–3範圍推測更強。但「主演1～3」的挑選基準（credit order、billing、角色重要性）、重複身分去重、name/ID比對與快照版本未記錄。

| 問題 | 判定 |
|---|---|
| intersection哪些集合 | 宣告為current與既有previous的主演1～3；不是全體cast |
| 是否兩側top3 | 作者說明YES；兩側實際抽取/排序與名單完整性仍待實作證據 |
| 排序影響 | 固定同一集合內順序理應不改intersection；但排序會影響誰進top3，兩層不可混同；實作未知 |
| normalization / 同名 | 沒有此lineage的規則或person IDs；同名可假重疊，譯名可假不重疊，未量化錯配 |
| previous對應資料 | 本檔與原工作簿都沒有前作主演1/2/3或previous cast list。禁止用系列排序/名稱重建替代 |
| cast missing vs0 | 檔內NA與0不同，current名單不全時沒有填shared0；但缺previous名單，不能確認每個0基於兩側足夠資料 |
| current/previous完整性 | current可看三格有無；previous無法直接核對。三格非空也不自動保證三個不同真實人物 |
| top3截斷 | 是宣告的有限cast representation，不一定是bug；不可解讀為整部片演員更換程度 |
| 旗標重疊 | 原始metadata明示same構念的閾值版本；先前QA mismatch=0，只支持這層deterministic consistency，不證明intersection算對 |

### Missingness / zero evidence

shared有值3,946，missing112（2.76%）；recorded0/1/2/3分別1,267/1,038/1,036/605。主演更換flag同樣missing112、TRUE3,341、FALSE605。

current主演1/2/3個別missing24/51/84，任一缺失聯集84。這84筆shared全NA；current完整但sharedNA另28筆。**不能直接把後28筆叫「已證明previous缺失」**，因沒有前作名單或上游log；只可說與未觀察到的前作完整性/比較規則有關的可能性尚待查明。

shared有值但current三格不全：0；shared=0但current三格不全：0。這排除了「可見current空格直接填0」這一種問題，**沒有排除隱藏的previous不足、重複名字、別名或錯身分**。不得把1,267個0全部稱為已核實無共同演員。

**Gate grade=C；Decision=DEFER；Can enter EA-core? NO。**  
需要與原固定pair對應的既有兩側top3來源名單/生成紀錄、cast選取與名稱身分規則、missing/zero分流政策。不得新爬cast或重建pair。EA-core原提案未含「主演是否更換」，因此此重疊本身不是現有三candidate之間的必然共線性，也不以重疊為由自行換X。

## 5. Candidate 3：與前作片長差

### 有證據支持的部分

原始Excel「分析特徵說明」A6:C8說明前作片長、current−previous差值及以previous作分母的rate；完整主檔J1明確標「片長(分鐘)」。後續schema把差值視為numeric、rate視為ratio。故可以描述**名義上以分鐘為單位的recorded current−previous difference**。

既有Model C manifest input_gate：
- runtime_difference_formula_n=3,923、mismatches=0。
- runtime_rate_formula_n=3,923、mismatches=0。
其程式使用1e−9絕對容差作QA。此處只引用既有證據，沒有重新相減/相除。它證明有完整元件的recorded算術一致，不證明元件代表同類剪輯或影片版本。

### Missing、0及範圍

- 差值非缺失3,923，missing135（3.33%），range−395至401分鐘；recorded差值0有310筆，與NA明確分離。
- current片長missing4、0值90、無負值；previous片長missing67、0值0、range3–476。
- 差值missing135中：69筆至少一側runtime缺失，66筆兩側有數字但current=0。
- 兩側positive但recorded差值missing：0；recorded差值有值但任一側缺失或nonpositive：0。
- 這是**觀察到的positive-runtime可用性模式**，與「不從0片長建立差值」相容；原作者完整的缺失生成程式仍未提供。本次沒有把90個0改NA，也沒有按正值規則補算/替換差值。

### 版本與極端值gate

兩個端點的raw證據：
| TMDB ID | 電影名稱 | source | current min | previous min | recorded difference |
|---|---|---|---:|---:|---:|
| 444149 | Hellraiser: Judgment | TMDB 2018–2020補充 | 81 | 476 | −395 |
| 348191 | Leviathan: The Story of Hellraiser and Hellbound: Hellraiser II | Kaggle歷史資料 | 476 | 75 | 401 |

表格原樣引用，不將兩列重新配對；不由名稱判定電影類型、資料錯誤或應剔除。這些值可能反映不同長短、內容/作品範圍、版本或記錄問題；**目前沒有版本/剪輯欄、取值政策或逐列source record能判別**。沒有證據證明「曾混用extended/director's cut」，也沒有足夠證據宣称「已排除不可比版本」。缺證與已確認不一致必須分開。

### 與rate及其他runtime欄的關係

- raw minute difference没有分母；CLEAN28筆previous runtime<10的放大問題主要針對rate。差值比rate直觀，也不受除以極小片長的機制放大，但仍可能有真實大差/measurement error。
- rate range−0.96至25，不應為了避免極端值而cap或換Y。
- 已確認recorded公式一致的列，current=previous+difference。因此若同時納current、previous、difference會有確定冗餘。原EA-core只含previous與difference，不因此構成三項等式共線性。
- 不新增current runtime或rate，也不把差值替換成rate。

**Gate grade=C；Decision=DEFER；Can enter EA-core? NO。**  
算術/名義單位/可見NA模式通過，卡在**版本與runtime scope可比性、上游取值政策**。不是因為無T−1快照而否決，也不是因為差值極端就REJECT。需要既有來源/提供者確認影片版本與runtime範圍選取政策，並解釋上述端點取值的口徑；不要求本次修改pair或原值。

## 6. 共同availability / population gate

本節無X–Y association；所有母體均由固定CLEAN及已記錄NA mask取得。

| 欄位 | 非缺失 | missing | missing % of CLEAN |
|---|---:|---:|---:|
| 導演是否更換 | 4,008 | 50 | 1.23% |
| 與前作共同主演數 | 3,946 | 112 | 2.76% |
| 與前作片長差 | 3,923 | 135 | 3.33% |

三欄missing聯集=256（6.31%），不是50+112+135=297。三欄共同complete=3,802（93.69%）。再要求五個既有core X完整，仍3,802；加coupling companion previous_rating也不改此已知可用樣本。這些都是potential availability，不是新模型N，不意味candidate gate通過。

missing pattern次序為導演／shared／runtime difference：
| pattern（1=NA、0=有值） | n |
|---|---:|
| 000 | 3802 |
| 001 | 126 |
| 010 | 80 |
| 100 | 12 |
| 101 | 6 |
| 110 | 29 |
| 111 | 3 |

CLEAN franchise ID=2,000；三欄共同CC=1,908。五既有core+三欄共同CC亦1,908。只計數現有ID，不重建系列，不當精確effective sample size。

| exact source label | all rows | CLEAN | director NA | shared NA | runtime diff NA | common CC | CC franchise IDs |
|---|---:|---:|---:|---:|---:|---:|---:|
| Kaggle歷史資料 | 4127 | 2732 | 28 | 73 | 81 | 2580 | 1252 |
| TMDB 2018–2020補充 | 681 | 404 | 10 | 12 | 13 | 372 | 275 |
| TMDB API 2021-2026 | 1420 | 921 | 12 | 27 | 41 | 849 | 622 |
| Kaggle歷史資料 + TMDB API 2021-2026 | 1 | 1 | 0 | 0 | 0 | 1 | 1 |
| TMDB API 2018-2020 | 252 | 0 | 0 | 0 | 0 | 0 | 0 |

各來源群組ID數可重疊，**不能相加當1,908**；來源列數可加總。保留全部5個label，包括CLEAN=0的來源，不把0樣本率寫成0%品質問題。来源差異仅為availability，不能稱偏誤或解釋效果。2026仍是截至2026-09-12累積、不完整年度。

## 7. 必要gate總表

| 必要gate | 導演是否更換 | 共同主演數 | 片長差 |
|---|---|---|---|
| G1 可明確描述且證明一致生成的construct | 意圖明確；多導演/identity规则未證實 | top3意圖明確；排序選人/去重/identity未證實 | 算術與方向已記錄，QA支持 |
| G2 missing不等於confirmed0/unchanged | 可見儲存層通過；上游身分比較仍缺證 | 可見current完整性通過；previous完整性/0含義缺證 | 可見NA/0及正片長availability支持 |
| G3 版本/範圍可比性 | 導演名單範圍/版本未定 | cast ranking/list版本未定 | cut/edition/runtime scope未定；極端比較口徑未說明 |
| G4 擬議EA-core無明顯確定冗餘 | 無直接同值別名入模 | 未與cast flag同入；可避免 | 未與current+previous三項同入；可避免 |
| G5 provenance支持回溯construct | workbook→features保存鏈通過；上游判定規則不足 | 保存鏈通過；previous input/identity規則不足 | 保存鏈及公式通過；版本選值來源不足 |
| G6 事前固定表示方法 | 可固定0/1/NA，但不能補證上游語意 | 可固定recorded0–3/NA，但不能補證上游語意 | 可固定raw minute difference/NA，但不能补证版本一致 |
| 最終decision | **DEFER** | **DEFER** | **DEFER** |

A/B/C/D初步等級和正式decision不是同一欄：A表示現有證據足夠、B表示僅需把已支持定義寫入spec、C表示還缺證據、D表示已知不適用。本次三欄均C→DEFER。不能用CONDITIONAL_REVIEW掩蓋尚未通過的必要gate，也不能靠新spec規定去反證舊資料怎麼生成。

## 8. RQ1與RQ2分離

三欄皆可能是合理的retrospective recorded film characteristics；現在defer源於構念/版本證據缺口，而非「上映後才查錄」本身。若日後證據補足，可重新review其RQ1用途，不必因此要求新的T−1 snapshot。

但本次沒有核准任何candidate，且即使未來RQ1通過，也**不解除RQ2的PROVENANCE_REVIEW**。回溯可用不等於上映前可用。既有五core X和previous_rating companion政策不重新決策，不改Y、CLEAN、LR-A/LR-B。

## 9. 最小的待補證據與停止

- 導演：提供適用於此Excel版本的上游判定程式/規則，以及多導演集合、排序、別名/人ID、缺失處理說明。
- Cast：提供既有pair所用的兩側top3來源紀錄及選取/去重/身分/不足名單政策；不從其他影片重新推前作，不新爬cast。
- Runtime：提供既有來源runtime選取、cut/edition與影片範圍政策、0/NA處理；確認極端原值的可比口徑。不自動修正、剔除或換X。

此處只列出缺少的證據，不執行補證或建立替代特徵。**Can proceed to EA implementation specification? NO。** 未通過G1/G3/G5及部分G2；沒有最終核准的新增三欄或完整EA-core清單。維持既有結果，停止此次extension，不縮成另一個偷偷執行的模型。

## 10. Exact source files / locators

- `<USER_HOME>/Downloads/電影續集疲乏_完整分析主檔.xlsx.xlsx`：完整主檔!J1、Y1:AI1；分析特徵說明!A2:C8。僅metadata與原欄，不採納C欄的ML建議。
- `reports/movie_sequel_master_classmate_v1_build_report.md`：結構整理、coverage；`reports/movie_sequel_master_classmate_v1_manifest.json`：input SHA、research_value_recalculation=false。
- `src/build_movie_sequel_master_classmate_v1.py`：resolve_input、inspect_workbook、structural_clean（僅讀程式）。
- `reports/movie_sequel_analysis_v1_transformation_report.md`、`src/transform_movie_sequel_analysis_v1.py`：型別與recorded保護。
- `reports/movie_sequel_feature_engineering_qa_v1.md`、`src/build_movie_sequel_features_v1.py`：原44欄逐值/NA保存、六alias mapping。
- `reports/pre_transformation_audit/pre_transformation_audit_report.md`：導演Boolean及runtime QA。
- `reports/model_c_continuity_qa.md`、`reports/model_c_continuity_manifest.json` input_gate、`src/run_model_c_continuity_v1.py` lines162–184：既有Boolean/range/formula check之實際範圍；本次不執行。
- `reports/explanatory_analysis_design_review_v1.md`、`reports/explanatory_analysis_feature_eligibility_v1.csv`：B方案與先前shared/flag一致性QA。
- `reports/movie_sequel_transformation_spec_v1.md`、`reports/movie_sequel_feature_engineering_spec_v1.2.md`：raw保護與RQ1/RQ2區分。
- `src/build_ml_dataset.py` lines71–76、319–320、368–370；`src/map_previous_movie.py` line12：**排除為本classmate資料生成證据的另一lineage**。

以上既有文件/程式皆僅讀。沒有用既有importance/p-value/AUC選變數或作gate理由。

