# ML Preprocessing Specification v1

**Status:** `PREPROCESSING_SPEC_COMPLETE`  
**Scope:** deterministic preprocessing and QA only; no model fitting or performance comparison.

## 1. Input

- Source: `data/processed/movie_sequel_features_v1.csv`
- Approved SHA256: `a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6`
- Expected shape: 6,481 rows × 50 columns
- The source is immutable. The pipeline must stop before publication if its hash or shape differs.

## 2. Target definition and eligibility

The existing `rating_drop` is the only formal Y:

```text
rating_drop = 1 when rating_valid = TRUE and recorded rating change <= -0.2
rating_drop = 0 when rating_valid = TRUE and recorded rating change >  -0.2
rating_drop = NA when rating_valid = FALSE
```

The pipeline does not recompute or change this target. It restricts the prediction population to rows where `rating_valid = TRUE` and `rating_drop` is nonmissing. Required counts are 4,058 rows: 2,014 drop and 2,044 non-drop. Any discrepancy is a critical failure.

## 3. Fixed model schemas

### Model A

Feature order is fixed:

1. `sequel_number`
2. `release_year`
3. `previous_rating`
4. `previous_rating_votes`
5. `years_since_previous`
6. `previous_runtime`

### Model B — coupling sensitivity

Feature order is fixed:

1. `sequel_number`
2. `release_year`
3. `years_since_previous`
4. `previous_runtime`

Model A and B use the same Y, eligibility rule, time split, missing-data methods, scaling methods, and franchise grouping. Their only feature difference is the joint removal of `previous_rating` and `previous_rating_votes` from Model B. This comparison is not feature-importance or causal proof.

## 4. Missing-data strategies

Neither strategy is selected by this specification. They are parallel, prespecified preprocessing candidates.

### P1 — complete-case

- Restrict the target-eligible population separately for each model to rows where every model X is nonmissing and finite.
- Record every excluded count and each feature's missingness; never treat missing as zero.
- Output a raw complete-case file and a train-only standardized complete-case file for each model.
- P1 is a transparent baseline, not the final missing-data policy.

### P2 — train-only median imputation plus missingness indicator

- Split the target-eligible population by time before fitting any preprocessing parameter.
- Calculate each median from the training cohort only.
- Apply the training median to missing training and test values; never inspect test values to choose the median.
- A missingness indicator is defined from whether the original X was missing. Indicator inclusion is determined only from training missingness. Indicators are not scaled.
- Calculate scaling mean and population standard deviation from the imputed training values only; apply those parameters to test.
- To avoid unnecessary full-data copies, v1 publishes parameter files and schemas for P2 rather than four imputed CSVs. A later modeling pipeline must reproduce the recorded rules exactly.
- P2 is a candidate policy and is not selected on the basis of model metrics.

## 5. Fixed time split

- Train: `release_year <= 2020`
- Test: `release_year >= 2021`
- Apply the split after target eligibility and before any fitted preprocessing operation.
- Do not use random split or row order.
- The 2026 test cohort is incomplete and must retain this warning.

## 6. Franchise grouping

Create metadata field `franchise_group_id` as an exact string alias of `電影系列ID`.

- It is retained for future franchise-aware robustness validation only.
- It is not X and must never be encoded, scaled, imputed, one-hot encoded, or included in the model matrix.
- Franchise overlap across the primary temporal split is permitted; the later robustness design must prevent cross-split franchise overlap.

`TMDB ID` and `IMDb ID` are retained as traceability metadata in preprocessing outputs and are never X.

## 7. Scaling

For every numeric X selected by P1 or P2:

```text
z = (x - training_mean) / training_population_standard_deviation
```

- Mean and standard deviation are fitted only on the strategy/model's training rows.
- Test rows only receive the training transformation.
- A zero or nonfinite training standard deviation is a critical failure.
- Raw output remains available; standardized columns use a `__z` suffix.
- Scaling does not change the stored source file or the research meaning of X.

## 8. Leakage prevention

Model A and B X must not contain current rating, current rating votes, popularity, current box office, rating change, box-office change/rate, target eligibility, target, legacy target, or identity/grouping fields. The pipeline enforces an explicit prohibited list including:

`平均評分`, `評分人數`, `人氣`, `票房`, `與前作評分差`, `與前作票房差`, `票房變化率`, `rating_change`, `rating_valid`, `rating_drop`, `口碑是否下滑`, `電影系列ID`, `TMDB ID`, and `IMDb ID`.

`rating_drop` is output only as Y. Identity and grouping columns are output only as metadata. They are excluded from each declared X schema.

## 9. Encoding policy

No categorical X is approved. Do not perform one-hot, label, target, ordinal, frequency, or other encoding. Do not add categorical predictors.

## 10. Outlier policy

Do not delete, clip, cap, winsorize, replace, or transform outliers. Nonmissing finite recorded values are retained. Any unusual values are warnings for later research review, not authorization to change the data.

## 11. Feature-transformation policy

Do not create logarithms, polynomials, interactions, ratios, bins, nonlinear transformations, or new research features. P2 missingness indicators and `__z` standardized columns are technical preprocessing representations only and cannot be interpreted as newly approved research variables.

## 12. Output contract

Directory: `data/processed/movie_sequel_ml_preprocessed_v1/`

P1 datasets:

- `model_A_complete_case.csv`
- `model_A_complete_case_scaled.csv`
- `model_B_complete_case.csv`
- `model_B_complete_case_scaled.csv`

Parameter files:

- `model_A_complete_case_scaling_parameters.csv`
- `model_B_complete_case_scaling_parameters.csv`
- `model_A_p2_train_parameters.csv`
- `model_B_p2_train_parameters.csv`

Each dataset contains traceability metadata (`TMDB ID`, `IMDb ID`, `franchise_group_id`, `data_split`), Y, and only the declared model X representation. Metadata columns are not part of X. Row order follows the source order after the explicit P1 filter.

## 13. Reproducibility

- The build script must gate the input hash, shape, schema, target logic, identity integrity, and target counts.
- Machine-readable outputs must be generated twice in isolated temporary directories and compared byte-for-byte.
- Output column order, row order, NA behavior, split labels, parameter origin, and hashes must be recorded.
- The source hash and file metadata must be unchanged after execution.
- Failure of any critical gate or deterministic comparison blocks publication.

## 14. Limitations

- Complete-case analysis can change sample composition and reduces target-eligible n.
- P2 is specified but not selected; later formal modeling must not choose P1/P2 from the held-out test performance.
- `previous_rating` is mathematically coupled to the change-based Y and may reflect regression-to-the-mean; Model B is the prespecified sensitivity analysis.
- `release_year` is temporal context/control, not a causal movie-content feature.
- A single temporal holdout is not the future franchise-aware robustness analysis.
- The 2026 cohort is incomplete.
- No model, AUC, feature selection, target optimization, or external enrichment is part of preprocessing.

## 15. Publication decision

The specification is complete. Model A and Model B may proceed to formal modeling only through these fixed schemas and preprocessing candidates. No critical issue blocks preparation; the choice between P1 and P2 remains a prespecified analysis decision that must not be made from held-out test performance.

**STATUS = PREPROCESSING_SPEC_COMPLETE**
