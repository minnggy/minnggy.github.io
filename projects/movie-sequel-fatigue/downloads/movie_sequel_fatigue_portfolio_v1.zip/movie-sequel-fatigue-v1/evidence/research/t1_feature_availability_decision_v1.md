# T−1 Feature Availability Decision Audit v1

**STATUS = T1_FEATURE_AVAILABILITY_DECISION_COMPLETE**

## Executive decision

The existing project evidence is sufficient to proceed to a formal ML preprocessing specification using a narrow, controlled predictor set. The formal Model A uses the six already implemented Feature Engineering v1 aliases. Model B removes the two predecessor-rating fields solely as a prespecified mathematical-coupling sensitivity analysis.

No continuity, current-runtime, genre/calendar, or financial field is approved at this stage. Their subject matter may exist before release, but the current dataset does not prove that the recorded values represent the state available on T−1. Pilot AUC results were not used to determine eligibility.

## 1. Decision scope

The prediction cutoff is **T−1: the calendar day immediately before theatrical release**. This audit distinguishes four different claims:

1. a field exists in the dataset;
2. the underlying fact might theoretically be known before release;
3. the recorded value is supported as a T−1 representation by current provenance; and
4. the field is approved for the formal pre-release model.

Only fields reaching the fourth standard are formal X. Fields with unresolved time snapshots, definitions, provenance, or representations remain outside the formal model even if they appeared useful in exploratory screening.

## 2. Evidence reviewed

- `data/processed/movie_sequel_features_v1.csv` — 6,481 rows × 50 columns; SHA256 `a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6`.
- `reports/movie_sequel_feature_engineering_spec_v1.2.md`.
- `reports/movie_sequel_feature_registry_v1.2.csv`.
- `reports/movie_sequel_association_eda_spec_v1.md`.
- `reports/pre_release_feature_screening_registry_v1.csv`.
- `reports/pre_release_feature_screening_report_v1.md`.

The 50-column input schema was used as the registry boundary. No internet source, external join, new feature, new EDA, or new model was used.

## 3. Final classification summary

| Final decision | Fields | Meaning |
|---|---:|---|
| `FINAL_INCLUDE` | 4 | Approved in both Model A and Model B |
| `SENSITIVITY_INCLUDE` | 2 | Included in Model A; jointly omitted in Model B because of coupling concerns |
| `PROVENANCE_REVIEW` | 18 | Theoretically relevant but not approved without T−1 provenance/representation evidence |
| `EXCLUDE_LEAKAGE` | 10 | Post-release, target-derived, or outcome-adjacent information |
| `EXCLUDE_IDENTITY` | 6 | Identity/grouping fields, retained outside X |
| `EXCLUDE_REFERENCE` | 9 | Legacy, provenance, status, or duplicate raw-source representation |
| `EXCLUDE_UNSUITABLE` | 1 | No defensible current T−1 use |

Each of the 50 input columns appears exactly once in the machine-readable registry.

## 4. FINAL MODEL A FEATURES

Formal Model A should use exactly:

1. `sequel_number`
2. `release_year`
3. `previous_rating`
4. `previous_rating_votes`
5. `years_since_previous`
6. `previous_runtime`

Interpretation constraints:

- `release_year` is a **temporal control / temporal context**, not a movie-content feature and not a causal exposure.
- `previous_rating` is a predecessor/baseline rating mathematically coupled to Y because Y uses current rating minus previous rating. It may be used for prediction but not given a causal interpretation; regression-to-the-mean must be discussed.
- `previous_rating_votes` is retained with predecessor-rating information. It is not evidence that vote volume causes decline.
- All six fields use the implemented English aliases, not duplicate Chinese source columns.

## 5. SENSITIVITY MODEL B FEATURES

Model B should use exactly:

1. `sequel_number`
2. `release_year`
3. `years_since_previous`
4. `previous_runtime`

Model B jointly omits `previous_rating` and `previous_rating_votes`. Its purpose is to show how results change without the mathematically coupled predecessor-rating information. Model A versus Model B must not be presented as proof of feature importance or causality.

## 6. PROVENANCE REVIEW FEATURES

The following 18 existing fields are not approved for formal preprocessing yet:

- Calendar/genre: `上映日期`, `類型`.
- Current production metadata: `片長(分鐘)`.
- Person identities: `導演`, `前作導演`, `主演1`, `主演2`, `主演3`.
- Continuity: `導演是否更換`, `主演是否更換`, `與前作共同主演數`.
- Runtime change: `與前作片長差`, `片長變化率`.
- Financial: `預算`, `前作預算`, `與前作預算差`, `預算變化率`, `前作票房`.

To advance later, these fields require evidence that the recorded value represents what was available by T−1. Person-name and genre fields additionally require an approved model representation. Financial fields require currency, unit, geography, definition, source, row-level provenance, and snapshot timing. Prior feature-screening AUC does not satisfy these requirements.

## 7. LEAKAGE EXCLUSIONS

These 10 fields are prohibited as pre-release X:

- Current outcomes/updates: `平均評分`, `評分人數`, `人氣`, `票房`.
- Outcome-derived values: `與前作評分差`, `評分樣本是否足夠`, `與前作票房差`, `票房變化率`.
- Target/eligibility: `rating_valid`, `rating_drop`.

`rating_drop` remains the formal Y; exclusion here means exclusion from X only.

## 8. IDENTITY / REFERENCE EXCLUSIONS

Identity/grouping exclusions:

- `電影系列`, `電影系列ID`, `電影名稱`, `中文片名`, `TMDB ID`, `IMDb ID`.

`電影系列ID` must remain available as the franchise-aware validation grouping key, but is never X.

Reference-only exclusions:

- Duplicate raw source fields represented by canonical aliases: `第幾部`, `上映年`, `前作評分`, `前作評分人數`, `與前作上映間隔(年)`, `前作片長`.
- Metadata/reference: `口碑是否下滑`, `資料來源`, `target_status`.

The duplicate source fields are not rejected substantively; their exact English aliases are used to avoid duplicated predictors. `口碑是否下滑` remains a legacy reference and is neither formal X nor Y.

## 9. Unsuitable field

`系列總部數` is excluded because it has no as-of-T−1 definition and may include installments released after the focal movie. Current group size or maximum sequel number must not be substituted.

## 10. Readiness for preprocessing

**Decision: YES — the existing data is sufficient to enter formal preprocessing specification.**

This approval is limited to the Model A and Model B field lists above. The preprocessing specification must:

1. preserve the fixed `rating_drop` definition and target-eligible population rule;
2. define missing-data handling using training data only;
3. preserve a time-based validation design;
4. preserve `電影系列ID` solely for franchise-aware robustness grouping;
5. prevent all leakage, identity, and reference exclusions from entering X;
6. keep Model A and Model B as prespecified complementary analyses;
7. avoid causal interpretation of `previous_rating` and `release_year`;
8. leave all `PROVENANCE_REVIEW` fields outside formal preprocessing until separately approved.

No additional feature construction or model experiment is required before drafting that preprocessing specification.

## Final answers

1. **Formal Model A X:** `sequel_number`, `release_year`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, `previous_runtime`.
2. **Sensitivity Model B X:** `sequel_number`, `release_year`, `years_since_previous`, `previous_runtime`.
3. **Temporarily unusable:** all `PROVENANCE_REVIEW`, `EXCLUDE_LEAKAGE`, `EXCLUDE_IDENTITY`, `EXCLUDE_REFERENCE`, and `EXCLUDE_UNSUITABLE` fields listed above.
4. **May enter only after future provenance approval:** calendar/genre representation, current runtime and runtime changes, director/cast identities and continuity, budgets and predecessor box office.
5. **Ready for formal preprocessing:** **YES**, strictly for the approved Model A/Model B feature sets.

**STATUS = T1_FEATURE_AVAILABILITY_DECISION_COMPLETE**
