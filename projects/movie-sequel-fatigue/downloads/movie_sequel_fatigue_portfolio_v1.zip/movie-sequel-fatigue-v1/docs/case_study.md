# Case Study：電影續集疲乏

## 1. 從問題出發，而不是從模型出發

本研究拆分兩個問題：RQ1 是哪些特徵與 recorded 評分變化有關；RQ2 是上映前一天能否預測口碑下滑。前者是 retrospective association，後者需要時間可用性證據，不能共享不受限制的 feature set。兩者皆不是因果推論。

## 2. 資料信任建立

主檔 42 欄經受控轉換成 44 欄，再保留原始欄位建立六個 aliases，得到 50 欄。評分 0 的語意不能武斷視為真實評分或任意補值，因此有效 outcome population 固定要求兩邊評分大於 0，且 recorded 差值非缺失。資料列仍保留，不在來源資料中刪除。

6,481 筆原始紀錄中，4,058 組有效；口碑下滑 2,014 組、未下滑 2,044 組。這個區分避免把首集或無有效前作評分的資料當成負類。

## 3. EDA 告訴我們什麼

既有 EDA 顯示第二部的下滑比例約 55.2%，第三部約 46.3%，第四部約 47.8%，第五部以上約 40.2%。這不是單調遞增，也不能推論後期續集更安全：能持續拍攝的系列可能與停止拍攝的系列不同。

![缺失值概況](../assets/04_missingness_overview.png)

資料來源與時期組成不同，必須一起報告。不同來源的差異不是來源「造成」評分變化。預算／票房缺乏足夠幣別、地域與 gross definition 證據，因此沒有強行變成正式預測特徵。

## 4. 預測路線

六個 Model A 欄位代表系列位置、時間背景與前作基線。release_year 是 temporal context，不是電影內容因素。current rating、current votes、popularity、票房、rating change 與 target flags 不進 X；系列 ID 只作識別／群組用途。

分類 Model B 移除 previous_rating 與 previous_rating_votes，作預先定義的 sensitivity。Model C 額外使用導演更換、主演更換、共同主演數、片長差與片長變化率，但其 T−1 provenance 未確認，只能視為受限制的研究實驗。

Random Forest 調參使用 144 組參數與 training-only 5-fold TimeSeriesSplit。既有 P2 最佳設定為 500 棵樹、depth=8、min_samples_leaf=20、min_samples_split=10、max_features=sqrt。leaf=20 是每葉最少樣本數，不是 20 個節點。

P2 train AUC 由原始 RF 的 1.000 降到約 0.812，test AUC 由約 0.625 升到約 0.645。這顯示過度擬合落差縮小，但不是部署效益、統計顯著改善或最佳模型的證明；也不能因最高 AUC 就忽略 AP、Brier、calibration 與樣本組成。

## 5. 補充關聯分析，而非用另一個模型挽救分數

連續型 Y 沿用 recorded 與前作評分差。OLS LR-A 使用六個基線 X；LR-B **只移除 previous_rating**，仍保留 previous_rating_votes。這與分類 Model B 不同，不能混用名稱。

兩者 n=3,991；LR-A R²=0.15356，LR-B R²=0.03183。這些是 in-sample fit，不可與 out-of-time AUC 比大小。Y 本身包含減去前作評分，所以 previous_rating 的訊號有 mathematical coupling 與 regression-to-the-mean concern，不能直接解讀為實質或因果重要性。

![LR-A 診斷](../assets/lr_a_diagnostics.png)

既有診斷包括異質變異、厚尾、高影響值與同系列重複觀測。p-value 小不等於效果大；R² 低也不代表所有關聯不存在。應同時閱讀係數、信賴區間、穩健標準誤與兩個 sensitivity 規格。

## 6. 可交付的 insight 與界線

1. 「续集疲乏」不能只用越拍越差概括；樣本階段與系列存續背景需納入解釋。
2. 前作基線帶來訊號，但有數學耦合，不能當成創作決策的因果指南。
3. 現有結構化欄位的 out-of-time 能力有限，尚不足以支持自動投資／行銷決策。
4. 票房、預算與製作延續性需要各自的定義與 provenance，不能為增加變數數量就納入。
5. 對資料限制和不支持的結論保持透明，是本作品集的重要成果。

本包裝不新增分析，系列平均／最高集等僅有 feasibility 的工作也不列為已完成研究發現。
