# 證據與程式索引

以下檔案為既有研究副本，不表示本次重新執行；歷史文件內的連結可能需要完整原 workspace。

| 原研究相對路徑 | 本包副本 |
|---|---|
| `src/transform_movie_sequel_analysis_v1.py` | [開啟](../research_reference/src/transform_movie_sequel_analysis_v1.py) |
| `src/build_movie_sequel_features_v1.py` | [開啟](../research_reference/src/build_movie_sequel_features_v1.py) |
| `src/build_ml_preprocessing_v1.py` | [開啟](../research_reference/src/build_ml_preprocessing_v1.py) |
| `src/run_movie_sequel_association_eda_v1.py` | [開啟](../research_reference/src/run_movie_sequel_association_eda_v1.py) |
| `src/run_logistic_regression_v1.py` | [開啟](../research_reference/src/run_logistic_regression_v1.py) |
| `src/run_logistic_regression_tuned_v1.py` | [開啟](../research_reference/src/run_logistic_regression_tuned_v1.py) |
| `src/run_random_forest_v1.py` | [開啟](../research_reference/src/run_random_forest_v1.py) |
| `src/run_random_forest_tuned_v1.py` | [開啟](../research_reference/src/run_random_forest_tuned_v1.py) |
| `src/run_model_c_continuity_v1.py` | [開啟](../research_reference/src/run_model_c_continuity_v1.py) |
| `src/run_final_xgboost_v1.py` | [開啟](../research_reference/src/run_final_xgboost_v1.py) |
| `src/run_rating_change_linear_regression_v1.py` | [開啟](../research_reference/src/run_rating_change_linear_regression_v1.py) |
| `reports/logistic_regression_v1_results.csv` | [開啟](../reports/logistic_regression_v1_results.csv) |
| `reports/random_forest_v1_results.csv` | [開啟](../reports/random_forest_v1_results.csv) |
| `reports/model_c_continuity_results.csv` | [開啟](../reports/model_c_continuity_results.csv) |
| `reports/final_xgboost_results.csv` | [開啟](../reports/final_xgboost_results.csv) |
| `reports/logistic_regression_tuned_v1_results.csv` | [開啟](../reports/logistic_regression_tuned_v1_results.csv) |
| `reports/random_forest_tuned_v1_results.csv` | [開啟](../reports/random_forest_tuned_v1_results.csv) |
| `reports/rating_change_linear_regression_results.csv` | [開啟](../reports/rating_change_linear_regression_results.csv) |
| `reports/rating_change_linear_regression_coefficients.csv` | [開啟](../reports/rating_change_linear_regression_coefficients.csv) |
| `reports/figures/movie_sequel_eda_v1/04_missingness_overview.png` | [開啟](../assets/04_missingness_overview.png) |
| `reports/figures/movie_sequel_eda_v1/05_rating_change_distribution.png` | [開啟](../assets/05_rating_change_distribution.png) |
| `reports/figures/movie_sequel_eda_v1/06_rating_drop_distribution.png` | [開啟](../assets/06_rating_drop_distribution.png) |
| `reports/figures/movie_sequel_eda_v1/09_sequel_group_drop_prevalence.png` | [開啟](../assets/09_sequel_group_drop_prevalence.png) |
| `reports/figures/movie_sequel_eda_v1/15_source_robustness.png` | [開啟](../assets/15_source_robustness.png) |
| `reports/figures/rating_change_linear_regression_v1/lr_a_diagnostics.png` | [開啟](../assets/lr_a_diagnostics.png) |
| `reports/logistic_regression_v1_manifest.json` | [開啟](../evidence/environments/logistic_regression_v1_manifest.json) |
| `reports/random_forest_tuned_v1_manifest.json` | [開啟](../evidence/environments/random_forest_tuned_v1_manifest.json) |
| `reports/final_xgboost_manifest.json` | [開啟](../evidence/environments/final_xgboost_manifest.json) |
| `reports/rating_change_linear_regression_v1_manifest.json` | [開啟](../evidence/environments/rating_change_linear_regression_v1_manifest.json) |
| `reports/movie_sequel_feature_engineering_spec_v1.2.md` | [開啟](../evidence/research/movie_sequel_feature_engineering_spec_v1.2.md) |
| `reports/t1_feature_availability_decision_v1.md` | [開啟](../evidence/research/t1_feature_availability_decision_v1.md) |
| `reports/ml_preprocessing_spec_v1.md` | [開啟](../evidence/research/ml_preprocessing_spec_v1.md) |
| `reports/movie_sequel_association_eda_v1.md` | [開啟](../evidence/research/movie_sequel_association_eda_v1.md) |
| `reports/explanatory_candidate_feature_gate_review_v1.md` | [開啟](../evidence/research/explanatory_candidate_feature_gate_review_v1.md) |
