# 重現與程式使用說明

## 可立即檢查的部分

在此作品集根目錄執行 `python3 verify_package.py`：只核對封裝檔案 SHA256，不會讀取資料、訓練模型或呼叫網路。

`reports/` 是既有結果副本；`assets/` 是既有圖表；`research_reference/src/` 是精選歷史程式，供方法審閱。來源與封裝 hash 記錄於 `package_manifest.json`。這不是新的結果執行紀錄。

## 重現研究的前提

原始資料不隨包提供，先取得合法且獲授權的完整研究 workspace。既有正式輸入為 `data/processed/movie_sequel_features_v1.csv`，6,481 × 50，SHA256 `a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6`。

不要在缺少完整依賴檔案時直接批次執行參考腳本。腳本會產生／覆寫其指定 reports；本包故意將其放在 research_reference，並未宣稱已完成乾淨環境的 end-to-end 重現。需要完整原專案的 spec、registry、先前結果與相容套件後，才可在獨立工作副本按階段執行。

## 歷史環境

`evidence/environments/` 收錄既有 manifest 的套件版本與參數證據；不同實驗可能使用不同環境，不應誤當成單一 lockfile。先核對對應實驗的 Python、numpy、pandas、scipy、scikit-learn、statsmodels、matplotlib、xgboost 版本。

## 重現契約

- 不變更資料 hash、Y、特徵順序、時間 split 或 seed。
- CV preprocessing 只 fit 對應 training fold；outer test 不選參數。
- 整理作品集沒有重新執行任何模型；腳本僅做語法檢查。
- 比較 tables、probabilities、parameters 的 deterministic 結果；時間戳不是分析數值。
- 有關資料授權、團隊著作與完整計算環境，參見公開前檢查表。
