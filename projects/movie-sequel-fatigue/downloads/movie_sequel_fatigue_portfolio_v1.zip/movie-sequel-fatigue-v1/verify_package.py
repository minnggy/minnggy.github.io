"""Offline integrity verification only. No research execution."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'package_manifest.json').read_text(encoding='utf-8'))
for item in manifest['files']:
    path = root / item['path']
    assert path.is_file(), f"Missing: {item['path']}"
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == item['sha256'], f"Changed: {item['path']}"
print(f"PASS: {len(manifest['files'])} packaged files verified. No models executed.")
