# 資料取得

本資料夾不包含原始或 processed dataset。不得用模擬資料冒充正式結果的輸入。

正式輸入：movie_sequel_features_v1.csv，6,481 rows × 50 columns。
SHA256：a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6

本包只展示既有彙總結果與圖表。取得權利人授權後，才能另行提供研究資料；確認授權前不建立公開下載連結。
