# 電影續集疲乏：從資料品質到預測邊界

> 一個以可追溯資料處理、時間外推驗證與審慎解釋為核心的資料分析作品集。

## 30 秒看懂這個專案

**問題：**哪些電影／系列特徵與續集口碑變化有關？是否能在上映前預測口碑下滑？

**資料：**6,481 筆電影紀錄、50 欄；其中 4,058 組具有有效前後作評分，2,014 組符合口碑下滑定義。6,481 並不等於有效續集比較組數。

**結果：**既有調參後 Random Forest P2 的 out-of-time ROC-AUC 約 **0.6453**；預測訊號有限，不足以宣稱可部署。連續型評分變化回歸的 R² 為 **0.1536 / 0.0318**，揭示前作評分的數學耦合與模型解釋限制，而不是證明機器學習普遍無效。

**展示能力：**資料品質審查 → 不可變資料與 SHA256 → 防止時間／目標洩漏 → 可重現特徵處理 → 時間切分與 train-only preprocessing → 模型評估 → 關聯分析與限制。

## 閱讀順序

1. [完整案例與研究洞察](docs/case_study.md)
2. [結果表與程式索引](docs/evidence_index.md)
3. [重現說明](docs/reproducibility.md)
4. [個人貢獻待確認](docs/contributions.md)／[公開前檢查](docs/publication_checklist.md)

## 探索性資料分析

![評分變化分布；固定 -0.2 定義](assets/05_rating_change_distribution.png)

![各續集階段的下滑比例](assets/09_sequel_group_drop_prevalence.png)

以上為既有分析圖，沒有重新分析或調整分組。第二部在樣本中的下滑比例較高，不代表集數造成下滑，也不支持「愈拍愈差」的簡單結論。

## 特徵工程不是把所有欄位轉成數字

第一版只建立六個 **exact value-preserving aliases**，保留缺失與原值，不重算配對、不編碼、不補值。變數依研究語意與可用性決策選定，並非依 p-value 或 test AUC 自動篩選。

| 英文欄位 | 原始欄位 |
|---|---|
| sequel_number | 第幾部 |
| release_year | 上映年 |
| previous_rating | 前作評分 |
| previous_rating_votes | 前作評分人數 |
| years_since_previous | 與前作上映間隔(年) |
| previous_runtime | 前作片長 |

Model A 使用六欄；分類 Model B 移除前作評分與評分人數；Model C 加入五個製作延續性欄位，僅屬 **provenance-limited experiment**，不能宣稱已通過 T−1 snapshot 審查。

## 如何評估

- Y 固定：有效評分組的 recorded 評分差 ≤ −0.2；invalid target 保持缺失。
- Train ≤ 2020、Test ≥ 2021；2026 為不完整年度。
- P1 complete-case；P2 train-only median、train-defined missing indicators 與 train-only scaling。
- 比較 Logistic、Random Forest、XGBoost；受控調參僅在 training 的時間序列 CV 進行。
- 同時報告 ROC-AUC、Average Precision、Brier 與 calibration，不只挑最高 AUC。

完整數值見 [彙整比較表](reports/portfolio_model_comparison.csv)。P1/P2 及 Model C 的樣本可能不同，不能將分數差直接視為已證實的增益。反覆使用同一 test cohort，也使其不等同新的獨立確認樣本。

## 結論與商業意涵

目前資料更適合作為**研究與風險討論的依據**，不宜直接成為電影投資、續集立項或行銷預算配置的自動決策工具。評分下滑不等同票房或獲利下滑；本研究不能估計 ROI。可信的分析成果也包括知道何時不應把模型投入使用。

## 使用範圍

本包裝為既有成果整理，沒有重新訓練模型。原始資料、逐筆預測與人物／電影明細未打包。程式是歷史研究參考副本，不是已驗證的可安裝產品；詳見重現說明。公開前仍須確認資料、圖表、團隊貢獻及程式授權。本作品集尚未上傳或公開。
