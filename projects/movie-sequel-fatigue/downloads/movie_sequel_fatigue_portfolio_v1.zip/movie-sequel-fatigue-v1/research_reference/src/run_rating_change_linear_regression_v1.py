#!/usr/bin/env python3
"""Prespecified continuous-outcome association analysis; source is immutable."""
from pathlib import Path
from datetime import datetime, timezone
from decimal import Decimal
import os, json, hashlib, platform, tempfile
os.environ.setdefault('MPLCONFIGDIR', tempfile.mkdtemp(prefix='rating-change-mpl-'))
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import numpy as np
import pandas as pd
import scipy
from scipy import stats
import statsmodels
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_breuschpagan
from statsmodels.stats.stattools import jarque_bera
from statsmodels.stats.outliers_influence import variance_inflation_factor
from statsmodels.stats.multitest import multipletests
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
REPORTS=ROOT/'reports'
INPUT=ROOT/'data/processed/movie_sequel_features_v1.csv'
SHA='a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6'
SPEC=REPORTS/'rating_change_linear_regression_spec_v1.md'
PREFIX='rating_change_linear_regression'
FEATURES=['sequel_number','release_year','previous_rating','previous_rating_votes','years_since_previous','previous_runtime']
MODELS={'LR-A':FEATURES,'LR-B':[x for x in FEATURES if x!='previous_rating']}
SOURCES={'sequel_number':'第幾部','release_year':'上映年','previous_rating':'前作評分','previous_rating_votes':'前作評分人數','years_since_previous':'與前作上映間隔(年)','previous_runtime':'前作片長'}
Y='與前作評分差'
EVIDENCE={
 'audit':'reports/rating_y_audit/rating_y_audit_correlation.csv',
 'eda':'reports/tables/movie_sequel_eda_v1/core_numeric_associations.csv',
 'logistic':'reports/logistic_regression_v1_coefficients.csv',
 'rf':'reports/random_forest_tuned_v1_feature_importance.csv',
 'xgb':'reports/final_xgboost_feature_importance.csv',
 'eda_spec':'reports/movie_sequel_association_eda_spec_v1.md',
 'eda_report':'reports/movie_sequel_association_eda_v1.md',
 'preprocessing':'reports/ml_preprocessing_spec_v1.md',
 'feature_decision':'reports/t1_feature_availability_decision_v1.md',
 'logistic_results':'reports/logistic_regression_v1_results.csv',
 'rf_results':'reports/random_forest_tuned_v1_results.csv',
 'xgb_results':'reports/final_xgboost_results.csv',
}
VERSIONS={k:v for k,v in [('python',platform.python_version()),('numpy',np.__version__),('pandas',pd.__version__),('scipy',scipy.__version__),('statsmodels',statsmodels.__version__),('matplotlib',matplotlib.__version__)]}

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def table(d):
    d=d.copy()
    for c in d:
        if pd.api.types.is_float_dtype(d[c]): d[c]=d[c].map(lambda v: '' if pd.isna(v) else f'{v:.5g}')
    return '\n'.join(['| '+' | '.join(d.columns)+' |','|'+'|'.join(['---']*len(d.columns))+'|']+['| '+' | '.join(str(v).replace('|','/') for v in r)+' |' for r in d.itertuples(index=False,name=None)])

def gate():
    assert sha(INPUT)==SHA,'CRITICAL input SHA mismatch'
    raw=pd.read_csv(INPUT,dtype=str,keep_default_na=False,encoding='utf-8-sig')
    assert raw.shape==(6481,50),'CRITICAL input shape'
    vals=raw[['平均評分','前作評分',Y]].replace('',np.nan).apply(pd.to_numeric,errors='raise')
    clean=(vals['平均評分']>0)&(vals['前作評分']>0)&vals[Y].notna()
    assert np.isfinite(vals.loc[clean]).all().all()
    assert clean.equals(raw.rating_valid.eq('TRUE')),'CLEAN disagrees with existing validity'
    assert clean.sum()==4058,'CRITICAL CLEAN n !=4058'
    for i in raw.index:
        expected=('1' if Decimal(raw.loc[i,Y])<=Decimal('-.2') else '0') if clean[i] else ''
        assert raw.loc[i,'rating_drop']==expected,'CRITICAL recorded target logic'
    assert raw.loc[clean,'rating_drop'].value_counts().to_dict()=={'0':2044,'1':2014}
    assert raw['TMDB ID'].ne('').all() and not raw['TMDB ID'].duplicated().any()
    assert not raw.loc[raw['IMDb ID'].ne(''),'IMDb ID'].duplicated().any()
    for f,s in SOURCES.items(): assert raw[f].equals(raw[s]),f'alias mismatch {f}'
    d=raw.loc[clean].copy()
    for col in FEATURES+[Y]: d[col]=pd.to_numeric(d[col].replace('',np.nan),errors='raise')
    assert d['電影系列ID'].ne('').all()
    return raw,d

def estimate(d):
    results=[]; coefs=[]; diagnostics=[]; missing=[]; observations=[]; fits={}; checks=[]
    for name,features in MODELS.items():
        for f in features:
            missing.append(dict(model=name,feature=f,clean_n=len(d),missing_count=int(d[f].isna().sum()),missing_rate=float(d[f].isna().mean()),nonfinite_nonmissing=int((d[f].notna()&~np.isfinite(d[f])).sum())))
        mask=np.isfinite(d[features]).all(axis=1)
        sample=d.loc[mask].copy(); n=len(sample); y=sample[Y]
        x=sm.add_constant(sample[features],has_constant='add')
        rank=np.linalg.matrix_rank(x); assert rank==x.shape[1]
        fit=sm.OLS(y,x).fit()
        hc=fit.get_robustcov_results(cov_type='HC3',use_t=True)
        groups=sample['電影系列ID']; g=groups.nunique()
        cluster=fit.get_robustcov_results(cov_type='cluster',groups=groups,use_correction=True,df_correction=True,use_t=True)
        influence=fit.get_influence(); cook=influence.cooks_distance[0]; lev=influence.hat_matrix_diag
        student=influence.resid_studentized_internal
        z=(sample[features]-sample[features].mean())/sample[features].std(ddof=1)
        zx=sm.add_constant(z); alt=np.linalg.lstsq(zx.to_numpy(),y.to_numpy(),rcond=None)[0]
        maxdiff=float(np.max(np.abs(zx.to_numpy()@alt-fit.fittedvalues)))
        assert maxdiff<1e-8,'independent OLS fitted-value mismatch'
        assert abs(np.sum(fit.resid))<1e-6
        bp=het_breuschpagan(fit.resid,zx,robust=True)
        jb=jarque_bera(fit.resid)
        results.append(dict(model=name,n=n,clean_n=len(d),excluded_missing_or_nonfinite=len(d)-n,features=json.dumps(features),y=Y,
            r_squared=fit.rsquared,adjusted_r_squared=fit.rsquared_adj,f_statistic=fit.fvalue,overall_p_value=fit.f_pvalue,
            df_model=fit.df_model,df_residual=fit.df_resid,hc3_f_statistic=float(hc.fvalue),hc3_overall_p_value=float(hc.f_pvalue),
            residual_standard_error=np.sqrt(fit.ssr/fit.df_resid),rmse=np.sqrt(np.mean(fit.resid**2)),mae=np.mean(np.abs(fit.resid)),
            sse=fit.ssr,y_mean=y.mean(),y_sd=y.std(ddof=1),y_min=y.min(),y_max=y.max(),franchise_groups=g,evaluation_scope='IN_SAMPLE_ASSOCIATION'))
        for j,f in enumerate(x.columns):
            vif=float(variance_inflation_factor(zx.to_numpy(),j)) if j else np.nan
            row=dict(model=name,n=n,feature='Intercept' if f=='const' else f,coefficient=fit.params.iloc[j],
                std_error=fit.bse.iloc[j],t_statistic=fit.tvalues.iloc[j],p_value=fit.pvalues.iloc[j],
                ci_lower=fit.conf_int().iloc[j,0],ci_upper=fit.conf_int().iloc[j,1],
                standardized_beta=fit.params.iloc[j]*sample[f].std(ddof=1)/y.std(ddof=1) if j else np.nan,
                vif=vif,scale_definition='RATING_CHANGE_POINTS_PER_RAW_X_UNIT' if j else 'INTERCEPT',
                hc3_std_error=hc.bse[j],hc3_t=hc.tvalues[j],hc3_p=hc.pvalues[j],hc3_ci_lower=hc.conf_int()[j,0],hc3_ci_upper=hc.conf_int()[j,1],
                cluster_std_error=cluster.bse[j],cluster_t=cluster.tvalues[j],cluster_p=cluster.pvalues[j],cluster_ci_lower=cluster.conf_int()[j,0],cluster_ci_upper=cluster.conf_int()[j,1],cluster_inference_df=g-1)
            coefs.append(row)
            if j: diagnostics.append(dict(model=name,n=n,diagnostic='VIF',feature=f,value=vif,p_value=np.nan,status='WARNING' if vif>5 else 'PASS',criterion='VIF > 5 review heuristic'))
        for key,value,p,status,criterion in [
            ('Design rank',rank,np.nan,'PASS',f'{x.shape[1]} columns incl intercept'),
            ('Independent least-squares fitted difference',maxdiff,np.nan,'PASS','absolute difference <1e-8'),
            ('Koenker Breusch-Pagan LM',bp[0],bp[1],'WARNING' if bp[1]<.05 else 'PASS','p<.05 variance diagnostic; no deletion'),
            ('Jarque-Bera',jb[0],jb[1],'WARNING' if jb[1]<.05 else 'PASS','p<.05 normality diagnostic; inspect Q-Q'),
            ('Cook D above 4/N',int((cook>4/n).sum()),np.nan,'WARNING' if (cook>4/n).any() else 'PASS',f'review threshold={4/n}'),
            ('Max Cook D',float(cook.max()),np.nan,'WARNING' if cook.max()>4/n else 'PASS','not automatic error/outlier exclusion'),
            ('High leverage',int((lev>2*x.shape[1]/n).sum()),np.nan,'WARNING','h >2p/N review heuristic'),
            ('Abs studentized residual >3',int((np.abs(student)>3).sum()),np.nan,'WARNING' if (np.abs(student)>3).any() else 'PASS','review only'),
            ('Repeated franchise observations',int(n-g),np.nan,'WARNING','cluster-robust uncertainty supplement'),
            ('Residual skewness',jb[2],np.nan,'WARNING' if abs(jb[2])>1 else 'PASS','shape descriptor'),
            ('Residual kurtosis',jb[3],np.nan,'WARNING' if abs(jb[3]-3)>1 else 'PASS','normal reference=3; shape descriptor'),
        ]: diagnostics.append(dict(model=name,n=n,diagnostic=key,feature='',value=value,p_value=p,status=status,criterion=criterion))
        obs=sample[['TMDB ID','IMDb ID','電影系列ID','電影系列','電影名稱','上映日期',Y]].copy()
        obs.insert(0,'source_csv_row',sample.index+2);obs.insert(0,'model',name);obs.insert(1,'n',n)
        obs['fitted']=fit.fittedvalues;obs['residual']=fit.resid;obs['studentized_residual']=student;obs['leverage']=lev;obs['cooks_distance']=cook
        obs['review_cook']=cook>4/n;obs['review_leverage']=lev>2*x.shape[1]/n
        observations.append(obs.reset_index(drop=True))
        fits[name]=(fit,sample,x,student,cook,lev)
    coefs=pd.DataFrame(coefs)
    for p,q in [('p_value','bh_q_11_coefficients'),('hc3_p','hc3_bh_q_11_coefficients'),('cluster_p','cluster_bh_q_11_coefficients')]:
        use=coefs.feature.ne('Intercept');coefs.loc[use,q]=multipletests(coefs.loc[use,p],method='fdr_bh')[1]
    assert fits['LR-A'][1].index.equals(fits['LR-B'][1].index),'models differ in CC sample'
    return {'results':pd.DataFrame(results),'coefficients':coefs,'diagnostics':pd.DataFrame(diagnostics),'missingness':pd.DataFrame(missing),'observations':pd.concat(observations,ignore_index=True)},fits

def integrate(d,coefs):
    old={k:pd.read_csv(ROOT/EVIDENCE[k],encoding='utf-8-sig') for k in ['audit','eda','logistic','rf','xgb']}
    existing_results={k:pd.read_csv(ROOT/EVIDENCE[k+'_results'],encoding='utf-8-sig') for k in ['logistic','rf','xgb']}
    summary=[];integrated=[]
    for f in FEATURES:
        pair=d[[f,Y]].dropna();rho,p=stats.spearmanr(pair[f],pair[Y])
        oldname='previous_vote_count' if f=='previous_rating_votes' else f
        audit=old['audit'].loc[old['audit'].variable.eq(oldname)]
        reused='NOT_AVAILABLE_IN_PRIOR_CLEAN_TABLE'
        if len(audit):
            assert int(audit.iloc[0].clean_n)==len(pair)
            assert np.isclose(audit.iloc[0].clean_rho,rho,rtol=0,atol=1e-12)
            reused=EVIDENCE['audit']
        row={'feature':f,'spearman_with_rating_change':rho,'spearman_n':len(pair),'spearman_p':p,'prior_clean_spearman_source':reused,'spearman_population':'CLEAN_PAIRWISE'}
        for model in MODELS:
            found=coefs[(coefs.model==model)&(coefs.feature==f)]
            for col in ['coefficient','ci_lower','ci_upper','p_value','hc3_ci_lower','hc3_ci_upper','hc3_p','cluster_ci_lower','cluster_ci_upper','cluster_p','standardized_beta']:
                row[model+'_'+col]=float(found.iloc[0][col]) if len(found) else np.nan
        row['interpretation']='Y beta positive = less-negative change; binary OR>1 = greater drop odds; scales/sample/adjustment differ'
        if f=='previous_rating':row['interpretation']='MATHEMATICAL_COUPLING; omitted only from LR-B; regression-to-mean concern; not causal'
        summary.append(row)
        ed=old['eda'][old['eda'].x_variable.eq(f)]
        for strategy in ['P1','P2']:
            log=old['logistic'][(old['logistic'].model=='Model A')&(old['logistic'].preprocessing==strategy)&(old['logistic'].feature==f)]
            rf=old['rf'][(old['rf'].preprocessing==strategy)&(old['rf'].feature==f)&(old['rf'].importance_type=='TEST_PERMUTATION_ROC_AUC')]
            xb=old['xgb'][(old['xgb'].preprocessing==strategy)&(old['xgb'].feature==f)&(old['xgb'].importance_type=='GAIN')]
            assert len(log)==len(rf)==len(xb)==1
            lr_n=existing_results['logistic'].query("model == 'Model A' and preprocessing == @strategy and split == 'TRAIN'").iloc[0]['n']
            rf_n=existing_results['rf'].query("preprocessing == @strategy and split == 'TEST'").iloc[0]['n']
            xb_train_n=existing_results['xgb'].query("preprocessing == @strategy and split == 'TRAIN'").iloc[0]['n']
            integrated.append(dict(feature=f,preprocessing=strategy,continuous_spearman=rho,continuous_spearman_n=len(pair),
                eda_binary_spearman=ed.iloc[0].spearman_rho if len(ed) else np.nan,
                eda_unadjusted_or=ed.iloc[0].odds_ratio if len(ed) else np.nan,eda_or_unit=ed.iloc[0].logistic_unit if len(ed) else np.nan,
                logistic_model='Existing Model A; training-only standardized X',logistic_or=log.iloc[0].odds_ratio,logistic_or_low=log.iloc[0].odds_ratio_ci_lower,logistic_or_high=log.iloc[0].odds_ratio_ci_upper,
                rf_test_permutation=rf.iloc[0].importance,rf_permutation_sd=rf.iloc[0].importance_std,
                xgboost_model='Model C 11 X + permitted missing indicators; provenance-limited',xgboost_gain=xb.iloc[0].importance,xgboost_normalized_gain=xb.iloc[0].normalized_importance,
                lr_a_beta=row['LR-A_coefficient'],lr_b_beta=row['LR-B_coefficient'],lr_population='ALL_YEAR_CLEAN_COMPLETE_CASE_3991',
                logistic_coefficient_train_n=int(lr_n),rf_permutation_test_n=int(rf_n),xgboost_gain_train_n=int(xb_train_n),
                eda_source=EVIDENCE['eda'],logistic_source=EVIDENCE['logistic'],rf_source=EVIDENCE['rf'],xgboost_source=EVIDENCE['xgb'],
                comparability='No magnitude ranking across metrics; importance has no signed direction; reused prior results, no refit'))
    return pd.DataFrame(summary),pd.DataFrame(integrated)

def plots(fits,diag,outdir,meta):
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    paths=[]
    for name,(fit,sample,x,student,cook,lev) in fits.items():
        fig,axs=plt.subplots(2,3,figsize=(16,9),layout='constrained');n=len(sample)
        a=axs[0,0];a.scatter(fit.fittedvalues,fit.resid,s=8,alpha=.35,color='#315a86');a.axhline(0,color='#555',lw=1)
        smoothed=sm.nonparametric.lowess(fit.resid,fit.fittedvalues,frac=.3,return_sorted=True)
        a.plot(smoothed[:,0],smoothed[:,1],color='#be7627',lw=1.8,label='LOWESS diagnostic');a.legend();a.set(title='Residual vs fitted',xlabel='Fitted rating change (points)',ylabel='Residual (points)')
        a=axs[0,1];a.hist(fit.resid,bins=45,color='#315a86',edgecolor='white');a.set(title='Residual distribution',xlabel='Residual (points)',ylabel='Count')
        a=axs[0,2];sm.qqplot(fit.resid,line='s',ax=a,marker='.',markersize=3,color='#315a86');a.set(title='Normal Q-Q',xlabel='Theoretical normal quantile',ylabel='Ordered residual (points)')
        a=axs[1,0];a.scatter(fit.fittedvalues,np.sqrt(np.abs(student)),s=8,alpha=.35,color='#315a86');a.set(title='Scale-location',xlabel='Fitted rating change (points)',ylabel='sqrt(abs(studentized residual))')
        a=axs[1,1];a.vlines(sample.index+2,0,cook,color='#315a86',lw=.5);a.axhline(4/n,color='#be7627',ls='--',label='4/N review heuristic');a.legend();a.set(title='Influence: all observations retained',xlabel='Source CSV row',ylabel="Cook's distance")
        a=axs[1,2];v=diag[(diag.model==name)&(diag.diagnostic=='VIF')];a.barh(v.feature,v.value,color='#315a86');a.axvline(5,color='#be7627',ls='--',label='5 review heuristic');a.set(title='Collinearity',xlabel='VIF');a.legend()
        fig.suptitle(f'{name} | Complete-case OLS | N={n:,} | In-sample diagnostics',fontsize=16)
        p=outdir/f'{name.lower().replace("-","_")}_diagnostics.png'
        fig.savefig(p,dpi=170,metadata={'Description':json.dumps(meta,ensure_ascii=False)});plt.close(fig);paths.append(p)
    return paths

def write_report(tables,meta):
    r=tables['results'].set_index('model');c=tables['coefficients'];s=tables['association_summary'];i=tables['framework_integration'];dg=tables['diagnostics']
    def coef(m,f):return c[(c.model==m)&(c.feature==f)].iloc[0]
    def interval(row,prefix='hc3_'):
        return f"[{row[prefix+'ci_lower']:.5g}, {row[prefix+'ci_upper']:.5g}]"
    views=[]; robust=[]
    descriptions={
        'sequel_number':'兩模型正向；與較小下滑相聯；系列存續/選擇可能解釋部分關係',
        'release_year':'正向 temporal context；非電影內容因素',
        'previous_rating':'负向但數學耦合；LR-B 刻意不估計',
        'previous_rating_votes':'未調整 Spearman 負向、LR-A 正向、LR-B 負向且 CI 跨零；不穩健',
        'years_since_previous':'兩模型負向；間隔較長與較大下滑相聯',
        'previous_runtime':'兩模型負向但幅度小；與較大下滑相聯',
    }
    for _,row in s.iterrows():
        f=row.feature;a=coef('LR-A',f);b=coef('LR-B',f) if f!='previous_rating' else None
        views.append({'Feature':f,'Spearman (n)':f"{row.spearman_with_rating_change:.4f} ({row.spearman_n})",'LR-A β':a.coefficient,
            'LR-A 95% CI':interval(a,''),'LR-A p':a.p_value,'LR-B β':b.coefficient if b is not None else np.nan,
            'LR-B 95% CI':interval(b,'') if b is not None else '預先排除','LR-B p':b.p_value if b is not None else np.nan,'Interpretation':descriptions[f]})
    for _,row in c[c.feature.ne('Intercept')].iterrows():
        robust.append({'Model':row.model,'Feature':row.feature,'Standardized β':row.standardized_beta,'HC3 95% CI':interval(row),
            'HC3 p':row.hc3_p,'Cluster 95% CI':interval(row,'cluster_'),'Cluster p':row.cluster_p,'VIF':row.vif})
    cross=[]
    for _,row in i.iterrows():
        cross.append({'Feature':row.feature,'P':row.preprocessing,'EDA binary rho':row.eda_binary_spearman,
            'Logistic OR':row.logistic_or,'RF permutation ΔAUC':row.rf_test_permutation,'XGB gain':row.xgboost_gain,'LR-A β':row.lr_a_beta,'LR-B β':row.lr_b_beta})
    top=tables['observations'].sort_values(['model','cooks_distance'],ascending=[True,False]).groupby('model',sort=False).head(5)
    missing=tables['missingness'][['model','feature','clean_n','missing_count','missing_rate','nonfinite_nonmissing']]
    model_stats=['model','n','r_squared','adjusted_r_squared','f_statistic','df_model','df_residual','overall_p_value','residual_standard_error','rmse','mae']
    prose=f'''# 連續型評分變化關聯分析：前作基準評分使模型解釋力明顯改變

STATUS = RATING_CHANGE_ASSOCIATION_COMPLETE_WITH_WARNINGS

## 主要結論

兩個預先指定 OLS 模型均使用同一批 **3,991** 個 complete cases；CLEAN population 仍為 **4,058**，僅 67 筆因前作片長缺失未參與係數估計。來源資料全數保留。

- **下滑幅度較明顯的穩健關聯**：與前作間隔較長對應較負的 rating_change；sequel_number 較高則對應較正的 rating_change（平均下滑較小）。兩個模型、HC3 與 franchise-cluster CI 的方向一致，惟關聯幅度小。
- **最大且具耦合疑慮的訊號**：previous_rating 在 LR-A 的 β={coef('LR-A','previous_rating').coefficient:.4f}，HC3 95% CI {interval(coef('LR-A','previous_rating'))}。移除此欄後 R² 由 {r.loc['LR-A','r_squared']:.4f} 降至 {r.loc['LR-B','r_squared']:.4f}（相差 {(r.loc['LR-A','r_squared']-r.loc['LR-B','r_squared'])*100:.2f} 個百分點）；這是數學耦合敏感度發現，不是 causal importance proof。
- **前作評分人數不穩健**：LR-A β={coef('LR-A','previous_rating_votes').coefficient:.6g}，LR-B β={coef('LR-B','previous_rating_votes').coefficient:.6g}，後者 HC3 CI 跨零。不能將評分人數描述為方向明確的獨立關聯。
- 兩模型殘差有厚尾、異質變異及高影響觀測值；傳統 p-value 不能單獨支持結論。HC3/cluster covariance 改善 uncertainty 報告，但不修正非線性、measurement error 或有影響的 OLS 點估計。

## 1. 研究問題、outcome 與 population

研究問題：「哪些因素與續集相較前作的評分變化幅度有關？」rating_change 的概念是 current average rating − previous rating；實際 Y 直接讀取 **recorded `與前作評分差`**。沒有重新相減、取整或替換原值，亦未新增 master target。

CLEAN 規則為 current rating >0、previous rating >0、recorded change 非缺失。與既有 rating_valid 逐列一致，n=4,058；既有 rating_drop 的 2,014/2,044 分布也通過 QA。CLEAN 的 recorded Y 範圍是 −7.5 至 +8.0，並非全部只有 0.1 精度；保留完整 recorded precision，不把零分重新納為有效評分。

本次是全期樣本（1913–2026）的補充性關聯估計，不沿用 classifier 的 temporal split 來宣稱預測績效。R²、RMSE、MAE 均為 in-sample；2026 cohort 不完整。語意上的正 β 表示 rating_change 較高，可是「較少下降」或「更多上升」，不是每部電影都在下降。模型納入所有有效變化，不只負向變化。

## 2. 模型、缺失與方法

LR-A：{', '.join(MODELS['LR-A'])}。

LR-B：{', '.join(MODELS['LR-B'])}。

兩者含截距。本次 LR-B **只移除 previous_rating，仍保留 previous_rating_votes**；不混同既有四 X 分類 Model B。禁止根據任何結果改模型。電影系列ID 僅用於 cluster covariance，不進 X。

{table(missing)}

missing_rate 的單位為 0–1 比例；67/4,058 = 1.6511%。LR-A/B 都只排除這 67 個缺前作片長的 complete-case 非適用列，並未刪除任何來源列或 outlier。未採用 optional imputation：本次未定義新 prediction training cohort，沒有理由另外以全樣本中位數補值，primary complete-case 結果可以直接比較。

OLS β 以原始 X 單位報告。standardized beta = β × SD(X)/SD(Y)，SD 使用該模型 complete-case sample、ddof=1；不新增 feature。一般 SE、t、p、95% CI 完整輸出；另提供 HC3（t, df=N−k−1）及 franchise cluster covariance（{int(r.loc['LR-A','franchise_groups'])} 個 cluster，small-sample correction、t df=G−1）。後兩者不改 OLS β。11 個非 intercept slope tests 分別在三種 covariance family 提供 BH-FDR q；未以 p 或 q 選變數。

## 3. Model fit

{table(tables['results'][model_stats])}

F 與 overall p 為 conventional OLS joint slope test；HC3 overall F/p 另在 results.csv。RSE = sqrt(SSE/(N−k−1))；RMSE = sqrt(SSE/N)；MAE = mean(abs(residual))。三者單位都是 rating points。LR-B 的低 R² 顯示移除前作基準評分後，這組線性變數只描述樣本變異的小部分；不能改寫成所有因素皆無關，也不能把 LR-A 的較高 R² 當成時間外推能力。

## 4. Spearman 與線性係數整合

此表的 LR CI/p 為 conventional OLS，供完整重現；解讀以後表 HC3/cluster uncertainty 一起判讀。六個 continuous Spearman 使用 CLEAN pairwise population；與舊 Rating Y Audit 已存四欄結果核對一致。previous_rating、release_year 的 CLEAN continuous Spearman 為本模組所需補充，未重跑整套 EDA；舊 4,376 筆 RAW correlation 未冒稱為 CLEAN。

{table(pd.DataFrame(views))}

## 5. Robust uncertainty 與方向穩健性

{table(pd.DataFrame(robust))}

可用原始單位解讀的例子（其他已列 X 固定；不作因果解釋）：

- sequel_number 每多一部，LR-A/B 的 recorded change 平均分別高 {coef('LR-A','sequel_number').coefficient:.4f}/{coef('LR-B','sequel_number').coefficient:.4f} 分，並非「越拍越好」的普遍定律，可能含 franchise survival 與組成差異。
- 與前作間隔多 5 年，相對 change 分別約低 {abs(coef('LR-A','years_since_previous').coefficient*5):.4f}/{abs(coef('LR-B','years_since_previous').coefficient*5):.4f} 分。這僅將原有係數換成易讀單位，不新增特徵。
- 前作片長多 10 分鐘，相對 change 分別約低 {abs(coef('LR-A','previous_runtime').coefficient*10):.4f}/{abs(coef('LR-B','previous_runtime').coefficient*10):.4f} 分，幅度相當小。
- release_year 較晚 10 年，相對 change 約高 {coef('LR-A','release_year').coefficient*10:.4f}/{coef('LR-B','release_year').coefficient*10:.4f} 分；只屬 temporal context，可能混合評分環境、產業、來源與系列存續差異。
- previous_rating_votes 每多 1,000 票，LR-A 約 {coef('LR-A','previous_rating_votes').coefficient*1000:+.4f} 分，LR-B 約 {coef('LR-B','previous_rating_votes').coefficient*1000:+.4f} 分，方向對調。raw counts 的線性斜率、rank correlation 及 non-linear importance 各自衡量不同關係。

## 6. 數學耦合及 regression-to-the-mean

previous_rating 直接出现在 Y=current−previous 的減項；在同一樣本和同一 X 設計下，change 對 previous 的 OLS 斜率等於 current 對 previous 的斜率減 1（代數關係，未額外擬合模型）。因此 LR-A 的負斜率部分可能來自 outcome construction。極端前作評分回到較典型後作評分也可能呈現 regression-to-the-mean，但本研究沒有重複量測可靠度資料可以分離機制。

LR-A 與 LR-B 的 R² 差異，以及 previous_rating_votes 的方向改變，均須完整報告；LR-B 不是最佳模型選擇、不是 feature elimination。不能將 previous_rating 的係數解釋為「前作評分造成下滑」，也不能將此差異當成 causal contribution。

## 7. 模型診斷

{table(dg[['model','diagnostic','feature','value','p_value','status']])}

normality p 輸出為 0 代表浮點下溢，不是理論機率恰等於零。殘差 Q-Q 兩端偏離 normal reference，厚尾清楚；residual vs fitted 的 LOWESS 有輕微系統性彎曲，線性條件平均假設需 WARNING，未自動新增非線性項。VIF 約 1.02–1.13，無明显 multicollinearity；這不消除 mathematical coupling。

Cook's D >4/N 是人工 review heuristic：LR-A 有 239 筆、LR-B 有 227 筆；最大 D 約 .0794/.0730。沒有任何列因此被刪除。Max D<1 也不表示沒有 influence。下表固定按每模型 Cook's D 排序取前五筆作人工查核，不表示資料錯誤或重新選片：

{table(top[['model','source_csv_row','電影名稱',Y,'residual','leverage','cooks_distance']])}

所有 7,982 筆 model-observation 診斷紀錄另存 observations.csv，可追溯 source CSV row、TMDB ID 及系列。未做刪高影響值的 refit，因此「robust」僅指目前 LR-A/B 與 uncertainty 方法間的一致性，不代表對所有高影響觀測敏感度皆已驗證。

![LR-A diagnostics](figures/rating_change_linear_regression_v1/lr_a_diagnostics.png)

![LR-B diagnostics](figures/rating_change_linear_regression_v1/lr_b_diagnostics.png)

## 8. 與既有 binary association 與 ML interpretation 對照

以下均直接讀取已有結果；本次未重新訓練 classifier。Association EDA 的 binary Spearman target 是 rating_drop，不是 continuous change。既有未調整 OR 在 framework_integration.csv 同時保留原單位；未存在 release_year 或 sequel_number 連續單位 OR 的欄位保持缺失，不自行擬合填入。

{table(pd.DataFrame(cross))}

- Logistic OR 來自正式 Model A、P1/P2，為每增加 1 個 **training SD** 的 odds multiplier；β 的 raw rating-point unit 不可直接比大小。Logistic 只用 ≤2020 training，LR 用全部有效年份，樣本不同。
- 原 EDA 的 previous_rating OR=1.486/每1分，間隔 OR=1.029/每年、前作片長 OR=1.045/每10分鐘，與本次負向 continuous β 在「更多下滑」語意上相容。sequel groups 的既有 drop odds 低於 part2，與正向 continuous sequel_number β 也相容，但分组與連續斜率不是同一 estimand。
- 前作評分人數的 EDA binary Spearman 為正、unadjusted logistic OR 約 .912/每10,000票且 CI 跨1；continuous Spearman 為負，LR-A 卻為正。rank/linear functional form、調整其他 X 與 target dichotomization 都不同，不能說所有方法方向一致。
- Tuned RF permutation 是 held-out test ROC-AUC decrease，XGBoost 是既有 **Model C 11 X** 的 training gain，且含 provenance-limited continuity X；兩者的模型、sample、基準單位不同。importance 沒有有利/不利方向，不可由正 importance 推論 X 與 rating_change 正相關。
- previous_rating 在 RF 與 XGBoost 反覆有訊號，但都沿用 change-based target，並非獨立驗證無耦合。sequel_number 與間隔也有跨框架訊號；前作片長 RF permutation 很小，符合其線性關聯幅度小的解讀。
- release_year 在 LR 有 temporal association，但既有 tuned RF test permutation 為0；無法由 LR 年份係數宣稱可外推未來。不同框架的 importance 不必相同，沒有根據這張表選 X。

## 9. 最終 evidence classification

| 類別 | 因素 | 結論與範圍 |
|---|---|---|
| robust evidence（本次模型/uncertainty 範圍） | sequel_number、years_since_previous | 前者較高與下滑較小相關；後者較長與下滑較大相關。LR-A/B、HC3/cluster CI、continuous Spearman 及 binary association 語意相容；幅度小，非因果。 |
| robust temporal association | release_year | 較晚年份對應较正變化；只能是 temporal context，不能解釋為電影內容原因或未來預測保證。 |
| weak evidence in magnitude | previous_runtime | 負向關聯方向穩定，但每10分鐘僅約0.02–0.03分，standardized beta 約−.06至−.08；不是因 p 小就稱為重要。 |
| coupling-sensitive evidence | previous_rating | 負向關聯最大，R² 對其高度敏感；outcome algebra 與 regression-to-the-mean concern 限制獨立解釋。 |
| insufficient evidence for a stable independent direction | previous_rating_votes | LR-A/B 反向，LR-B HC3/cluster CI 跨0；可有跨框架 signal，但不足以聲稱穩健獨立線性方向。 |

這些結論限於現有記錄、complete-case population、固定線性模型。不能代表因果關係、高效 T−1 預測或已解決 snapshot/provenance 問題。原始資料、既有 Y/模型結果與 feature eligibility 決策全部保留。本模組到此完成。

## 10. Provenance / reproducibility

- Input：`{meta['input_file']}`；SHA256 `{SHA}`；6481 × 50。
- Execution UTC：{meta['execution_timestamp_utc']}。這是執行日期，不是資料 snapshot date。
- N：CLEAN 4058；LR-A/LR-B 各3991、{int(r.loc['LR-A','franchise_groups'])} franchise groups；random seed 不適用（deterministic OLS）。
- Software：`{json.dumps(VERSIONS,ensure_ascii=False)}`。
- 完整 conventional β/SE/t/p/CI、HC3/cluster uncertainty、standardized beta/VIF：`rating_change_linear_regression_coefficients.csv`。
- Model fit、missingness、diagnostics、observations、association_summary、framework_integration 各表使用同名模組前綴。每表保留 SHA、execution timestamp、spec path、versions，definition/features 在 spec/manifest。
- 兩個模型以獨立 NumPy least-squares 檢驗，fitted difference <1e−8；完整數值估計執行兩次且相同。PNG metadata 含來源、N、模型、版本與日期；來源與既有比較檔 SHA/size/mtime 皆未變。
- Scope：只輸出本模組報告/表/圖/script；未寫任何 master/analysis/features dataset，未作 classifier fit、外部 lookup、配對或篩選特徵。
'''
    path=REPORTS/f'{PREFIX}_v1_report.md';path.write_text(prose,encoding='utf-8');return path

def main():
    timestamp=datetime.now(timezone.utc).isoformat()
    before={p:(sha(p),p.stat().st_size,p.stat().st_mtime_ns) for p in [INPUT]+[ROOT/p for p in EVIDENCE.values()]}
    raw,d=gate()
    tables,fits=estimate(d);second,_=estimate(d)
    assert all(tables[k].equals(second[k]) for k in tables),'deterministic estimates mismatch'
    summary,integration=integrate(d,tables['coefficients']);tables['association_summary']=summary;tables['framework_integration']=integration
    # Narrative conclusions use all prespecified estimates and diagnostic limits;
    # they never select, remove, or refit predictors.
    versions=json.dumps(VERSIONS,sort_keys=True)
    meta=dict(input_file=str(INPUT.relative_to(ROOT)),input_sha256=SHA,input_rows=6481,input_columns=50,clean_n=4058,execution_timestamp_utc=timestamp,software_versions=VERSIONS,random_seed=None,model_definitions=MODELS,specification=str(SPEC.relative_to(ROOT)))
    outputs=[]
    for name,frame in tables.items():
        p=REPORTS/f'{PREFIX}_{name}.csv'
        export=frame.copy();export['input_sha256']=SHA;export['execution_timestamp_utc']=timestamp;export['specification']=str(SPEC.relative_to(ROOT));export['software_versions']=versions
        export.to_csv(p,index=False,encoding='utf-8-sig',lineterminator='\n',float_format='%.17g');outputs.append(p)
    outdir=REPORTS/'figures/rating_change_linear_regression_v1';outdir.mkdir(parents=True,exist_ok=True)
    figures=plots(fits,tables['diagnostics'],outdir,meta);outputs+=figures
    outputs.append(write_report(tables,meta))
    for p,signature in before.items(): assert signature==(sha(p),p.stat().st_size,p.stat().st_mtime_ns),f'source changed: {p}'
    qa=REPORTS/f'{PREFIX}_v1_qa.md'
    qa.write_text('# Rating Change Linear Regression v1 QA\n\nSTATUS = PASS_WITH_WARNINGS\n\n'+
        '\n'.join(f'- PASS: {s}' for s in ['Approved input SHA and 6481 x 50 shape','CLEAN n=4058; same existing rating_valid','Existing binary target checked only; 2014/2044 unchanged','Exact source aliases; no Y recomputation or source writes','LR-A six X; LR-B five X retains previous_rating_votes','Both models use identical 3991 original rows; 67 missing-runtime exclusions documented','No imputation, outlier deletion, weights, feature selection or classifier fits','All existing evidence files and input SHA/size/mtime unchanged','OLS full rank; independent standardized NumPy least-squares fitted values agree <1e-8','Repeated OLS results/coefficients/diagnostic/observation tables exactly equal','Prior available CLEAN Spearman values independently reconcile','Integration reads existing Logistic/RF/XGBoost outputs, no training'])+
        '\n\n## Diagnostic status (not source-data failure)\n\n'+table(tables['diagnostics'])+
        '\n\n## Figure review\n\nTwo PNGs generated; visual inspection is separately documented in manifest after inspection.\n\n## Provenance\n\n'+json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');outputs.append(qa)
    manifest={**meta,'status':'RATING_CHANGE_ASSOCIATION_COMPLETE_WITH_WARNINGS','input_immutable':True,'evidence':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in before],
        'source_y_column':Y,'feature_lists':MODELS,'complete_case_n':{name:len(value[1]) for name,value in fits.items()},'no_imputation':True,
        'covariances':['NONROBUST','HC3','CLUSTER_FRANCHISE'],'fdr':'BH across 11 slope tests per covariance family','diagnostic_warnings':tables['diagnostics'].loc[tables['diagnostics'].status.eq('WARNING')].to_dict('records'),
        'deterministic_repeated_estimates':True,'figures_visually_verified':False,'script_path':str(Path(__file__).relative_to(ROOT)),'script_sha256':sha(__file__),'spec_sha256':sha(SPEC),
        'outputs':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in outputs]}
    # JSON null, not nonstandard NaN, for unavailable diagnostic p-values.
    def safe(v):
        if isinstance(v,dict):return {k:safe(x) for k,x in v.items()}
        if isinstance(v,list):return [safe(x) for x in v]
        if isinstance(v,float) and not np.isfinite(v):return None
        return v
    (REPORTS/f'{PREFIX}_v1_manifest.json').write_text(json.dumps(safe(manifest),ensure_ascii=False,indent=2,default=str,allow_nan=False)+'\n',encoding='utf-8')
    print(table(tables['results'][['model','n','r_squared','adjusted_r_squared','f_statistic','overall_p_value','residual_standard_error','rmse','mae']]))
    print(table(tables['coefficients'][['model','feature','coefficient','standardized_beta','hc3_ci_lower','hc3_ci_upper','cluster_ci_lower','cluster_ci_upper','vif']]))
    print(table(tables['diagnostics']))

if __name__=='__main__':main()
