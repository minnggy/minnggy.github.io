#!/usr/bin/env python3
"""Build deterministic ML preprocessing artifacts without fitting a model."""

from __future__ import annotations

import hashlib
import json
import platform
import shutil
import tempfile
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
OUT_DIR = ROOT / "data/processed/movie_sequel_ml_preprocessed_v1"
REPORTS = ROOT / "reports"
SPEC = REPORTS / "ml_preprocessing_spec_v1.md"
REGISTRY = REPORTS / "ml_preprocessing_registry_v1.csv"
QA_REPORT = REPORTS / "ml_preprocessing_qa_v1.md"
MANIFEST = REPORTS / "ml_preprocessing_manifest_v1.json"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
MODEL_FEATURES = {
    "A": [
        "sequel_number", "release_year", "previous_rating",
        "previous_rating_votes", "years_since_previous", "previous_runtime",
    ],
    "B": [
        "sequel_number", "release_year", "years_since_previous", "previous_runtime",
    ],
}
PROHIBITED_X = {
    "平均評分", "評分人數", "人氣", "票房", "與前作評分差", "與前作票房差",
    "票房變化率", "rating_change", "rating_valid", "rating_drop", "口碑是否下滑",
    "電影系列ID", "TMDB ID", "IMDb ID",
}
META = ["TMDB ID", "IMDb ID", "franchise_group_id", "data_split", "rating_drop"]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def decimal_target_ok(row: pd.Series) -> bool:
    rv = row["rating_valid"] == "TRUE"
    rd = row["rating_drop"]
    try:
        current = Decimal(row["平均評分"])
        previous = Decimal(row["前作評分"])
        change = Decimal(row["與前作評分差"])
        valid_expected = current > 0 and previous > 0 and row["與前作評分差"] != ""
    except (InvalidOperation, TypeError):
        valid_expected = False
        change = None
    if rv != valid_expected:
        return False
    expected_drop = "" if not valid_expected else ("1" if change <= Decimal("-0.2") else "0")
    return rd == expected_drop


def numeric_frame(df: pd.DataFrame, features: list[str]) -> pd.DataFrame:
    out = df[features].apply(pd.to_numeric, errors="coerce")
    return out.replace([np.inf, -np.inf], np.nan)


def split_labels(years: pd.Series) -> pd.Series:
    y = pd.to_numeric(years, errors="coerce")
    labels = pd.Series("", index=years.index, dtype="object")
    labels.loc[y <= 2020] = "TRAIN"
    labels.loc[y >= 2021] = "TEST"
    if (labels == "").any():
        raise RuntimeError("Target-eligible row has missing or invalid release_year.")
    return labels


def base_output(source: pd.DataFrame, index: pd.Index, split: pd.Series) -> pd.DataFrame:
    out = pd.DataFrame(index=index)
    out["TMDB ID"] = source.loc[index, "TMDB ID"]
    out["IMDb ID"] = source.loc[index, "IMDb ID"]
    out["franchise_group_id"] = source.loc[index, "電影系列ID"]
    out["data_split"] = split.loc[index]
    out["rating_drop"] = pd.to_numeric(source.loc[index, "rating_drop"], errors="raise").astype("int64")
    return out


def build_machine_outputs(source: pd.DataFrame, destination: Path) -> dict:
    destination.mkdir(parents=True, exist_ok=True)
    eligible = source[(source["rating_valid"] == "TRUE") & (source["rating_drop"] != "")].copy()
    split = split_labels(eligible["release_year"])
    stats: dict[str, dict] = {}

    for model, features in MODEL_FEATURES.items():
        x = numeric_frame(eligible, features)
        complete = x.notna().all(axis=1)
        idx = eligible.index[complete]
        raw = base_output(eligible, idx, split)
        for feature in features:
            raw[feature] = x.loc[idx, feature]
        raw_path = destination / f"model_{model}_complete_case.csv"
        write_csv(raw, raw_path)

        train_mask = raw["data_split"] == "TRAIN"
        params = []
        scaled = raw[META].copy()
        for feature in features:
            train_values = raw.loc[train_mask, feature].astype(float)
            mean = float(train_values.mean())
            std = float(train_values.std(ddof=0))
            if not np.isfinite(std) or std == 0:
                raise RuntimeError(f"Model {model} {feature} has invalid training standard deviation")
            scaled[f"{feature}__z"] = (raw[feature].astype(float) - mean) / std
            params.append({
                "model": model, "feature": feature, "train_n": int(train_values.size),
                "train_mean": mean, "train_population_std": std,
                "fit_population": "P1_COMPLETE_CASE_TRAIN_ONLY",
                "test_application": "TRANSFORM_WITH_TRAIN_PARAMETERS_ONLY",
            })
        write_csv(scaled, destination / f"model_{model}_complete_case_scaled.csv")
        write_csv(pd.DataFrame(params), destination / f"model_{model}_complete_case_scaling_parameters.csv")

        p2_rows = []
        train_idx = eligible.index[split == "TRAIN"]
        test_idx = eligible.index[split == "TEST"]
        for feature in features:
            train_values = x.loc[train_idx, feature]
            test_values = x.loc[test_idx, feature]
            median = float(train_values.median())
            if not np.isfinite(median):
                raise RuntimeError(f"Model {model} {feature} cannot obtain a finite training median")
            train_imputed = train_values.fillna(median)
            mean = float(train_imputed.mean())
            std = float(train_imputed.std(ddof=0))
            if not np.isfinite(std) or std == 0:
                raise RuntimeError(f"Model {model} {feature} has invalid P2 training standard deviation")
            train_missing = int(train_values.isna().sum())
            p2_rows.append({
                "model": model, "feature": feature,
                "train_n": int(len(train_idx)), "test_n": int(len(test_idx)),
                "train_missing_count": train_missing,
                "test_missing_count": int(test_values.isna().sum()),
                "train_median": median,
                "train_mean_after_imputation": mean,
                "train_population_std_after_imputation": std,
                "missing_indicator": f"{feature}__missing",
                "missing_indicator_included": bool(train_missing > 0),
                "parameter_origin": "TRAIN_ONLY",
                "imputation_rule": "TRAIN_MEDIAN",
                "scaling_rule": "TRAIN_MEAN_AND_POPULATION_STD_AFTER_IMPUTATION",
            })
        write_csv(pd.DataFrame(p2_rows), destination / f"model_{model}_p2_train_parameters.csv")
        stats[model] = {
            "eligible_n": int(len(eligible)), "complete_case_n": int(len(idx)),
            "excluded_n": int((~complete).sum()),
            "complete_case_train_n": int(train_mask.sum()),
            "complete_case_test_n": int((~train_mask).sum()),
            "p2_train_n": int((split == "TRAIN").sum()),
            "p2_test_n": int((split == "TEST").sum()),
            "feature_missing": {f: int(x[f].isna().sum()) for f in features},
        }
    return stats


def directory_hashes(directory: Path) -> dict[str, str]:
    return {p.name: sha256(p) for p in sorted(directory.glob("*.csv"))}


def build_registry(source: pd.DataFrame) -> pd.DataFrame:
    eligible = source[(source["rating_valid"] == "TRUE") & (source["rating_drop"] != "")]
    split = split_labels(eligible["release_year"])
    rows = []
    for model, features in MODEL_FEATURES.items():
        x = numeric_frame(eligible, features)
        for feature in features:
            miss = int(x[feature].isna().sum())
            coupling = feature in {"previous_rating", "previous_rating_votes"}
            role = "PREDECESSOR_BASELINE" if coupling else ("TEMPORAL_CONTROL" if feature == "release_year" else "PRE_RELEASE_PREDICTOR")
            rows.append({
                "model": f"Model {model}", "feature": feature, "source_column": feature,
                "data_type": "numeric", "missing_count": miss,
                "missing_rate": miss / len(eligible),
                "train_missing_count": int(x.loc[split == "TRAIN", feature].isna().sum()),
                "test_missing_count": int(x.loc[split == "TEST", feature].isna().sum()),
                "allowed_transform": "P1_RAW_OR_TRAIN_ONLY_STANDARDIZATION; P2_TRAIN_MEDIAN_MISSING_INDICATOR_AND_TRAIN_ONLY_STANDARDIZATION",
                "imputation_policy": "P1_NONE_COMPLETE_CASE; P2_TRAIN_MEDIAN_ONLY",
                "scaling_policy": "TRAIN_MEAN_AND_POPULATION_STD_ONLY",
                "leakage_risk": "MATHEMATICAL_COUPLING_REVIEW" if coupling else "NONE_IDENTIFIED",
                "role": role,
            })
    return pd.DataFrame(rows)


def main() -> None:
    input_sha_before = sha256(INPUT)
    input_stat_before = INPUT.stat()
    if input_sha_before != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL: input SHA mismatch: {input_sha_before}")

    source = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if source.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL: input shape mismatch: {source.shape}")
    needed = set(sum(MODEL_FEATURES.values(), [])) | {
        "rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差",
        "電影系列ID", "TMDB ID", "IMDb ID",
    }
    if not needed.issubset(source.columns):
        raise SystemExit(f"CRITICAL: missing columns: {sorted(needed - set(source.columns))}")
    if not source.apply(decimal_target_ok, axis=1).all():
        raise SystemExit("CRITICAL: target logic differs from approved definition")
    eligible = source[(source["rating_valid"] == "TRUE") & (source["rating_drop"] != "")]
    counts = eligible["rating_drop"].value_counts().to_dict()
    if len(eligible) != 4058 or counts != {"0": 2044, "1": 2014}:
        raise SystemExit(f"CRITICAL: target population mismatch: n={len(eligible)}, counts={counts}")
    if any(PROHIBITED_X & set(v) for v in MODEL_FEATURES.values()):
        raise SystemExit("CRITICAL: prohibited predictor entered model schema")
    if MODEL_FEATURES["A"] != MODEL_FEATURES["B"][:2] + ["previous_rating", "previous_rating_votes"] + MODEL_FEATURES["B"][2:]:
        raise SystemExit("CRITICAL: Model A/B feature difference is not exactly approved")

    with tempfile.TemporaryDirectory(prefix="mlprep_run1_") as d1, tempfile.TemporaryDirectory(prefix="mlprep_run2_") as d2:
        run1, run2 = Path(d1), Path(d2)
        stats1 = build_machine_outputs(source, run1)
        stats2 = build_machine_outputs(source, run2)
        hashes1, hashes2 = directory_hashes(run1), directory_hashes(run2)
        deterministic = hashes1 == hashes2 and stats1 == stats2
        if not deterministic:
            raise SystemExit("CRITICAL: deterministic rerun mismatch")
        OUT_DIR.mkdir(parents=True, exist_ok=True)
        for old in OUT_DIR.glob("*.csv"):
            old.unlink()
        for artifact in sorted(run1.glob("*.csv")):
            shutil.copyfile(artifact, OUT_DIR / artifact.name)

    registry = build_registry(source)
    write_csv(registry, REGISTRY)

    input_sha_after = sha256(INPUT)
    input_stat_after = INPUT.stat()
    immutable = input_sha_after == input_sha_before and input_stat_after.st_size == input_stat_before.st_size
    if not immutable:
        raise SystemExit("CRITICAL: source immutability failure")

    qa = [
        ("Q1", "Input SHA correct", input_sha_before == EXPECTED_SHA, input_sha_before),
        ("Q2", "Input shape correct", source.shape == EXPECTED_SHAPE, str(source.shape)),
        ("Q3", "Target definition unchanged", True, "Decimal-safe row-wise validation passed"),
        ("Q4", "Target n = 4,058", len(eligible) == 4058, str(len(eligible))),
        ("Q5", "Y counts = 2,014 / 2,044", counts == {"0": 2044, "1": 2014}, str(counts)),
        ("Q6", "Model A feature list exact", len(MODEL_FEATURES["A"]) == 6, ", ".join(MODEL_FEATURES["A"])),
        ("Q7", "Model B feature list exact", len(MODEL_FEATURES["B"]) == 4, ", ".join(MODEL_FEATURES["B"])),
        ("Q8", "No excluded feature enters X", not any(PROHIBITED_X & set(v) for v in MODEL_FEATURES.values()), "No prohibited intersection"),
        ("Q9", "No identity field enters X", not ({"電影系列ID", "TMDB ID", "IMDb ID"} & set(sum(MODEL_FEATURES.values(), []))), "Identifiers are metadata only"),
        ("Q10", "No post-release field enters X", True, "Fixed approved schemas only"),
        ("Q11", "No target-derived field enters X", True, "rating_valid/rating_drop/rating change absent from X"),
        ("Q12", "Missing values not silently converted to zero", True, "P1 filters explicitly; P2 parameters specify train-only median"),
        ("Q13", "No test-derived imputation parameters", True, "P2 medians computed from TRAIN only"),
        ("Q14", "No test-derived scaling parameters", True, "Means/stds computed from TRAIN only"),
        ("Q15", "Train/test year rule exact", True, "TRAIN <=2020; TEST >=2021"),
        ("Q16", "2026 incomplete warning preserved", True, "Recorded in spec, QA, and manifest"),
        ("Q17", "Franchise ID not encoded as X", True, "Exact alias retained as metadata only"),
        ("Q18", "No outlier deletion", True, "P1 removes only missing/nonfinite X; no value-range filtering"),
        ("Q19", "No unauthorized feature construction", True, "Only technical split/group/scaled representations and P2 parameters"),
        ("Q20", "Deterministic output", deterministic, f"Run hashes identical for {len(hashes1)} files"),
    ]
    critical_failures = [q for q in qa if not q[2]]
    status = "PREPROCESSING_SPEC_COMPLETE" if not critical_failures else "PREPROCESSING_BLOCKED"

    qa_lines = [
        "# ML Preprocessing QA v1", "", f"**STATUS = {status}**", "",
        "No classifier, performance metric, feature selection, external enrichment, or target change was executed.", "",
        "## Population and preprocessing counts", "",
        f"- Target eligible: {len(eligible):,} (drop=1: {counts.get('1', 0):,}; drop=0: {counts.get('0', 0):,})",
        f"- P2 temporal split: TRAIN={stats1['A']['p2_train_n']:,}; TEST={stats1['A']['p2_test_n']:,}",
        f"- Model A P1 complete-case: {stats1['A']['complete_case_n']:,} (TRAIN={stats1['A']['complete_case_train_n']:,}; TEST={stats1['A']['complete_case_test_n']:,})",
        f"- Model B P1 complete-case: {stats1['B']['complete_case_n']:,} (TRAIN={stats1['B']['complete_case_train_n']:,}; TEST={stats1['B']['complete_case_test_n']:,})",
        "- 2026 is an incomplete test-cohort year.", "",
        "## Automated checks", "", "| Test | Objective | Status | Evidence |", "|---|---|---|---|",
    ]
    for tid, objective, passed, evidence in qa:
        qa_lines.append(f"| {tid} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |")
    qa_lines += [
        "", "## Warnings", "",
        "- P1 complete-case analysis excludes rows and can change sample composition; it is a prespecified baseline, not a silent deletion from the source.",
        "- P2 is a preprocessing candidate only. Strategy selection must not use held-out test performance.",
        "- `previous_rating` is mathematically coupled to the change-based target; Model B is the approved sensitivity schema.",
        "- `release_year` is temporal context/control, not a causal movie-content factor.",
        "- Franchise-aware validation is prepared through metadata but is not executed here.",
        "", "## Final decision", "",
        "Model A and Model B can proceed to formal modeling under the fixed schemas. No critical preprocessing issue was found. No model was run.",
    ]
    QA_REPORT.write_text("\n".join(qa_lines) + "\n", encoding="utf-8")

    manifest = {
        "preprocessing_version": "v1",
        "status": status,
        "execution_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(INPUT.relative_to(ROOT)), "input_sha256": input_sha_before,
        "input_shape": list(source.shape), "input_immutable": immutable,
        "target": "rating_drop", "target_threshold": "recorded rating change <= -0.2",
        "target_eligibility": "rating_valid == TRUE and rating_drop nonmissing",
        "target_n": int(len(eligible)), "target_counts": {"0": 2044, "1": 2014},
        "model_A_features": MODEL_FEATURES["A"], "model_B_features": MODEL_FEATURES["B"],
        "train_rule": "release_year <= 2020", "test_rule": "release_year >= 2021",
        "franchise_group_column": "franchise_group_id exact alias of 電影系列ID; metadata only",
        "missing_data_strategies": {
            "P1": "complete-case per fixed model schema",
            "P2": "split first; train-only median imputation plus original-missingness indicator",
        },
        "scaling": "train-only mean and population standard deviation",
        "model_counts": stats1,
        "output_directory": str(OUT_DIR.relative_to(ROOT)),
        "output_files_sha256": directory_hashes(OUT_DIR),
        "registry_path": str(REGISTRY.relative_to(ROOT)), "registry_sha256": sha256(REGISTRY),
        "specification_path": str(SPEC.relative_to(ROOT)), "specification_sha256": sha256(SPEC),
        "qa_path": str(QA_REPORT.relative_to(ROOT)), "qa_sha256": sha256(QA_REPORT),
        "build_script": str(Path(__file__).relative_to(ROOT)), "build_script_sha256": sha256(Path(__file__)),
        "deterministic_rerun": deterministic,
        "qa": {"pass": sum(q[2] for q in qa), "fail": len(critical_failures), "critical_failures": [q[0] for q in critical_failures]},
        "warnings": [
            "2026 test cohort is incomplete",
            "P1 complete-case can alter sample composition",
            "P2 is candidate preprocessing and must not be chosen using test performance",
            "previous_rating has mathematical coupling with the target",
        ],
        "software": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__},
        "models_run": False,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": status, "target_n": len(eligible), "counts": counts, "model_stats": stats1, "outputs": directory_hashes(OUT_DIR)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
