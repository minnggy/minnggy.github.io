#!/usr/bin/env python3
"""Execute the fixed final XGBoost provenance-limited prediction experiment."""

from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import warnings
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels
import statsmodels.api as sm
import xgboost
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from xgboost import XGBClassifier


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
PREPROCESSING_SPEC = ROOT / "reports/ml_preprocessing_spec_v1.md"
MODEL_C_SPEC = ROOT / "reports/model_c_continuity_spec_v1.md"
LOGISTIC_RESULTS = ROOT / "reports/logistic_regression_v1_results.csv"
RF_RESULTS = ROOT / "reports/random_forest_v1_results.csv"
MODEL_C_RESULTS = ROOT / "reports/model_c_continuity_results.csv"
SPEC = ROOT / "reports/final_xgboost_spec_v1.md"
RESULTS = ROOT / "reports/final_xgboost_results.csv"
IMPORTANCE = ROOT / "reports/final_xgboost_feature_importance.csv"
COMPARISON = ROOT / "reports/final_model_comparison.csv"
MANIFEST = ROOT / "reports/final_xgboost_manifest.json"
QA = ROOT / "reports/final_xgboost_qa.md"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
SEED = 20260913
THRESHOLD = 0.5
FEATURES = [
    "sequel_number",
    "release_year",
    "previous_rating",
    "previous_rating_votes",
    "years_since_previous",
    "previous_runtime",
    "導演是否更換",
    "主演是否更換",
    "與前作共同主演數",
    "與前作片長差",
    "片長變化率",
]
ADDED_PROVENANCE_LIMITED = FEATURES[6:]
BOOLEAN_FEATURES = {"導演是否更換", "主演是否更換"}
PROHIBITED = {
    "平均評分",
    "評分人數",
    "人氣",
    "票房",
    "與前作評分差",
    "與前作票房差",
    "票房變化率",
    "rating_change",
    "rating_valid",
    "rating_drop",
    "口碑是否下滑",
    "電影系列ID",
    "TMDB ID",
    "IMDb ID",
}
XGB_PARAMS = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "n_estimators": 500,
    "max_depth": 6,
    "learning_rate": 0.05,
    "min_child_weight": 1,
    "subsample": 1.0,
    "colsample_bytree": 1.0,
    "gamma": 0,
    "reg_alpha": 0,
    "reg_lambda": 1,
    "random_state": SEED,
    "n_jobs": 1,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def convert_feature(frame: pd.DataFrame, feature: str) -> pd.Series:
    if feature in BOOLEAN_FEATURES:
        unexpected = frame.loc[~frame[feature].isin(["", "TRUE", "FALSE"]), feature].unique().tolist()
        if unexpected:
            raise RuntimeError(f"Unexpected boolean values for {feature}: {unexpected[:10]}")
        return frame[feature].map({"TRUE": 1.0, "FALSE": 0.0, "": np.nan}).astype(float)
    raw_nonempty = frame[feature].ne("")
    values = pd.to_numeric(frame[feature], errors="coerce").replace([np.inf, -np.inf], np.nan)
    failures = int((raw_nonempty & values.isna()).sum())
    if failures:
        raise RuntimeError(f"Nonempty numeric parse failures for {feature}: {failures}")
    return values


def feature_matrix(frame: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({feature: convert_feature(frame, feature) for feature in FEATURES}, index=frame.index)


def gate_input() -> tuple[pd.DataFrame, dict]:
    input_sha = sha256(INPUT)
    if input_sha != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL FAILURE: input SHA mismatch: {input_sha}")
    frame = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if frame.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL FAILURE: input shape mismatch: {frame.shape}")
    required = set(FEATURES) | {
        "rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差",
        "TMDB ID", "IMDb ID", "電影系列ID",
    }
    if not required.issubset(frame.columns):
        raise SystemExit(f"CRITICAL FAILURE: missing columns: {sorted(required - set(frame.columns))}")
    if set(FEATURES) & PROHIBITED:
        raise SystemExit(f"CRITICAL FAILURE: prohibited X entered schema: {sorted(set(FEATURES) & PROHIBITED)}")

    mismatches = []
    for index, row in frame.iterrows():
        current, previous, change = (
            decimal_or_none(row[name]) for name in ["平均評分", "前作評分", "與前作評分差"]
        )
        valid = current is not None and previous is not None and change is not None and current > 0 and previous > 0
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            mismatches.append(int(index) + 2)
    if mismatches:
        raise SystemExit(f"CRITICAL FAILURE: target logic mismatch rows: {mismatches[:10]}")

    eligible = frame[(frame["rating_valid"] == "TRUE") & frame["rating_drop"].isin(["0", "1"])].copy()
    counts = eligible["rating_drop"].value_counts().to_dict()
    if len(eligible) != 4058 or counts != {"0": 2044, "1": 2014}:
        raise SystemExit(f"CRITICAL FAILURE: target population mismatch: n={len(eligible)}, counts={counts}")
    tmdb = frame["TMDB ID"]
    imdb = frame.loc[frame["IMDb ID"].ne(""), "IMDb ID"]
    if tmdb.eq("").any() or tmdb.duplicated().any() or imdb.duplicated().any():
        raise SystemExit("CRITICAL FAILURE: identity integrity gate failed")

    x = feature_matrix(eligible)
    if x["release_year"].isna().any():
        raise SystemExit("CRITICAL FAILURE: eligible release_year missing")
    train = x["release_year"] <= 2020
    test = x["release_year"] >= 2021
    if not (train | test).all() or (train & test).any():
        raise SystemExit("CRITICAL FAILURE: temporal split is not exhaustive and exclusive")
    missingness = []
    for feature in FEATURES:
        missingness.append({
            "feature": feature,
            "eligible_missing_n": int(x[feature].isna().sum()),
            "eligible_missing_rate": float(x[feature].isna().mean()),
            "train_missing_n": int(x.loc[train, feature].isna().sum()),
            "test_missing_n": int(x.loc[test, feature].isna().sum()),
        })
    return eligible, {
        "input_sha256": input_sha,
        "input_shape": list(frame.shape),
        "eligible_n": len(eligible),
        "drop_n": int(counts["1"]),
        "non_drop_n": int(counts["0"]),
        "base_train_n": int(train.sum()),
        "base_test_n": int(test.sum()),
        "target_logic_mismatches": 0,
        "missingness": missingness,
    }


def calibration(y: np.ndarray, probability: np.ndarray) -> tuple[float, float, str]:
    p = np.clip(probability, 1e-12, 1 - 1e-12)
    logit = np.log(p / (1 - p))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            fit = sm.GLM(y, sm.add_constant(logit, has_constant="add"), family=sm.families.Binomial()).fit(
                maxiter=200, tol=1e-10
            )
            if any(type(w.message).__name__ == "PerfectSeparationWarning" for w in caught):
                return np.nan, np.nan, "NOT_ESTIMABLE_PERFECT_PREDICTION"
            return float(fit.params[0]), float(fit.params[1]), "ESTIMABLE"
        except Exception as exc:
            return np.nan, np.nan, f"NOT_ESTIMABLE:{type(exc).__name__}"


def evaluate(y: np.ndarray, probability: np.ndarray) -> dict:
    predicted = (probability >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    intercept, slope, calibration_status = calibration(y, probability)
    return {
        "roc_auc": float(roc_auc_score(y, probability)),
        "pr_auc": float(average_precision_score(y, probability)),
        "brier": float(brier_score_loss(y, probability)),
        "accuracy": float(accuracy_score(y, predicted)),
        "precision": float(precision_score(y, predicted, zero_division=0)),
        "recall": float(recall_score(y, predicted, zero_division=0)),
        "f1": float(f1_score(y, predicted, zero_division=0)),
        "specificity": float(tn / (tn + fp)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "calibration_intercept": intercept,
        "calibration_slope": slope,
        "calibration_status": calibration_status,
        "mean_predicted_probability": float(np.mean(probability)),
        "observed_prevalence": float(np.mean(y)),
    }


def prepare(eligible: pd.DataFrame, strategy: str) -> dict:
    x_all = feature_matrix(eligible)
    y_all = pd.to_numeric(eligible["rating_drop"], errors="raise").astype(int)
    train_base = x_all["release_year"] <= 2020
    test_base = x_all["release_year"] >= 2021
    parameters = []
    indicators = []

    if strategy == "P1":
        used = x_all.notna().all(axis=1) & np.isfinite(x_all).all(axis=1)
        train_mask = train_base & used
        test_mask = test_base & used
        train_raw = x_all.loc[train_mask].copy()
        test_raw = x_all.loc[test_mask].copy()
    elif strategy == "P2":
        used = pd.Series(True, index=eligible.index)
        train_mask = train_base
        test_mask = test_base
        train_raw = x_all.loc[train_mask].copy()
        test_raw = x_all.loc[test_mask].copy()
        for feature in FEATURES:
            train_missing = train_raw[feature].isna()
            test_missing = test_raw[feature].isna()
            median = float(train_raw.loc[~train_missing, feature].median())
            if not np.isfinite(median):
                raise RuntimeError(f"Nonfinite train median for {feature}")
            if train_missing.any():
                indicator = f"{feature}__missing"
                indicators.append(indicator)
                train_raw[indicator] = train_missing.astype(float)
                test_raw[indicator] = test_missing.astype(float)
            train_raw[feature] = train_raw[feature].fillna(median)
            test_raw[feature] = test_raw[feature].fillna(median)
            parameters.append({
                "strategy": strategy, "feature": feature, "parameter": "TRAIN_MEDIAN", "value": median,
                "source": "TRAIN_ONLY", "indicator_included": bool(train_missing.any()),
            })
    else:
        raise ValueError(strategy)

    train = pd.DataFrame(index=train_raw.index)
    test = pd.DataFrame(index=test_raw.index)
    for feature in FEATURES:
        mean = float(train_raw[feature].mean())
        std = float(train_raw[feature].std(ddof=0))
        if not np.isfinite(mean) or not np.isfinite(std) or std == 0:
            raise RuntimeError(f"Invalid training scaling parameters for {feature}")
        train[feature] = (train_raw[feature] - mean) / std
        test[feature] = (test_raw[feature] - mean) / std
        parameters.extend([
            {"strategy": strategy, "feature": feature, "parameter": "TRAIN_MEAN", "value": mean, "source": "TRAIN_ONLY", "indicator_included": f"{feature}__missing" in indicators},
            {"strategy": strategy, "feature": feature, "parameter": "TRAIN_POPULATION_SD", "value": std, "source": "TRAIN_ONLY", "indicator_included": f"{feature}__missing" in indicators},
        ])
    for indicator in indicators:
        train[indicator] = train_raw[indicator]
        test[indicator] = test_raw[indicator]
    if train.isna().any().any() or test.isna().any().any():
        raise RuntimeError(f"{strategy} model matrix still contains missing values")
    return {
        "x_train": train,
        "x_test": test,
        "y_train": y_all.loc[train_mask].to_numpy(),
        "y_test": y_all.loc[test_mask].to_numpy(),
        "used_n": int(used.sum()),
        "excluded_n": int((~used).sum()),
        "train_n": int(train_mask.sum()),
        "test_n": int(test_mask.sum()),
        "indicators": indicators,
        "parameters": pd.DataFrame(parameters),
    }


def fit_one(prepared: dict, strategy: str) -> dict:
    model = XGBClassifier(**XGB_PARAMS)
    model.fit(prepared["x_train"], prepared["y_train"])
    train_probability = model.predict_proba(prepared["x_train"])[:, 1]
    test_probability = model.predict_proba(prepared["x_test"])[:, 1]
    results = []
    for split, y, probability in [
        ("TRAIN", prepared["y_train"], train_probability),
        ("TEST", prepared["y_test"], test_probability),
    ]:
        results.append({
            "model": "Final XGBoost Model C",
            "algorithm": "XGBoost",
            "preprocessing": strategy,
            "split": split,
            "n": len(y),
            **evaluate(y, probability),
        })

    booster = model.get_booster()
    importance_rows = []
    for importance_type in ["gain", "weight", "cover", "total_gain", "total_cover"]:
        scores = booster.get_score(importance_type=importance_type)
        denominator = sum(scores.values())
        for feature in prepared["x_train"].columns:
            raw = float(scores.get(feature, 0.0))
            importance_rows.append({
                "model": "Final XGBoost Model C",
                "preprocessing": strategy,
                "feature": feature,
                "importance_type": importance_type.upper(),
                "importance": raw,
                "normalized_importance": raw / denominator if denominator else 0.0,
            })
    importance = pd.DataFrame(importance_rows)
    importance["rank"] = importance.groupby(["preprocessing", "importance_type"])["importance"].rank(
        method="min", ascending=False
    ).astype(int)
    return {
        "results": pd.DataFrame(results),
        "importance": importance,
        "train_probability": train_probability,
        "test_probability": test_probability,
        "model_config": json.loads(booster.save_config()),
    }


def run_all(eligible: pd.DataFrame) -> dict:
    result_frames = []
    importance_frames = []
    probability_frames = []
    parameter_frames = []
    diagnostics = []
    configs = {}
    for strategy in ["P1", "P2"]:
        prepared = prepare(eligible, strategy)
        fitted = fit_one(prepared, strategy)
        result_frames.append(fitted["results"])
        importance_frames.append(fitted["importance"])
        if not prepared["parameters"].empty:
            parameter_frames.append(prepared["parameters"])
        probability_frames.append(pd.DataFrame({
            "preprocessing": strategy,
            "split": ["TRAIN"] * prepared["train_n"] + ["TEST"] * prepared["test_n"],
            "probability": np.concatenate([fitted["train_probability"], fitted["test_probability"]]),
        }))
        diagnostics.append({
            "preprocessing": strategy,
            "eligible_n": len(eligible),
            "used_n": prepared["used_n"],
            "excluded_n": prepared["excluded_n"],
            "train_n": prepared["train_n"],
            "test_n": prepared["test_n"],
            "research_feature_count": len(FEATURES),
            "model_matrix_column_count": prepared["x_train"].shape[1],
            "missingness_indicators": "|".join(prepared["indicators"]),
            "fit_success": True,
        })
        configs[strategy] = fitted["model_config"]
    return {
        "results": pd.concat(result_frames, ignore_index=True),
        "importance": pd.concat(importance_frames, ignore_index=True),
        "probabilities": pd.concat(probability_frames, ignore_index=True),
        "parameters": pd.concat(parameter_frames, ignore_index=True) if parameter_frames else pd.DataFrame(),
        "diagnostics": pd.DataFrame(diagnostics),
        "configs": configs,
    }


def deterministic_equal(first: dict, second: dict) -> bool:
    frame_keys = ["results", "importance", "probabilities", "parameters", "diagnostics"]
    return all(first[key].equals(second[key]) for key in frame_keys) and first["configs"] == second["configs"]


def load_comparison(final_results: pd.DataFrame) -> pd.DataFrame:
    logistic = pd.read_csv(LOGISTIC_RESULTS, encoding="utf-8-sig")
    logistic = logistic[(logistic["model"] == "Model A") & (logistic["split"] == "TEST")].copy()
    logistic.insert(1, "algorithm", "Logistic Regression")
    logistic["comparison_model"] = "Model A Logistic"

    forest = pd.read_csv(RF_RESULTS, encoding="utf-8-sig")
    forest = forest[(forest["model"] == "Model A") & (forest["split"] == "TEST")].copy()
    forest.insert(1, "algorithm", "Random Forest")
    forest["comparison_model"] = "Model A Random Forest"

    model_c = pd.read_csv(MODEL_C_RESULTS, encoding="utf-8-sig")
    model_c = model_c[(model_c["model"] == "Model C") & (model_c["split"] == "TEST")].copy()
    model_c["comparison_model"] = model_c["algorithm"].map({
        "Logistic Regression": "Model C Logistic",
        "Random Forest": "Model C Random Forest",
    })

    final = final_results[final_results["split"] == "TEST"].copy()
    final["comparison_model"] = "Final XGBoost"
    combined = pd.concat([logistic, forest, model_c, final], ignore_index=True, sort=False)
    columns = [
        "comparison_model", "algorithm", "preprocessing", "split", "n", "roc_auc", "pr_auc", "brier",
        "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope",
    ]
    return combined[columns].sort_values(
        ["preprocessing", "comparison_model"],
        key=lambda s: s.map({"P1": 0, "P2": 1}) if s.name == "preprocessing" else s,
    ).reset_index(drop=True)


def markdown_table(frame: pd.DataFrame) -> str:
    table = frame.copy()
    for column in table.columns:
        if pd.api.types.is_float_dtype(table[column]):
            table[column] = table[column].map(lambda x: "" if pd.isna(x) else f"{x:.4f}")
    headers = list(table.columns)
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    lines.extend("| " + " | ".join(row) + " |" for row in table.astype(str).itertuples(index=False, name=None))
    return "\n".join(lines)


def main() -> None:
    execution_timestamp = os.environ.get("FINAL_XGBOOST_EXECUTION_TIMESTAMP_UTC") or datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    input_sha_before = sha256(INPUT)
    input_size_before = INPUT.stat().st_size
    eligible, gate = gate_input()
    first = run_all(eligible)
    second = run_all(eligible)
    deterministic = deterministic_equal(first, second)
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated XGBoost outputs differ")

    comparison = load_comparison(first["results"])
    final_test = first["results"][first["results"]["split"] == "TEST"].copy()
    prior = comparison[comparison["comparison_model"] != "Final XGBoost"]
    deltas = []
    for _, current in final_test.iterrows():
        matching = prior[prior["preprocessing"] == current["preprocessing"]]
        for _, baseline in matching.iterrows():
            deltas.append({
                "preprocessing": current["preprocessing"],
                "comparator": baseline["comparison_model"],
                "roc_auc_delta_xgb_minus_comparator": current["roc_auc"] - baseline["roc_auc"],
                "pr_auc_delta_xgb_minus_comparator": current["pr_auc"] - baseline["pr_auc"],
                "brier_delta_xgb_minus_comparator": current["brier"] - baseline["brier"],
            })
    deltas = pd.DataFrame(deltas)

    diagnostics = first["diagnostics"]
    p1 = diagnostics[diagnostics["preprocessing"] == "P1"].iloc[0]
    p2 = diagnostics[diagnostics["preprocessing"] == "P2"].iloc[0]
    source_immutable = sha256(INPUT) == input_sha_before and INPUT.stat().st_size == input_size_before
    parameter_sources_ok = first["parameters"].empty or first["parameters"]["source"].eq("TRAIN_ONLY").all()
    model_fitted = bool(diagnostics["fit_success"].all())
    checks = [
        ("Q1", "Input SHA correct", input_sha_before == EXPECTED_SHA, input_sha_before),
        ("Q2", "Input shape correct", tuple(gate["input_shape"]) == EXPECTED_SHAPE, str(gate["input_shape"])),
        ("Q3", "Target definition unchanged", gate["target_logic_mismatches"] == 0, "decimal-safe recorded target verification"),
        ("Q4", "Target population and class counts", gate["eligible_n"] == 4058 and gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"n={gate['eligible_n']}; 1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q5", "Fixed 11-feature schema", len(FEATURES) == 11, "|".join(FEATURES)),
        ("Q6", "No prohibited X", not bool(set(FEATURES) & PROHIBITED), str(sorted(set(FEATURES) & PROHIBITED))),
        ("Q7", "P1/P2 sample counts coherent", p1.used_n == p1.train_n + p1.test_n and p2.used_n == p2.train_n + p2.test_n, f"P1={p1.used_n}; P2={p2.used_n}"),
        ("Q8", "Fixed temporal split", p2.train_n == 3136 and p2.test_n == 922, f"train={p2.train_n}; test={p2.test_n}"),
        ("Q9", "Train-only preprocessing", bool(parameter_sources_ok), "all fitted preprocessing parameters tagged TRAIN_ONLY"),
        ("Q10", "No test-derived preprocessing", bool(parameter_sources_ok), "no test statistics used"),
        ("Q11", "Fixed XGBoost parameters", XGB_PARAMS["n_estimators"] == 500 and XGB_PARAMS["random_state"] == SEED and XGB_PARAMS["n_jobs"] == 1, json.dumps(XGB_PARAMS, sort_keys=True)),
        ("Q12", "No early stopping or tuning", "early_stopping_rounds" not in XGB_PARAMS, "fixed single parameter set"),
        ("Q13", "Threshold fixed at 0.5", THRESHOLD == 0.5, str(THRESHOLD)),
        ("Q14", "XGBoost fitted for P1 and P2", model_fitted and set(diagnostics.preprocessing) == {"P1", "P2"}, "two successful fits per execution"),
        ("Q15", "Metrics calculated", not first["results"][["roc_auc", "pr_auc", "brier"]].isna().any().any(), "train/test ROC-AUC, PR-AUC, Brier present"),
        ("Q16", "Deterministic repeated execution", deterministic, "probabilities, metrics, importances, parameters, configs identical"),
        ("Q17", "Input immutable", source_immutable, "hash and file size unchanged"),
        ("Q18", "Provenance limitation retained", len(ADDED_PROVENANCE_LIMITED) == 5, "PROVENANCE_REVIEW_REQUIRED"),
    ]
    failures = [check for check in checks if not check[2]]
    status = "FINAL_XGBOOST_COMPLETE_WITH_WARNINGS" if not failures else "FINAL_XGBOOST_BLOCKED"

    write_csv(first["results"], RESULTS)
    write_csv(first["importance"], IMPORTANCE)
    write_csv(comparison, COMPARISON)

    importance_view = first["importance"][(first["importance"]["importance_type"] == "GAIN")].sort_values(
        ["preprocessing", "rank"]
    ).groupby("preprocessing", as_index=False).head(8)
    comparison_view = comparison[["comparison_model", "preprocessing", "n", "roc_auc", "pr_auc", "brier"]]
    delta_view = deltas[deltas["comparator"].isin(["Model A Logistic", "Model C Logistic", "Model C Random Forest"])]

    def metric_delta(strategy: str, comparator: str, column: str) -> float:
        row = delta_view[(delta_view["preprocessing"] == strategy) & (delta_view["comparator"] == comparator)]
        return float(row.iloc[0][column])

    prior_best_auc = prior.groupby("preprocessing")["roc_auc"].max()
    auc_context = []
    for _, row in final_test.iterrows():
        auc_context.append(
            f"{row.preprocessing}: XGBoost {row.roc_auc:.4f}; strongest existing comparator {prior_best_auc[row.preprocessing]:.4f}; difference {row.roc_auc - prior_best_auc[row.preprocessing]:+.4f}"
        )
    decision = "FINAL_PREDICTION_ROUTE_NOT_SUPPORTED_BY_CURRENT_FEATURE_SET"

    spec_lines = [
        "# Final Predictive Model: XGBoost v1", "",
        "## Executive Conclusion", "",
        f"**Decision: `{decision}`.** Under the fixed out-of-time design, XGBoost did not show a clear, consistent improvement over the existing approximately 0.63 ROC-AUC baselines. " + "; ".join(auc_context) + ". The result is a provenance-limited predictive experiment, not a formally cleared T−1 or deployment model.", "",
        "The evidence supports the narrower conclusion that, with the current data, target definition, eleven recorded features, and fixed temporal holdout, the study has not observed performance sufficient to support high-performing pre-release rating-drop prediction. It does not establish that machine learning can never predict sequel reception.", "",
        "## 1. Fixed specification", "",
        f"- Input: `{INPUT.relative_to(ROOT)}`", f"- Input SHA256: `{input_sha_before}`", f"- Input shape: {EXPECTED_SHAPE[0]:,} rows × {EXPECTED_SHAPE[1]} columns",
        "- Y: existing `rating_drop`; eligible only when `rating_valid=TRUE` and target is nonmissing.",
        "- Threshold: recorded rating change ≤ -0.2 gives 1; otherwise 0 among valid pairs.",
        "- Train: `release_year <= 2020`; Test: `release_year >= 2021`.",
        "- Classification threshold: 0.5.",
        "- This execution used no early stopping, tuning, resampling, class weighting, feature selection, or external enrichment.", "",
        "### Fixed feature order", "",
        "\n".join(f"{i}. `{feature}`" for i, feature in enumerate(FEATURES, 1)), "",
        "The final five fields remain `PROVENANCE_REVIEW_REQUIRED`; recorded values are not proof of T−1 availability.", "",
        "## 2. Preprocessing", "",
        f"- P1 complete cases: {int(p1.used_n):,} of 4,058; train={int(p1.train_n):,}, test={int(p1.test_n):,}.",
        f"- P2 train-only median imputation and train-defined missing indicators: 4,058; train={int(p2.train_n):,}, test={int(p2.test_n):,}.",
        "- Numeric and boolean model inputs were standardized using training means and population standard deviations only; test data received those fixed parameters.",
        "- Missing booleans were not interpreted as FALSE; imputation occurred only in the technical P2 model matrix.", "",
        "## 3. Fixed XGBoost parameters", "",
        "```json", json.dumps(XGB_PARAMS, ensure_ascii=False, indent=2, sort_keys=True), "```", "",
        "XGBoost 3.0.5 was compiled without OpenMP as an API/runtime compatibility adjustment. `n_jobs=1` and every requested learning parameter remained unchanged.", "",
        "## 4. XGBoost results", "", markdown_table(first["results"][["preprocessing", "split", "n", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope", "calibration_status"]]), "",
        "## 5. Comparison with completed models", "", markdown_table(comparison_view), "",
        "### XGBoost metric differences", "", markdown_table(delta_view), "",
        "These are descriptive held-out comparisons. They were not used to alter parameters, features, target, split, or preprocessing.", "",
        "## 6. Feature importance", "", markdown_table(importance_view[["preprocessing", "feature", "importance", "normalized_importance", "rank"]]), "",
        "Importance reflects how this fitted boosting model used recorded predictors. It is neither a causal effect nor independent contribution and was not used for feature selection.", "",
        "## 7. Calibration and performance interpretation", "",
        "Calibration intercept and slope were estimated by regressing observed outcomes on the logit of predicted probabilities. No recalibration was performed. ROC-AUC, PR-AUC, Brier score, calibration, and fixed-threshold results should be read together; no single metric selected a model.", "",
        "## 8. Limitations", "",
        "- Five continuity/runtime-change inputs remain provenance-limited and have not been proven to represent T−1 snapshots.",
        "- `previous_rating` is mathematically coupled to the change-based Y and may reflect regression to the mean.",
        "- P1 and P2 use different sample compositions.",
        "- The 2026 test cohort is incomplete.",
        "- This single temporal holdout does not establish deployment performance or causality.",
        "- Feature importance is model-specific predictive interpretation only.", "",
        "## 9. Final decision", "",
        f"`{decision}`", "",
        "### Required model comparisons", "",
        f"1. Versus Model A Logistic, XGBoost ROC-AUC changed by {metric_delta('P1', 'Model A Logistic', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P1 and {metric_delta('P2', 'Model A Logistic', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P2. The P1 comparison has different complete-case n because Model C adds five fields; P2 uses the same target-eligible n.",
        f"2. Versus Model C Logistic, XGBoost ROC-AUC changed by {metric_delta('P1', 'Model C Logistic', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P1 and {metric_delta('P2', 'Model C Logistic', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P2. These small, mixed differences do not show a clear advantage.",
        f"3. Versus Model C Random Forest, XGBoost ROC-AUC changed by {metric_delta('P1', 'Model C Random Forest', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P1 and {metric_delta('P2', 'Model C Random Forest', 'roc_auc_delta_xgb_minus_comparator'):+.4f} in P2, while Brier score was worse by {metric_delta('P1', 'Model C Random Forest', 'brier_delta_xgb_minus_comparator'):+.4f} and {metric_delta('P2', 'Model C Random Forest', 'brier_delta_xgb_minus_comparator'):+.4f}, respectively.",
        "4. The combination of approximately 0.633 test ROC-AUC, modest PR-AUC, shallow test calibration slopes, and near-perfect training discrimination does not provide sufficient evidence of practically strong out-of-time prediction under the current design.", "",
        "The final predictive route stops here as prespecified. No additional model, tuning round, threshold change, or feature experiment was initiated.", "",
        f"**STATUS = {status}**", "",
    ]
    SPEC.write_text("\n".join(spec_lines), encoding="utf-8")

    qa_lines = ["# Final XGBoost QA", "", f"**STATUS = {status}**", "", "## Checks", "", "| Test | Objective | Status | Evidence |", "|---|---|---|---|"]
    qa_lines.extend(f"| {test_id} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |" for test_id, objective, passed, evidence in checks)
    qa_lines += [
        "", "## Warnings", "",
        "- The five continuity/runtime-change fields remain `PROVENANCE_REVIEW_REQUIRED`.",
        "- XGBoost was compiled in a temporary environment without OpenMP; requested model parameters, including `n_jobs=1`, were unchanged.",
        "- P1 and P2 have different sample composition.",
        "- `previous_rating` remains mathematically coupled to the outcome definition.",
        "- 2026 is an incomplete test-cohort year.",
        "- No result is a causal estimate or evidence of production/deployment readiness.", "",
    ]
    QA.write_text("\n".join(qa_lines), encoding="utf-8")

    output_hashes = {
        str(path.relative_to(ROOT)): sha256(path)
        for path in [SPEC, RESULTS, IMPORTANCE, COMPARISON, QA]
    }
    manifest = {
        "status": status,
        "final_decision": decision,
        "execution_timestamp_utc": execution_timestamp,
        "input_path": str(INPUT.relative_to(ROOT)),
        "input_sha256": input_sha_before,
        "input_shape": list(EXPECTED_SHAPE),
        "input_immutable": source_immutable,
        "target": "rating_drop",
        "target_definition": "rating_valid TRUE and recorded rating change <= -0.2",
        "eligible_n": gate["eligible_n"],
        "target_counts": {"1": gate["drop_n"], "0": gate["non_drop_n"]},
        "features": FEATURES,
        "provenance_limited_features": ADDED_PROVENANCE_LIMITED,
        "provenance_status": "PROVENANCE_REVIEW_REQUIRED",
        "preprocessing": {
            "P1": "target-eligible complete cases across all 11 X; train-only scaling",
            "P2": "split first; train-only median imputation; train-defined original-missingness indicators; train-only scaling",
        },
        "train_rule": "release_year <= 2020",
        "test_rule": "release_year >= 2021",
        "classification_threshold": THRESHOLD,
        "xgboost_parameters": XGB_PARAMS,
        "random_seed": SEED,
        "xgboost_build_info": xgboost.build_info(),
        "api_compatibility_adjustment": "XGBoost 3.0.5 built without OpenMP in temporary environment; no requested model parameter changed",
        "sample_diagnostics": diagnostics.to_dict(orient="records"),
        "missingness": gate["missingness"],
        "preprocessing_parameters": first["parameters"].to_dict(orient="records"),
        "deterministic_repeated_execution": deterministic,
        "determinism_scope": "predictions, probabilities, metrics, feature importance, preprocessing parameters, model configs",
        "qa": {"pass": sum(bool(check[2]) for check in checks), "fail": len(failures), "failed_tests": [check[0] for check in failures]},
        "specifications": {
            str(PREPROCESSING_SPEC.relative_to(ROOT)): sha256(PREPROCESSING_SPEC),
            str(MODEL_C_SPEC.relative_to(ROOT)): sha256(MODEL_C_SPEC),
        },
        "comparison_sources": {
            str(LOGISTIC_RESULTS.relative_to(ROOT)): sha256(LOGISTIC_RESULTS),
            str(RF_RESULTS.relative_to(ROOT)): sha256(RF_RESULTS),
            str(MODEL_C_RESULTS.relative_to(ROOT)): sha256(MODEL_C_RESULTS),
        },
        "outputs": output_hashes,
        "script": str(Path(__file__).relative_to(ROOT)),
        "script_sha256": sha256(Path(__file__)),
        "software": {
            "python": platform.python_version(),
            "xgboost": xgboost.__version__,
            "pandas": pd.__version__,
            "numpy": np.__version__,
            "scipy": scipy.__version__,
            "scikit_learn": sklearn.__version__,
            "statsmodels": statsmodels.__version__,
        },
        "warnings": [
            "five added features remain provenance-review required",
            "XGBoost compiled without OpenMP as runtime compatibility adjustment",
            "P1/P2 sample composition differs",
            "previous-rating mathematical coupling",
            "2026 incomplete",
        ],
        "prohibited_actions_executed": [],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit(f"FINAL XGBOOST BLOCKED: {[check[0] for check in failures]}")
    print(first["results"].to_string(index=False))
    print("\nDELTAS\n" + delta_view.to_string(index=False))
    print(f"STATUS={status}")
    print(f"DECISION={decision}")


if __name__ == "__main__":
    main()
