#!/usr/bin/env python3
"""Final, prespecified Random Forest tuning for Movie Sequel Fatigue."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd
import scipy
import sklearn
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import TimeSeriesSplit

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from run_logistic_regression_tuned_v1 import (  # noqa: E402
    EXPECTED_SHA, EXPECTED_SHAPE, FEATURES, PROHIBITED, THRESHOLD,
    evaluate, fit_preprocessor, gate_input, numeric_x, outer_population,
    sha256, write_csv,
)

INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
PREPROCESSING_SPEC = ROOT / "reports/ml_preprocessing_spec_v1.md"
BASELINE_RESULTS = ROOT / "reports/random_forest_v1_results.csv"
SPEC = ROOT / "reports/random_forest_tuned_v1_spec.md"
CV_RESULTS = ROOT / "reports/random_forest_tuned_v1_cv_results.csv"
RESULTS = ROOT / "reports/random_forest_tuned_v1_results.csv"
IMPORTANCE = ROOT / "reports/random_forest_tuned_v1_feature_importance.csv"
MANIFEST = ROOT / "reports/random_forest_tuned_v1_manifest.json"
QA = ROOT / "reports/random_forest_tuned_v1_qa.md"

SEED = 20260913
CV_FOLDS = 5
N_ESTIMATORS = 500
DEPTHS = [3, 5, 8, None]
LEAVES = [1, 5, 10, 20]
SPLITS = [2, 5, 10]
MAX_FEATURES = ["sqrt", "log2", 0.5]


def rf_model(params: dict) -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=N_ESTIMATORS,
        max_depth=params["max_depth"],
        min_samples_leaf=params["min_samples_leaf"],
        min_samples_split=params["min_samples_split"],
        max_features=params["max_features"],
        bootstrap=True,
        criterion="gini",
        class_weight=None,
        random_state=SEED,
        n_jobs=1,
    )


def grid() -> list[dict]:
    return [
        {"max_depth": depth, "min_samples_leaf": leaf,
         "min_samples_split": split, "max_features": maximum}
        for depth in DEPTHS for leaf in LEAVES for split in SPLITS
        for maximum in MAX_FEATURES
    ]


def fold_cache(eligible: pd.DataFrame, strategy: str) -> tuple[pd.DataFrame, pd.DataFrame, int, list[dict]]:
    outer_train, outer_test, excluded = outer_population(eligible, strategy)
    raw = numeric_x(outer_train)
    y = pd.to_numeric(outer_train["rating_drop"], errors="raise").astype(int)
    cache = []
    for fold, (train_pos, valid_pos) in enumerate(TimeSeriesSplit(n_splits=CV_FOLDS).split(raw), 1):
        x_train, x_valid, parameters, indicators = fit_preprocessor(
            raw.iloc[train_pos].copy(), raw.iloc[valid_pos].copy(), strategy
        )
        y_train = y.iloc[train_pos].to_numpy()
        y_valid = y.iloc[valid_pos].to_numpy()
        if len(np.unique(y_train)) != 2 or len(np.unique(y_valid)) != 2:
            raise RuntimeError(f"{strategy} fold {fold} has a single target class")
        cache.append({
            "fold": fold, "x_train": x_train, "x_valid": x_valid,
            "y_train": y_train, "y_valid": y_valid,
            "train_period": f"{outer_train.iloc[train_pos]['__release_date'].min().date()} to {outer_train.iloc[train_pos]['__release_date'].max().date()}",
            "validation_period": f"{outer_train.iloc[valid_pos]['__release_date'].min().date()} to {outer_train.iloc[valid_pos]['__release_date'].max().date()}",
            "parameters": parameters, "indicators": indicators,
        })
    return outer_train, outer_test, excluded, cache


def tune(eligible: pd.DataFrame, strategy: str) -> dict:
    outer_train, outer_test, excluded, cache = fold_cache(eligible, strategy)
    rows = []
    summaries = []
    for candidate_id, params in enumerate(grid(), 1):
        scores = []
        for item in cache:
            model = rf_model(params)
            model.fit(item["x_train"], item["y_train"])
            probability = model.predict_proba(item["x_valid"])[:, 1]
            score = float(roc_auc_score(item["y_valid"], probability))
            scores.append(score)
            rows.append({
                "preprocessing": strategy, "candidate_id": candidate_id,
                "max_depth": "None" if params["max_depth"] is None else params["max_depth"],
                "min_samples_leaf": params["min_samples_leaf"],
                "min_samples_split": params["min_samples_split"],
                "max_features": params["max_features"], "fold": item["fold"],
                "train_period": item["train_period"], "validation_period": item["validation_period"],
                "train_n": len(item["y_train"]), "validation_n": len(item["y_valid"]),
                "validation_roc_auc": score,
            })
        summaries.append({"candidate_id": candidate_id, "params": params,
                          "mean": float(np.mean(scores)), "std": float(np.std(scores, ddof=0))})
    depth_order = {3: 0, 5: 1, 8: 2, None: 3}
    max_order = {"sqrt": 0, "log2": 1, 0.5: 2}
    best = sorted(summaries, key=lambda x: (
        -x["mean"], depth_order[x["params"]["max_depth"]],
        -x["params"]["min_samples_leaf"], -x["params"]["min_samples_split"],
        max_order[x["params"]["max_features"]],
    ))[0]
    summary_map = {x["candidate_id"]: x for x in summaries}
    for row in rows:
        summary = summary_map[row["candidate_id"]]
        row["mean_cv_roc_auc"] = summary["mean"]
        row["std_cv_roc_auc"] = summary["std"]
        row["selected"] = row["candidate_id"] == best["candidate_id"]
    return {"strategy": strategy, "outer_train": outer_train, "outer_test": outer_test,
            "excluded": excluded, "cv": pd.DataFrame(rows), "best": best}


def fit_selected(tuned: dict) -> dict:
    strategy = tuned["strategy"]
    train, test = tuned["outer_train"], tuned["outer_test"]
    x_train, x_test, parameters, indicators = fit_preprocessor(
        numeric_x(train), numeric_x(test), strategy
    )
    y_train = pd.to_numeric(train["rating_drop"], errors="raise").astype(int).to_numpy()
    y_test = pd.to_numeric(test["rating_drop"], errors="raise").astype(int).to_numpy()
    model = rf_model(tuned["best"]["params"])
    model.fit(x_train, y_train)
    p_train = model.predict_proba(x_train)[:, 1]
    p_test = model.predict_proba(x_test)[:, 1]
    metrics = []
    for split, y, probability in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        metrics.append({
            "model": "Tuned RF Model A", "preprocessing": strategy, "split": split,
            "n": len(y), **evaluate(y, probability),
            "train_test_roc_auc_gap": np.nan,
        })
    metrics = pd.DataFrame(metrics)
    train_auc = float(metrics.loc[metrics["split"] == "TRAIN", "roc_auc"].iloc[0])
    test_auc = float(metrics.loc[metrics["split"] == "TEST", "roc_auc"].iloc[0])
    metrics["train_test_roc_auc_gap"] = train_auc - test_auc

    impurity = pd.DataFrame({
        "preprocessing": strategy, "feature": x_train.columns,
        "importance_type": "IMPURITY", "importance": model.feature_importances_,
        "importance_std": np.nan,
    })
    perm = permutation_importance(
        model, x_test, y_test, scoring="roc_auc", n_repeats=30,
        random_state=SEED, n_jobs=1,
    )
    permutation = pd.DataFrame({
        "preprocessing": strategy, "feature": x_test.columns,
        "importance_type": "TEST_PERMUTATION_ROC_AUC", "importance": perm.importances_mean,
        "importance_std": perm.importances_std,
    })
    importance = pd.concat([impurity, permutation], ignore_index=True)
    importance["rank"] = importance.groupby(["preprocessing", "importance_type"])["importance"].rank(
        method="first", ascending=False
    ).astype(int)
    return {
        "results": metrics, "importance": importance,
        "probabilities": np.concatenate([p_train, p_test]),
        "parameters": parameters, "indicators": indicators,
        "columns": list(x_train.columns), "train_n": len(y_train), "test_n": len(y_test),
    }


def baseline_comparison(results: pd.DataFrame) -> pd.DataFrame:
    baseline = pd.read_csv(BASELINE_RESULTS, encoding="utf-8-sig")
    rows = []
    for strategy in ["P1", "P2"]:
        old_train = baseline[(baseline.model == "Model A") & (baseline.preprocessing == strategy) & (baseline.split == "TRAIN")].iloc[0]
        old_test = baseline[(baseline.model == "Model A") & (baseline.preprocessing == strategy) & (baseline.split == "TEST")].iloc[0]
        new_train = results[(results.preprocessing == strategy) & (results.split == "TRAIN")].iloc[0]
        new_test = results[(results.preprocessing == strategy) & (results.split == "TEST")].iloc[0]
        rows.append({
            "preprocessing": strategy,
            "original_test_roc_auc": old_test.roc_auc, "tuned_test_roc_auc": new_test.roc_auc,
            "test_roc_auc_delta": new_test.roc_auc - old_test.roc_auc,
            "original_test_pr_auc": old_test.pr_auc, "tuned_test_pr_auc": new_test.pr_auc,
            "test_pr_auc_delta": new_test.pr_auc - old_test.pr_auc,
            "original_test_brier": old_test.brier, "tuned_test_brier": new_test.brier,
            "test_brier_delta": new_test.brier - old_test.brier,
            "original_train_test_roc_gap": old_train.roc_auc - old_test.roc_auc,
            "tuned_train_test_roc_gap": new_train.roc_auc - new_test.roc_auc,
            "roc_gap_delta": (new_train.roc_auc - new_test.roc_auc) - (old_train.roc_auc - old_test.roc_auc),
            "original_calibration_intercept": old_test.calibration_intercept,
            "tuned_calibration_intercept": new_test.calibration_intercept,
            "original_calibration_slope": old_test.calibration_slope,
            "tuned_calibration_slope": new_test.calibration_slope,
        })
    return pd.DataFrame(rows)


def md_table(frame: pd.DataFrame) -> str:
    view = frame.copy()
    for col in view.columns:
        if pd.api.types.is_float_dtype(view[col]):
            view[col] = view[col].map(lambda x: "" if pd.isna(x) else f"{x:.4f}")
    return "\n".join([
        "| " + " | ".join(view.columns) + " |",
        "|" + "|".join(["---"] * len(view.columns)) + "|",
        *("| " + " | ".join(map(str, row)) + " |" for row in view.itertuples(index=False, name=None)),
    ])


def main() -> None:
    timestamp = os.environ.get("RF_TUNING_EXECUTION_TIMESTAMP_UTC") or datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    sha_before, size_before = sha256(INPUT), INPUT.stat().st_size
    eligible, gate = gate_input()
    tuned = [tune(eligible, strategy) for strategy in ["P1", "P2"]]
    fitted = [fit_selected(item) for item in tuned]
    # Empirical deterministic check: independently refit each selected final model.
    repeated = [fit_selected(item) for item in tuned]
    deterministic = all(
        first["results"].equals(second["results"])
        and first["importance"].equals(second["importance"])
        and np.array_equal(first["probabilities"], second["probabilities"])
        for first, second in zip(fitted, repeated)
    )
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated selected-model execution differs")
    cv = pd.concat([item["cv"] for item in tuned], ignore_index=True)
    results = pd.concat([item["results"] for item in fitted], ignore_index=True)
    importance = pd.concat([item["importance"] for item in fitted], ignore_index=True)
    comparison = baseline_comparison(results)
    deltas = comparison["test_roc_auc_delta"].to_numpy()
    gaps = comparison["roc_gap_delta"].to_numpy()
    if np.all(deltas < 0):
        decision = "FINAL_RF_TUNING_DID_NOT_IMPROVE"
    elif not (np.all(deltas > 0) and np.all(gaps < 0)):
        decision = "FINAL_RF_TUNING_NO_MEANINGFUL_IMPROVEMENT"
    else:
        # The final report still considers PR-AUC, Brier and calibration before using
        # the improvement label; no value here can alter the selected model.
        pr_ok = np.all(comparison["test_pr_auc_delta"].to_numpy() > 0)
        brier_ok = np.all(comparison["test_brier_delta"].to_numpy() < 0)
        decision = "FINAL_RF_TUNING_SHOWS_IMPROVEMENT" if pr_ok and brier_ok else "FINAL_RF_TUNING_NO_MEANINGFUL_IMPROVEMENT"

    input_immutable = sha256(INPUT) == sha_before and INPUT.stat().st_size == size_before
    selected = {item["strategy"]: item["best"] for item in tuned}
    tests = [
        ("Q1", "Input SHA correct", sha_before == EXPECTED_SHA, sha_before),
        ("Q2", "Input shape correct", tuple(gate["input_shape"]) == EXPECTED_SHAPE, str(gate["input_shape"])),
        ("Q3", "Target population/counts correct", gate["eligible_n"] == 4058 and gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"n={gate['eligible_n']}; 1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q4", "Exactly six Model A X", len(FEATURES) == 6, "|".join(FEATURES)),
        ("Q5", "No prohibited X", not bool(set(FEATURES) & PROHIBITED), str(sorted(set(FEATURES) & PROHIBITED))),
        ("Q6", "Outer split fixed", gate["outer_train_n"] == 3136 and gate["outer_test_n"] == 922, f"train={gate['outer_train_n']}; test={gate['outer_test_n']}"),
        ("Q7", "TimeSeriesSplit five folds", cv.groupby("preprocessing")["fold"].nunique().eq(5).all(), "five folds per strategy"),
        ("Q8", "All CV validation ends by 2020", cv.validation_period.str[-10:].le("2020-12-31").all(), cv.validation_period.max()),
        ("Q9", "Exactly 144 candidates per strategy", cv.groupby("preprocessing")["candidate_id"].nunique().eq(144).all(), str(cv.groupby("preprocessing")["candidate_id"].nunique().to_dict())),
        ("Q10", "Every candidate has five folds", cv.groupby(["preprocessing", "candidate_id"]).size().eq(5).all(), "720 rows per strategy"),
        ("Q11", "P2 preprocessing parameters training-only", all(all(x["source"] == "TRAIN_ONLY" for x in fit["parameters"]) for fit in fitted), "TRAIN_ONLY"),
        ("Q12", "Outer test not used in tuning", cv.validation_period.str[-10:].le("2020-12-31").all(), "outer test starts 2021"),
        ("Q13", "Classification threshold fixed", THRESHOLD == 0.5, str(THRESHOLD)),
        ("Q14", "RF seed fixed", SEED == 20260913, str(SEED)),
        ("Q15", "500 trees fixed", N_ESTIMATORS == 500, str(N_ESTIMATORS)),
        ("Q16", "n_jobs fixed", rf_model(grid()[0]).n_jobs == 1, "1"),
        ("Q17", "No class weighting", rf_model(grid()[0]).class_weight is None, "None"),
        ("Q18", "No resampling/outlier deletion", True, "not implemented"),
        ("Q19", "No unauthorized features", all(set(fit["columns"]).issubset(set(FEATURES) | {f'{f}__missing' for f in FEATURES}) for fit in fitted), str([x["columns"] for x in fitted])),
        ("Q20", "Selected final models deterministic", deterministic, str(deterministic)),
        ("Q21", "Input immutable", input_immutable, sha256(INPUT)),
        ("Q22", "Permutation importance uses 30 test repeats", True, "n_repeats=30; scoring=roc_auc; seed=20260913"),
    ]
    failures = [test_id for test_id, _, passed, _ in tests if not passed]
    if failures:
        decision = "RANDOM_FOREST_TUNING_BLOCKED"
    write_csv(cv, CV_RESULTS)
    write_csv(results, RESULTS)
    write_csv(importance, IMPORTANCE)

    spec_text = f"""# Final Random Forest Tuning Specification v1

## Purpose

This is the final Random Forest experiment. It tests whether training-only complexity control improves out-of-time performance relative to the fixed unrestricted Model A Random Forest. No feature, target, threshold, or split changes are permitted.

## Fixed design

- Input: `{INPUT.relative_to(ROOT)}`; approved SHA256 `{EXPECTED_SHA}`; expected shape 6,481 × 50.
- Target: existing `rating_drop`; eligible only when `rating_valid = TRUE` and target is nonmissing; threshold definition remains rating change ≤ −0.2.
- X, fixed order: {', '.join(FEATURES)}.
- Outer train: `release_year <= 2020`; outer test: `release_year >= 2021`.
- P1: complete cases. P2: split first, training-only medians, training-defined missing indicators, and training-only mean/population-SD scaling. Every CV fold independently learns preprocessing.
- CV: `TimeSeriesSplit(n_splits=5)` within outer training only; selection criterion mean validation ROC-AUC.
- Grid: max_depth={DEPTHS}; min_samples_leaf={LEAVES}; min_samples_split={SPLITS}; max_features={MAX_FEATURES}; 144 combinations per strategy.
- Fixed RF: 500 trees, bootstrap, gini, no class weighting, random_state={SEED}, n_jobs=1.
- Tie-break: smaller depth, larger minimum leaf, larger minimum split, then max_features order sqrt/log2/0.5.
- Classification threshold: 0.5. No tuning, feature selection, resampling, or second-round tuning.
- Permutation importance: outer test, ROC-AUC, 30 repeats, seed {SEED}; interpretation only.

## Stop rule

After P1 and P2 are evaluated once on outer test, the experiment stops regardless of result.
"""
    SPEC.write_text(spec_text, encoding="utf-8")

    result_view = results[["preprocessing", "split", "n", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope", "train_test_roc_auc_gap"]]
    selected_view = pd.DataFrame([{
        "preprocessing": strategy,
        "max_depth": "None" if best["params"]["max_depth"] is None else str(best["params"]["max_depth"]),
        "min_samples_leaf": best["params"]["min_samples_leaf"],
        "min_samples_split": best["params"]["min_samples_split"],
        "max_features": str(best["params"]["max_features"]),
        "mean_cv_roc_auc": best["mean"], "std_cv_roc_auc": best["std"],
    } for strategy, best in selected.items()])
    top_importance = importance[importance.importance_type == "TEST_PERMUTATION_ROC_AUC"].sort_values(["preprocessing", "rank"]).groupby("preprocessing").head(3)
    report = f"""# Final Random Forest Tuning v1 Report

## Design and population

The approved input passed its SHA, shape, identity, target-logic, and target-count gates. The target-eligible population is {gate['eligible_n']:,} rows ({gate['drop_n']:,} drop; {gate['non_drop_n']:,} non-drop). Tuning used only the outer training cohort and the fixed five-fold time-series procedure. The 2026 cohort is incomplete and remains in the prespecified outer test cohort.

## Selected training-only hyperparameters

{md_table(selected_view)}

## Final metrics

{md_table(result_view)}

## Comparison with the original unrestricted Random Forest

{md_table(comparison)}

Lower train ROC-AUC is not itself evidence of improvement. The relevant evidence is the out-of-time test ROC-AUC together with PR-AUC, Brier score, calibration, and the train–test gap. Parameter selection did not use outer-test results.

## Permutation importance (three highest per preprocessing run)

{md_table(top_importance[['preprocessing', 'feature', 'importance', 'importance_std', 'rank']])}

These importances are test-set, descriptive model interpretations only. They do not establish causality and were not used for feature selection or retraining.

## Final decision

**{decision}**

- P1 test ROC-AUC: {results[(results.preprocessing == 'P1') & (results.split == 'TEST')].roc_auc.iloc[0]:.4f}; change from original RF: {comparison[comparison.preprocessing == 'P1'].test_roc_auc_delta.iloc[0]:+.4f}.
- P2 test ROC-AUC: {results[(results.preprocessing == 'P2') & (results.split == 'TEST')].roc_auc.iloc[0]:.4f}; change from original RF: {comparison[comparison.preprocessing == 'P2'].test_roc_auc_delta.iloc[0]:+.4f}.
- P1/P2 direction is {'consistent' if np.sign(deltas[0]) == np.sign(deltas[1]) else 'not consistent'} relative to the original RF.

This is predictive, not causal, analysis. `previous_rating` remains mathematically coupled to the change-based target, `release_year` is temporal context, and the 2026 cohort is incomplete. No subsequent tuning or model experiment is initiated.
"""
    (ROOT / "reports/random_forest_tuned_v1_report.md").write_text(report, encoding="utf-8")

    qa_lines = ["# Final Random Forest Tuning v1 QA", "", f"STATUS = {'PASS' if not failures else 'BLOCKED'}", "", "| Test | Objective | Status | Actual |", "|---|---|---|---|"]
    qa_lines += [f"| {tid} | {objective} | {'PASS' if passed else 'FAIL'} | {actual} |" for tid, objective, passed, actual in tests]
    qa_lines += ["", "## Critical result", "", f"Critical failures: {len(failures)}" + (f" ({', '.join(failures)})" if failures else "."), "", "No outer-test observation participated in tuning or preprocessing fitting. No second tuning round was performed."]
    QA.write_text("\n".join(qa_lines) + "\n", encoding="utf-8")

    manifest = {
        "experiment": "Final Random Forest Tuning v1", "execution_timestamp_utc": timestamp,
        "input_path": str(INPUT.relative_to(ROOT)), "input_sha256": sha_before,
        "input_shape": gate["input_shape"], "input_immutable": input_immutable,
        "target": "rating_drop", "target_threshold": "rating_change <= -0.2",
        "eligible_n": gate["eligible_n"], "drop_n": gate["drop_n"], "non_drop_n": gate["non_drop_n"],
        "features": FEATURES, "outer_train_rule": "release_year <= 2020",
        "outer_test_rule": "release_year >= 2021", "cv": "TimeSeriesSplit(n_splits=5)",
        "selection_criterion": "mean validation ROC-AUC within outer training only",
        "grid_candidates_per_strategy": 144, "strategies": ["P1", "P2"],
        "fixed_parameters": {"n_estimators": 500, "bootstrap": True, "criterion": "gini", "class_weight": None, "random_state": SEED, "n_jobs": 1},
        "selected": {strategy: {**best["params"], "mean_cv_roc_auc": best["mean"], "std_cv_roc_auc": best["std"]} for strategy, best in selected.items()},
        "classification_threshold": 0.5, "permutation_importance": {"split": "TEST", "n_repeats": 30, "scoring": "roc_auc", "seed": SEED},
        "baseline_results_path": str(BASELINE_RESULTS.relative_to(ROOT)), "baseline_results_sha256": sha256(BASELINE_RESULTS),
        "preprocessing_spec_path": str(PREPROCESSING_SPEC.relative_to(ROOT)), "preprocessing_spec_sha256": sha256(PREPROCESSING_SPEC),
        "script_path": str(Path(__file__).resolve().relative_to(ROOT)), "script_sha256": sha256(Path(__file__).resolve()),
        "software": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__},
        "deterministic_selected_model_repeat": deterministic, "qa_failures": failures,
        "decision": decision,
        "output_files": [str(p.relative_to(ROOT)) for p in [SPEC, CV_RESULTS, RESULTS, IMPORTANCE, MANIFEST, QA, ROOT / "reports/random_forest_tuned_v1_report.md"]],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit(f"CRITICAL FAILURE: {failures}")
    print(json.dumps({"decision": decision, "selected": manifest["selected"], "comparison": comparison.to_dict(orient="records"), "deterministic": deterministic}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
