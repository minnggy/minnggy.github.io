#!/usr/bin/env python3
"""Controlled deterministic transformation for the classmate movie-sequel master.

This program is intentionally narrow: it preserves the source population and its
recorded fields, adds only rating_valid and rating_drop, runs the approved test
plan, and publishes the output only when all CRITICAL tests pass.
"""

from __future__ import annotations

import csv
import hashlib
import json
import math
import os
import re
import shutil
import tempfile
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MASTER = ROOT / "data/processed/movie_sequel_master_classmate_v1.csv"
OUTPUT = ROOT / "data/processed/movie_sequel_analysis_v1.csv"
SPEC = ROOT / "reports/movie_sequel_transformation_spec_v1.md"
REGISTRY = ROOT / "reports/movie_sequel_transformation_field_registry_v1.csv"
TEST_PLAN = ROOT / "reports/movie_sequel_transformation_test_plan_v1.md"
REPORT = ROOT / "reports/movie_sequel_analysis_v1_transformation_report.md"
TEST_RESULTS = ROOT / "reports/movie_sequel_analysis_v1_test_results.csv"
MANIFEST = ROOT / "reports/movie_sequel_analysis_v1_manifest.json"
APPROVED_MASTER_SHA256 = "aa2ef613ea1d41acb0bb3a7cf051025e4f5274b40a901eb931c91b0d631ded35"
EXPECTED_ROWS = 6481
EXPECTED_COLUMNS = 42
ADDED_COLUMNS = ["rating_valid", "rating_drop"]
BOOL_COLUMNS = ["導演是否更換", "主演是否更換"]
DERIVED_COLUMNS = [
    "與前作評分差",
    "與前作片長差",
    "片長變化率",
    "與前作預算差",
    "預算變化率",
    "與前作票房差",
    "票房變化率",
]
FINANCIAL_COLUMNS = [
    "預算",
    "前作預算",
    "與前作預算差",
    "預算變化率",
    "票房",
    "前作票房",
    "與前作票房差",
    "票房變化率",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def file_metadata(path: Path) -> dict:
    stat = path.stat()
    return {
        "size_bytes": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
        "inode": stat.st_ino,
        "mode": oct(stat.st_mode),
    }


def read_csv_rows(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        header = list(reader.fieldnames or [])
        rows = [{key: (value if value is not None else "") for key, value in row.items()} for row in reader]
    return header, rows


def read_registry() -> list[dict[str, str]]:
    _, rows = read_csv_rows(REGISTRY)
    return rows


def parse_test_plan() -> dict[str, dict[str, str]]:
    tests: dict[str, dict[str, str]] = {}
    pattern = re.compile(r"^\|\s*([A-Z]{2}-\d{2})\s*\|(.*)$")
    for line in TEST_PLAN.read_text(encoding="utf-8").splitlines():
        match = pattern.match(line)
        if not match:
            continue
        cells = [match.group(1)] + [part.strip() for part in match.group(2).split("|")]
        if cells and cells[-1] == "":
            cells.pop()
        if len(cells) != 7:
            raise RuntimeError(f"Cannot parse test-plan row: {line}")
        test_id, objective, input_condition, expected, severity, execution, failure_action = cells
        tests[test_id] = {
            "test_id": test_id,
            "objective": objective.replace("`", ""),
            "input_condition": input_condition.replace("`", ""),
            "expected": expected.replace("`", ""),
            "severity": severity,
            "execution": "EXECUTED_" + execution,
            "failure_action": failure_action,
        }
    if len(tests) != 78:
        raise RuntimeError(f"Expected 78 tests in plan; found {len(tests)}")
    return tests


def decimal_or_none(value: str) -> Decimal | None:
    if value is None or value.strip() == "":
        return None
    try:
        number = Decimal(value.strip())
    except InvalidOperation:
        return None
    return number if number.is_finite() else None


def derive_rating(current: str | None, previous: str | None, change: str | None) -> tuple[bool, int | None]:
    current_d = decimal_or_none(current or "")
    previous_d = decimal_or_none(previous or "")
    change_d = decimal_or_none(change or "")
    valid = bool(
        current_d is not None
        and previous_d is not None
        and change_d is not None
        and current_d > Decimal("0")
        and previous_d > Decimal("0")
    )
    if not valid:
        return False, None
    return True, int(change_d <= Decimal("-0.2"))


def convert_boolean(value: str) -> str:
    if value == "":
        return ""
    number = decimal_or_none(value)
    if number == Decimal("0"):
        return "FALSE"
    if number == Decimal("1"):
        return "TRUE"
    raise ValueError(f"Invalid boolean token: {value!r}")


def transform_rows(master_columns: list[str], source_rows: list[dict[str, str]]) -> tuple[list[str], list[dict[str, str]]]:
    output_columns = master_columns + ADDED_COLUMNS
    output_rows: list[dict[str, str]] = []
    for source in source_rows:
        target = {column: source[column] for column in master_columns}
        # The only authorized original-column representation conversion is the
        # registry-defined 0/1/NA -> TRUE/FALSE/empty nullable-boolean mapping.
        for column in BOOL_COLUMNS:
            target[column] = convert_boolean(source[column])
        rating_valid, rating_drop = derive_rating(source["平均評分"], source["前作評分"], source["與前作評分差"])
        target["rating_valid"] = "TRUE" if rating_valid else "FALSE"
        target["rating_drop"] = "" if rating_drop is None else str(rating_drop)
        output_rows.append(target)
    return output_columns, output_rows


def write_csv(path: Path, columns: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # UTF-8-SIG writes the standard UTF-8 BOM. This preserves Unicode while
    # allowing Excel to recognize Chinese column names without manual import.
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, lineterminator="\n", extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def normalized_value(column: str, value: str) -> object:
    if value == "":
        return None
    if column in BOOL_COLUMNS:
        if value in {"0", "0.0", "FALSE"}:
            return False
        if value in {"1", "1.0", "TRUE"}:
            return True
    return value


def preserved(source_rows: list[dict[str, str]], output_rows: list[dict[str, str]], columns: list[str]) -> bool:
    return all(
        normalized_value(column, source[column]) == normalized_value(column, output[column])
        for source, output in zip(source_rows, output_rows)
        for column in columns
    )


def na_masks_equal(source_rows: list[dict[str, str]], output_rows: list[dict[str, str]], columns: list[str]) -> bool:
    return all((source[column] == "") == (output[column] == "") for source, output in zip(source_rows, output_rows) for column in columns)


def source_counts(rows: list[dict[str, str]]) -> dict[str, int]:
    return dict(sorted(Counter(row["資料來源"] for row in rows).items()))


def missing_counts(rows: list[dict[str, str]], columns: list[str]) -> dict[str, int]:
    return {column: sum(row[column] == "" for row in rows) for column in columns}


def formula_qa(rows: list[dict[str, str]]) -> dict[str, dict[str, int]]:
    specs = {
        "rating_difference": ("平均評分", "前作評分", "與前作評分差", "difference"),
        "runtime_difference": ("片長(分鐘)", "前作片長", "與前作片長差", "difference"),
        "runtime_rate": ("片長(分鐘)", "前作片長", "片長變化率", "rate"),
        "budget_difference": ("預算", "前作預算", "與前作預算差", "difference"),
        "budget_rate": ("預算", "前作預算", "預算變化率", "rate"),
        "revenue_difference": ("票房", "前作票房", "與前作票房差", "difference"),
        "revenue_rate": ("票房", "前作票房", "票房變化率", "rate"),
    }
    results: dict[str, dict[str, int]] = {}
    tolerance = Decimal("0.000000000001")
    for name, (current_col, previous_col, recorded_col, kind) in specs.items():
        comparable = 0
        mismatch = 0
        denominator_zero_with_recorded = 0
        for row in rows:
            current = decimal_or_none(row[current_col])
            previous = decimal_or_none(row[previous_col])
            recorded = decimal_or_none(row[recorded_col])
            if current is None or previous is None or recorded is None:
                continue
            if kind == "rate" and previous == 0:
                denominator_zero_with_recorded += 1
                continue
            expected = current - previous if kind == "difference" else (current - previous) / previous
            comparable += 1
            if abs(expected - recorded) > tolerance:
                mismatch += 1
        results[name] = {
            "comparable": comparable,
            "mismatch_at_1e-12": mismatch,
            "zero_denominator_with_recorded": denominator_zero_with_recorded,
        }
    return results


def main() -> int:
    execution_timestamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    master_sha_before = sha256(MASTER)
    master_metadata_before = file_metadata(MASTER)
    if master_sha_before != APPROVED_MASTER_SHA256:
        raise SystemExit("CRITICAL GATE FAIL: master SHA256 is not the approved snapshot; no files were written.")

    master_columns, master_rows = read_csv_rows(MASTER)
    registry_rows = read_registry()
    registry_columns = [row["column"] for row in registry_rows]
    if len(master_rows) != EXPECTED_ROWS or len(master_columns) != EXPECTED_COLUMNS:
        raise SystemExit("CRITICAL GATE FAIL: input shape differs from 6481 x 42; no files were written.")
    if master_columns != registry_columns or len(set(registry_columns)) != EXPECTED_COLUMNS:
        raise SystemExit("CRITICAL GATE FAIL: master schema and registry do not match exactly; no files were written.")

    plan = parse_test_plan()
    results: dict[str, dict[str, str]] = {}

    def record(test_id: str, passed: bool, actual: object, message: str = "", warn: bool = False) -> None:
        meta = plan[test_id]
        status = "WARN" if warn else ("PASS" if passed else "FAIL")
        results[test_id] = {
            "test_id": test_id,
            "objective": meta["objective"],
            "severity": meta["severity"],
            "execution": meta["execution"],
            "actual": str(actual),
            "expected": meta["expected"],
            "status": status,
            "message": message or ("符合規格。" if passed else meta["failure_action"]),
        }

    registry_types = {row["column"]: row["target_type"] for row in registry_rows}
    numeric_columns = [column for column, kind in registry_types.items() if "integer" in kind or "float" in kind]
    integer_columns = [column for column, kind in registry_types.items() if "integer" in kind]
    text_columns = [column for column, kind in registry_types.items() if kind in {"text", "categorical text", "categorical boolean", "identity string"}]
    tmdb_values = [row["TMDB ID"] for row in master_rows]
    imdb_values = [row["IMDb ID"] for row in master_rows if row["IMDb ID"] != ""]
    numeric_bad = [(i + 2, column, row[column]) for i, row in enumerate(master_rows) for column in numeric_columns if row[column] != "" and decimal_or_none(row[column]) is None]
    integer_bad = [(i + 2, column, row[column]) for i, row in enumerate(master_rows) for column in integer_columns if row[column] != "" and (decimal_or_none(row[column]) is None or decimal_or_none(row[column]) != decimal_or_none(row[column]).to_integral_value())]
    date_bad = [(i + 2, row["上映日期"]) for i, row in enumerate(master_rows) if row["上映日期"] and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", row["上映日期"])]
    date_parse_bad = []
    year_mismatch = []
    for i, row in enumerate(master_rows):
        if not row["上映日期"]:
            continue
        try:
            parsed = datetime.strptime(row["上映日期"], "%Y-%m-%d").date()
        except ValueError:
            date_parse_bad.append((i + 2, row["上映日期"]))
            continue
        year = decimal_or_none(row["上映年"])
        if year is not None and int(year) != parsed.year:
            year_mismatch.append((i + 2, row["上映日期"], row["上映年"]))

    bool_bad = {
        column: [(i + 2, row[column]) for i, row in enumerate(master_rows) if row[column] and decimal_or_none(row[column]) not in {Decimal("0"), Decimal("1")}]
        for column in BOOL_COLUMNS
    }

    record("IN-01", len(master_rows) == 6481, len(master_rows))
    record("IN-02", len(master_columns) == 42, len(master_columns))
    record("IN-03", set(registry_columns).issubset(master_columns), f"missing={sorted(set(registry_columns)-set(master_columns))}")
    record("IN-04", set(master_columns).issubset(registry_columns), f"extra={sorted(set(master_columns)-set(registry_columns))}")
    record("IN-05", len(registry_rows) == 42 and len(set(registry_columns)) == 42 and master_columns == registry_columns, f"registry_rows={len(registry_rows)}, unique={len(set(registry_columns))}, ordered_match={master_columns == registry_columns}")
    record("IN-06", all(tmdb_values) and len(tmdb_values) == len(set(tmdb_values)), f"missing={sum(v == '' for v in tmdb_values)}, duplicate_affected={len(tmdb_values)-len(set(tmdb_values))}")
    record("IN-07", len(imdb_values) == len(set(imdb_values)), f"nonempty={len(imdb_values)}, duplicate_affected={len(imdb_values)-len(set(imdb_values))}, missing={len(master_rows)-len(imdb_values)}")
    record("IN-08", master_sha_before == APPROVED_MASTER_SHA256, master_sha_before)
    record("SC-01", not numeric_bad, f"parse_failures={len(numeric_bad)}")
    record("SC-02", not integer_bad, f"noninteger_tokens={len(integer_bad)}")
    record("SC-03", not date_bad and not date_parse_bad, f"format_failures={len(date_bad)}, parse_failures={len(date_parse_bad)}")
    record("SC-04", all(isinstance(v, str) for v in imdb_values), f"nonempty string identities={len(imdb_values)}")
    record("SC-05", all(re.fullmatch(r"tt[0-9]+", v) for v in imdb_values), f"regex_failures={sum(re.fullmatch(r'tt[0-9]+', v) is None for v in imdb_values)}")
    record("SC-06", registry_types.get("TMDB ID") == "identity string" and all(isinstance(v, str) for v in tmdb_values), f"logical_type={registry_types.get('TMDB ID')}; literal identities retained")
    record("SC-07", registry_types.get("電影系列ID") == "identity string", f"logical_type={registry_types.get('電影系列ID')}; column name retained")
    record("SC-08", not any(bool_bad.values()), f"input domain valid; missing 導演={sum(r['導演是否更換']=='' for r in master_rows)}, 主演={sum(r['主演是否更換']=='' for r in master_rows)}")
    record("SC-09", True, f"{len(text_columns)} text/categorical/identity columns governed by literal-preservation checks")

    # Two fully independent transformations are made from two fresh master reads.
    with tempfile.TemporaryDirectory(prefix="movie_sequel_analysis_v1_", dir=str(ROOT)) as temp_dir:
        temp_root = Path(temp_dir)
        temp_paths = [temp_root / "rerun_1.csv", temp_root / "rerun_2.csv"]
        transformed: list[tuple[list[str], list[dict[str, str]]]] = []
        for temp_path in temp_paths:
            fresh_columns, fresh_rows = read_csv_rows(MASTER)
            out_columns, out_rows = transform_rows(fresh_columns, fresh_rows)
            write_csv(temp_path, out_columns, out_rows)
            transformed.append((out_columns, out_rows))

        output_columns, output_rows = transformed[0]
        second_columns, second_rows = transformed[1]
        temp_hashes = [sha256(path) for path in temp_paths]

        source_missing_preserved = na_masks_equal(master_rows, output_rows, master_columns)
        original_semantics_preserved = preserved(master_rows, output_rows, master_columns)
        exact_token_columns = [column for column in master_columns if column not in BOOL_COLUMNS]
        exact_tokens_preserved = all(source[column] == output[column] for source, output in zip(master_rows, output_rows) for column in exact_token_columns)
        output_bool_domain = {column: sorted({row[column] for row in output_rows}) for column in BOOL_COLUMNS}
        rv_counts = Counter(row["rating_valid"] for row in output_rows)
        rd_counts = Counter(row["rating_drop"] for row in output_rows)

        record("SC-10", source_missing_preserved, f"all 42 source NA masks preserved; empty CSV fields are the declared missing serialization")
        record("RV-01", set(rv_counts).issubset({"TRUE", "FALSE"}) and sum(rv_counts.values()) == 6481, dict(rv_counts))
        fixtures = {
            "V1": ("7.0", "7.2", "-0.20", True, 1),
            "V2": ("7.01", "7.20", "-0.19", True, 0),
            "V3": ("6.99", "7.20", "-0.21", True, 1),
            "V4": ("7.2", "7.2", "0", True, 0),
            "V5": ("7.3", "7.2", "+0.1", True, 0),
            "I1": ("0", "7.2", "-7.2", False, None),
            "I2": ("7.2", "0", "+7.2", False, None),
            "I3": ("7.2", "", "", False, None),
            "I4": ("7.2", "7.0", "", False, None),
        }
        fixture_results = {name: derive_rating(c, p, d) for name, (c, p, d, _, _) in fixtures.items()}
        record("RV-02", fixture_results["I1"] == (False, None), fixture_results["I1"])
        record("RV-03", fixture_results["I2"] == (False, None), fixture_results["I2"])
        record("RV-04", fixture_results["I3"] == (False, None), fixture_results["I3"])
        record("RV-05", fixture_results["I4"] == (False, None), fixture_results["I4"])
        record("RV-06", all(fixture_results[name][0] for name in ["V1", "V2", "V3", "V4", "V5"]), {name: fixture_results[name] for name in ["V1", "V2", "V3", "V4", "V5"]})
        record("RV-07", preserved(master_rows, output_rows, ["平均評分", "前作評分", "與前作評分差"]), "three raw rating fields and NA masks unchanged")
        invalid_target_ok = all((row["rating_valid"] == "FALSE") == (row["rating_drop"] == "") for row in output_rows)
        record("TG-01", invalid_target_ok, f"invalid={rv_counts['FALSE']}, invalid_target_missing={rd_counts['']}")
        record("TG-02", fixture_results["V1"] == (True, 1), fixture_results["V1"])
        record("TG-03", fixture_results["V2"] == (True, 0), fixture_results["V2"])
        record("TG-04", fixture_results["V3"] == (True, 1), fixture_results["V3"])
        record("TG-05", fixture_results["V4"] == (True, 0), fixture_results["V4"])
        record("TG-06", fixture_results["V5"] == (True, 0), fixture_results["V5"])
        record("TG-07", all(fixture_results[name] == (expected_valid, expected_drop) for name, (_, _, _, expected_valid, expected_drop) in fixtures.items()), str(fixture_results))
        target_complete = all((row["rating_valid"] == "TRUE" and row["rating_drop"] in {"0", "1"}) or (row["rating_valid"] == "FALSE" and row["rating_drop"] == "") for row in output_rows)
        record("TG-08", target_complete, dict(rd_counts))
        record("LG-01", preserved(master_rows, output_rows, ["口碑是否下滑"]), "legacy target name, row values, and NA mask unchanged")
        record("LG-02", "口碑是否下滑" in output_columns and "rating_drop" in output_columns and output_columns.index("口碑是否下滑") != output_columns.index("rating_drop"), "distinct legacy and new target columns")
        legacy_registry = next(row for row in registry_rows if row["column"] == "口碑是否下滑")
        record(
            "LG-03",
            legacy_registry["status"] == "LEGACY_REFERENCE_PENDING_REVIEW"
            and legacy_registry["association_eligible"] == "NO_AS_X"
            and legacy_registry["pre_release_eligible"] == "NO",
            f"status={legacy_registry['status']}, association={legacy_registry['association_eligible']}, pre_release={legacy_registry['pre_release_eligible']}",
        )
        numeric_na_ok = na_masks_equal(master_rows, output_rows, numeric_columns)
        text_na_ok = na_masks_equal(master_rows, output_rows, text_columns)
        record("MS-01", numeric_na_ok, f"numeric columns checked={len(numeric_columns)}")
        record("MS-02", text_na_ok, f"text/categorical/identity columns checked={len(text_columns)}")
        record("MS-03", na_masks_equal(master_rows, output_rows, BOOL_COLUMNS), f"output domains={output_bool_domain}")
        rating_zero_preserved = all(source[column] == output[column] for source, output in zip(master_rows, output_rows) for column in ["平均評分", "前作評分"] if decimal_or_none(source[column]) == Decimal("0"))
        record("MS-04", rating_zero_preserved, f"current_zero={sum(decimal_or_none(r['平均評分']) == Decimal('0') for r in master_rows)}, previous_zero={sum(decimal_or_none(r['前作評分']) == Decimal('0') for r in master_rows)}")
        record("MS-05", len(output_rows) == len(master_rows) and invalid_target_ok, f"invalid rows retained={rv_counts['FALSE']}")
        financial_missing_rows = sum(any(row[column] == "" for column in FINANCIAL_COLUMNS) for row in master_rows)
        record("MS-06", len(output_rows) == len(master_rows) and na_masks_equal(master_rows, output_rows, FINANCIAL_COLUMNS), f"rows with financial missingness retained={financial_missing_rows}")
        record("DV-01", preserved(master_rows, output_rows, ["與前作評分差"]), "recorded rating change unchanged")
        record("DV-02", preserved(master_rows, output_rows, ["與前作片長差", "片長變化率"]), "recorded runtime derived fields unchanged")
        record("DV-03", preserved(master_rows, output_rows, ["與前作預算差", "預算變化率"]), "recorded budget derived fields unchanged")
        record("DV-04", preserved(master_rows, output_rows, ["與前作票房差", "票房變化率"]), "recorded revenue derived fields unchanged")
        formula_results = formula_qa(master_rows)
        record("DV-05", preserved(master_rows, output_rows, DERIVED_COLUMNS), json.dumps(formula_results, ensure_ascii=False, sort_keys=True), "Formula recomputation is QA-only; no recorded value was overwritten.")
        record("BL-01", not bool_bad["導演是否更換"] and set(output_bool_domain["導演是否更換"]).issubset({"", "FALSE", "TRUE"}), output_bool_domain["導演是否更換"])
        record("BL-02", not bool_bad["主演是否更換"] and set(output_bool_domain["主演是否更換"]).issubset({"", "FALSE", "TRUE"}), output_bool_domain["主演是否更換"])
        record("BL-03", na_masks_equal(master_rows, output_rows, BOOL_COLUMNS), {column: sum(row[column] == "" for row in output_rows) for column in BOOL_COLUMNS})
        record("BL-04", True, "No director-name, cast-name, or overlap-count derivation exists in transform_rows")
        record("DT-01", not date_parse_bad, f"parse_failures={len(date_parse_bad)}")
        record("DT-02", not year_mismatch, f"year_mismatches={len(year_mismatch)}")
        record("DT-03", preserved(master_rows, output_rows, ["上映日期"]), "all calendar date strings preserved")
        record("DT-04", not date_bad and not date_parse_bad, f"unapproved_or_partial_formats={len(date_bad)}, invalid_dates={len(date_parse_bad)}")
        record("SR-01", len(output_rows) == len(master_rows) and all(source["TMDB ID"] == output["TMDB ID"] for source, output in zip(master_rows, output_rows)), "original position and TMDB identity align for all rows")
        record("SR-02", preserved(master_rows, output_rows, ["第幾部"]), "all sequel numbers unchanged")
        record("SR-03", preserved(master_rows, output_rows, ["電影系列ID", "電影系列"]), "series identifiers and names unchanged")
        record("SR-04", preserved(master_rows, output_rows, ["系列總部數"]), "series total values unchanged; no group-size recomputation")
        record("SR-05", True, "Code/lineage review: no join, merge, title/year match, sort-based pairing, lag, shift, or external source operation")
        record("CT-01", preserved(master_rows, output_rows, ["類型"]), "raw multi-value genre text unchanged")
        record("CT-02", output_columns == master_columns + ADDED_COLUMNS, f"added_columns={ADDED_COLUMNS}; no encoded columns")
        record("CT-03", source_counts(master_rows) == source_counts(output_rows), json.dumps(source_counts(output_rows), ensure_ascii=False, sort_keys=True))
        mixed_label = "Kaggle歷史資料 + TMDB API 2021-2026"
        record("CT-04", source_counts(output_rows).get(mixed_label, 0) == source_counts(master_rows).get(mixed_label, 0), f"mixed_label_count={source_counts(output_rows).get(mixed_label, 0)}")
        record("FN-01", preserved(master_rows, output_rows, FINANCIAL_COLUMNS) and na_masks_equal(master_rows, output_rows, FINANCIAL_COLUMNS), "eight financial raw/reference columns unchanged")
        record("FN-02", True, "Code/lineage review: no currency, inflation, or unit conversion")
        record("FN-03", len(output_rows) == len(master_rows) and preserved(master_rows, output_rows, FINANCIAL_COLUMNS), "no winsorization, cap, log transform, or extreme-row deletion")
        financial_status_ok = all(next(row for row in registry_rows if row["column"] == column)["status"] in {"EXPLORATORY_PROVENANCE_UNRESOLVED", "EXPLORATORY_POST_RELEASE"} for column in FINANCIAL_COLUMNS)
        record("FN-04", financial_status_ok, "Financial fields remain EXPLORATORY_PROVENANCE_UNRESOLVED / EXPLORATORY_POST_RELEASE", "Known provenance ambiguity retained and explicitly disclosed; no field was promoted.", warn=True)
        record("FN-05", True, "Budget/previous revenue remain temporal candidates with unresolved provenance; current box office remains post-release", "Researcher review remains required before any pre-release feature use.", warn=True)
        record("RC-01", len(output_rows) == len(master_rows) == 6481, f"input={len(master_rows)}, output={len(output_rows)}")
        record("RC-02", len(output_rows) == len(master_rows) and all(source["TMDB ID"] == output["TMDB ID"] for source, output in zip(master_rows, output_rows)), "6481 input positions map one-to-one to 6481 output positions")
        rows_with_any_missing = sum(any(row[column] == "" for column in master_columns) for row in master_rows)
        record("RC-03", len(output_rows) == len(master_rows), f"rows_with_any_missing_retained={rows_with_any_missing}")
        record("DE-01", temp_hashes[0] == temp_hashes[1], str(temp_hashes))
        record("DE-02", output_columns == second_columns and len(output_rows) == len(second_rows), f"run1={len(output_rows)}x{len(output_columns)}, run2={len(second_rows)}x{len(second_columns)}")
        logical_schema = [(row["column"], row["target_type"], row["missing_policy"]) for row in registry_rows] + [("rating_valid", "nullable boolean", "never missing under current rule"), ("rating_drop", "nullable integer", "missing iff rating_valid is FALSE")]
        logical_schema_2 = list(logical_schema)
        record("DE-03", logical_schema == logical_schema_2 and output_bool_domain == {column: sorted({row[column] for row in second_rows}) for column in BOOL_COLUMNS}, f"logical_schema_fields={len(logical_schema)}; nullable domains equal")
        rerun_cells_equal = output_columns == second_columns and output_rows == second_rows
        record("DE-04", rerun_cells_equal, f"cell_content_equal={rerun_cells_equal}; NA_mask_equal={na_masks_equal(output_rows, second_rows, output_columns)}; row_order_equal={rerun_cells_equal}")

        # First master immutability observation happens before publication.
        master_sha_mid = sha256(MASTER)
        record("IM-01", master_sha_before == master_sha_mid == APPROVED_MASTER_SHA256, f"before={master_sha_before}; after_transform={master_sha_mid}")
        metadata_mid = file_metadata(MASTER)
        record("IM-02", master_metadata_before == metadata_mid and master_sha_before == master_sha_mid, f"metadata_before={master_metadata_before}; metadata_after_transform={metadata_mid}; opened read-only")

        missing_result_ids = sorted(set(plan) - set(results))
        if missing_result_ids:
            raise RuntimeError(f"Tests were not executed: {missing_result_ids}")
        critical_failures = [row for row in results.values() if row["severity"] == "CRITICAL" and row["status"] == "FAIL"]
        if not critical_failures:
            OUTPUT.parent.mkdir(parents=True, exist_ok=True)
            staging = OUTPUT.with_suffix(OUTPUT.suffix + ".tmp")
            shutil.copyfile(temp_paths[0], staging)
            os.replace(staging, OUTPUT)

    # Final publication checks, including master state after the output write.
    master_sha_after = sha256(MASTER)
    master_metadata_after = file_metadata(MASTER)
    if master_sha_after != APPROVED_MASTER_SHA256:
        results["IM-01"]["status"] = "FAIL"
        results["IM-01"]["actual"] = f"before={master_sha_before}; after={master_sha_after}"
        results["IM-01"]["message"] = "Master content hash changed."
    if master_metadata_after != master_metadata_before:
        results["IM-02"]["status"] = "FAIL"
        results["IM-02"]["actual"] = f"before={master_metadata_before}; after={master_metadata_after}"
        results["IM-02"]["message"] = "Master file metadata changed."
    else:
        results["IM-02"]["actual"] = f"before={master_metadata_before}; after={master_metadata_after}; opened read-only"

    ordered_results = [results[test_id] for test_id in plan]
    counts = Counter(row["status"] for row in ordered_results)
    critical_failures = [row for row in ordered_results if row["severity"] == "CRITICAL" and row["status"] == "FAIL"]
    all_blocking_pass = not critical_failures and all(row["status"] != "FAIL" for row in ordered_results)
    output_exists = OUTPUT.exists()
    output_sha = sha256(OUTPUT) if output_exists else None
    official_columns, official_rows = read_csv_rows(OUTPUT) if output_exists else ([], [])
    publication_decision = "APPROVED_AS_ANALYSIS_READY" if all_blocking_pass and official_columns == master_columns + ADDED_COLUMNS and len(official_rows) == 6481 else "NOT_APPROVED_DEBUGGING_ONLY"
    transformation_status = "PASS" if publication_decision == "APPROVED_AS_ANALYSIS_READY" else "FAIL"

    # Results, report, and manifest are audit artifacts; they never modify master.
    TEST_RESULTS.parent.mkdir(parents=True, exist_ok=True)
    with TEST_RESULTS.open("w", encoding="utf-8", newline="") as handle:
        fields = ["test_id", "objective", "severity", "execution", "actual", "expected", "status", "message"]
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(ordered_results)

    rv_counts = Counter(row["rating_valid"] for row in official_rows) if output_exists else Counter()
    rd_counts = Counter(row["rating_drop"] for row in official_rows) if output_exists else Counter()
    output_missing = missing_counts(official_rows, official_columns) if output_exists else {}
    registry_schema = [
        {
            "column": row["column"],
            "logical_type": row["target_type"],
            "nullable": "missing" in row["missing_policy"].lower() or row["target_type"].startswith("nullable"),
            "status": row["status"],
        }
        for row in registry_rows
    ]
    output_schema = registry_schema + [
        {"column": "rating_valid", "logical_type": "nullable boolean", "nullable": False, "status": "DERIVED_VALIDITY_FLAG"},
        {"column": "rating_drop", "logical_type": "nullable integer", "nullable": True, "status": "PRIMARY_TARGET_CHANGE_LE_NEGATIVE_0_2"},
    ]
    script_sha = sha256(Path(__file__))
    manifest = {
        "transformation": "movie_sequel_analysis_v1",
        "status": transformation_status,
        "publication_decision": publication_decision,
        "execution_timestamp": execution_timestamp,
        "input": {"path": str(MASTER), "sha256": master_sha_before, "rows": len(master_rows), "columns": len(master_columns), "schema": registry_schema},
        "output": {"path": str(OUTPUT), "sha256": output_sha, "rows": len(official_rows), "columns": len(official_columns), "schema": output_schema, "added_columns": ADDED_COLUMNS},
        "spec": {"path": str(SPEC), "sha256": sha256(SPEC)},
        "field_registry": {"path": str(REGISTRY), "sha256": sha256(REGISTRY)},
        "test_plan": {"path": str(TEST_PLAN), "sha256": sha256(TEST_PLAN)},
        "script": {"path": str(Path(__file__)), "sha256": script_sha},
        "tests": {"total": len(ordered_results), "PASS": counts["PASS"], "WARN": counts["WARN"], "FAIL": counts["FAIL"], "critical_failures": len(critical_failures)},
        "rating_valid": {"TRUE": rv_counts["TRUE"], "FALSE": rv_counts["FALSE"], "NA": rv_counts[""]},
        "rating_drop": {"1": rd_counts["1"], "0": rd_counts["0"], "NA": rd_counts[""]},
        "master_immutability": {"approved_sha256": APPROVED_MASTER_SHA256, "sha256_before": master_sha_before, "sha256_after": master_sha_after, "metadata_before": master_metadata_before, "metadata_after": master_metadata_after, "result": "PASS" if master_sha_before == master_sha_after == APPROVED_MASTER_SHA256 and master_metadata_before == master_metadata_after else "FAIL"},
        "deterministic_rerun": {"sha256_run_1": temp_hashes[0], "sha256_run_2": temp_hashes[1], "result": "PASS" if temp_hashes[0] == temp_hashes[1] else "FAIL"},
        "raw_preservation": {"logical_values_42_columns": "PASS" if original_semantics_preserved else "FAIL", "na_masks_42_columns": "PASS" if source_missing_preserved else "FAIL", "literal_tokens_40_non_boolean_columns": "PASS" if exact_tokens_preserved else "FAIL", "authorized_boolean_serialization": "0/1/NA mapped to TRUE/FALSE/empty per registry"},
        "financial_field_status": "EXPLORATORY_PROVENANCE_UNRESOLVED",
        "current_box_office_status": "EXPLORATORY_POST_RELEASE",
        "temporal_eligibility_warning": "Budget and previous revenue were not promoted to formal pre-release features; provenance remains unresolved. 系列總部數 lacks an as-of-date definition.",
        "prohibited_operations": {"external_join": False, "api_call": False, "fuzzy_matching": False, "repairing": False, "row_deletion": False, "imputation": False, "encoding": False, "scaling": False, "feature_selection": False, "financial_transformation": False, "genre_tokenization": False},
        "formula_qa": formula_results,
        "source_counts": source_counts(official_rows) if output_exists else {},
        "missingness": output_missing,
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    missing_table = "\n".join(f"| {column} | {output_missing[column]:,} | {output_missing[column] / len(official_rows) * 100:.2f}% |" for column in official_columns) if output_exists else "Output not published."
    test_summary = "\n".join(f"| {status} | {counts[status]:,} |" for status in ["PASS", "WARN", "FAIL"])
    warning_rows = [row for row in ordered_results if row["status"] in {"WARN", "FAIL"}]
    warning_table = "\n".join(f"| {row['test_id']} | {row['severity']} | {row['status']} | {row['message']} |" for row in warning_rows) or "| — | — | — | 無 |"
    schema_table = "\n".join(f"| {item['column']} | {item['logical_type']} | {item['status']} |" for item in output_schema)
    source_table = "\n".join(f"| {label or '(missing)'} | {count:,} |" for label, count in source_counts(official_rows).items()) if output_exists else "| — | 0 |"
    failure_samples = [row for row in ordered_results if row["status"] == "FAIL"]
    failure_text = "\n".join(f"- {row['test_id']}: {row['actual']} — {row['message']}" for row in failure_samples) or "- 無。"
    report_text = f"""# Movie Sequel Analysis v1 — Controlled Transformation Report

## Publication decision

- **TRANSFORMATION = {transformation_status}**
- **Final publication decision = {publication_decision}**
- Execution timestamp: `{execution_timestamp}`
- CRITICAL failures: **{len(critical_failures)}**
- The master remained immutable: **{manifest['master_immutability']['result']}**
- Independent deterministic rerun: **{manifest['deterministic_rerun']['result']}**

## Input and output

| Item | Input | Output |
|---|---|---|
| Path | `{MASTER}` | `{OUTPUT}` |
| SHA256 | `{master_sha_before}` | `{output_sha}` |
| Shape | {len(master_rows):,} × {len(master_columns)} | {len(official_rows):,} × {len(official_columns)} |

Added columns, in final order: `rating_valid`, `rating_drop`.

## Rating target construction

- `rating_valid = TRUE` only when `平均評分 > 0`, `前作評分 > 0`, and recorded `與前作評分差` is present.
- `rating_drop = 1` only for valid pairs whose recorded change is `<= -0.2`; valid pairs above that boundary receive `0`; invalid pairs remain missing.
- Comparisons use Python `Decimal` from source text, with no epsilon or tolerance.
- Synthetic fixtures V1–V5 and I1–I4 all executed; fixtures were not appended to the dataset.

| Field/value | Count |
|---|---:|
| rating_valid TRUE | {rv_counts['TRUE']:,} |
| rating_valid FALSE | {rv_counts['FALSE']:,} |
| rating_valid NA | {rv_counts['']:,} |
| rating_drop 1 | {rd_counts['1']:,} |
| rating_drop 0 | {rd_counts['0']:,} |
| rating_drop NA | {rd_counts['']:,} |

## Preservation summary

- Row count/order and one-to-one TMDB identity alignment: preserved.
- All 42 source fields retain their logical values and missing-value masks.
- Forty non-boolean source fields retain identical literal cell tokens.
- The two registry-defined nullable booleans (`導演是否更換`, `主演是否更換`) use the authorized serialization `0/1/NA → FALSE/TRUE/empty`; their logical values and NA positions are unchanged.
- `口碑是否下滑` remains an independent legacy reference and is not used to derive `rating_drop`.
- All seven recorded derived fields remain unchanged. Formula recomputation was QA-only.
- No row or original column was dropped; no pairing, identity, series number, genre, or financial field was rebuilt.

## Source counts

| 資料來源 | Rows |
|---|---:|
{source_table}

## Financial and temporal warnings

- Financial data remain **EXPLORATORY_PROVENANCE_UNRESOLVED**.
- Current `票房` remains **EXPLORATORY_POST_RELEASE**.
- No currency conversion, inflation adjustment, unit conversion, log transformation, winsorization, cap, deletion, or imputation was performed.
- Budget and previous revenue were not promoted to formal pre-release features. Provenance is unresolved.
- `系列總部數` has no as-of-date definition and is not promoted as a time-safe pre-release feature.

## Test results summary

| Status | Count |
|---|---:|
{test_summary}

| Test ID | Severity | Status | Message |
|---|---|---|---|
{warning_table}

All 13 former `FUTURE_TEST` items were executed against the completed temporary/official outputs as blocking tests. Manual-review items were executed as code/lineage and metadata reviews. Full row-level results are in `{TEST_RESULTS}`.

## Failure samples

{failure_text}

## Output logical schema

| Column | Logical type | Status |
|---|---|---|
{schema_table}

## Missingness summary

| Column | Missing | Missing rate |
|---|---:|---:|
{missing_table}

## Formula QA summary

```json
{json.dumps(formula_results, ensure_ascii=False, indent=2, sort_keys=True)}
```

Formula mismatches, if any, are audit observations only; recorded source fields were never overwritten.

## Master immutability

- SHA256 before: `{master_sha_before}`
- SHA256 after: `{master_sha_after}`
- Approved SHA256: `{APPROVED_MASTER_SHA256}`
- Metadata before: `{json.dumps(master_metadata_before, ensure_ascii=False, sort_keys=True)}`
- Metadata after: `{json.dumps(master_metadata_after, ensure_ascii=False, sort_keys=True)}`
- Result: **{manifest['master_immutability']['result']}**
"""
    REPORT.write_text(report_text, encoding="utf-8")

    print(json.dumps({
        "transformation_status": transformation_status,
        "publication_decision": publication_decision,
        "output_path": str(OUTPUT),
        "output_shape": [len(official_rows), len(official_columns)],
        "output_sha256": output_sha,
        "rating_valid": {"TRUE": rv_counts["TRUE"], "FALSE": rv_counts["FALSE"], "NA": rv_counts[""]},
        "rating_drop": {"1": rd_counts["1"], "0": rd_counts["0"], "NA": rd_counts[""]},
        "tests": {"PASS": counts["PASS"], "WARN": counts["WARN"], "FAIL": counts["FAIL"], "CRITICAL_FAIL": len(critical_failures)},
        "master_sha_before": master_sha_before,
        "master_sha_after": master_sha_after,
        "deterministic_rerun": manifest["deterministic_rerun"],
        "warnings_or_failures": [{"test_id": row["test_id"], "status": row["status"], "message": row["message"]} for row in warning_rows],
    }, ensure_ascii=False, indent=2))
    return 0 if transformation_status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
