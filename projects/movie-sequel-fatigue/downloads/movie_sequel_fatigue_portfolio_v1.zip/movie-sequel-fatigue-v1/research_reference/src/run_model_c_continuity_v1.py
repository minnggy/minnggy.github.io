#!/usr/bin/env python3
"""Run the provenance-limited Model C continuity extension experiment."""

from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import warnings
from decimal import Decimal, InvalidOperation
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels.api as sm
import statsmodels
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score, average_precision_score, brier_score_loss, confusion_matrix,
    f1_score, precision_score, recall_score, roc_auc_score,
)


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
SPEC = ROOT / "reports/model_c_continuity_spec_v1.md"
T1_REGISTRY = ROOT / "reports/t1_feature_availability_decision_registry_v1.csv"
LOGISTIC_A = ROOT / "reports/logistic_regression_v1_results.csv"
RF_A = ROOT / "reports/random_forest_v1_results.csv"
RESULTS = ROOT / "reports/model_c_continuity_results.csv"
COEFFICIENTS = ROOT / "reports/model_c_continuity_coefficients.csv"
IMPORTANCE = ROOT / "reports/model_c_continuity_feature_importance.csv"
MANIFEST = ROOT / "reports/model_c_continuity_manifest.json"
QA = ROOT / "reports/model_c_continuity_qa.md"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
SEED = 20260913
THRESHOLD = 0.5
PERMUTATION_REPEATS = 30
BASE_FEATURES = [
    "sequel_number", "release_year", "previous_rating", "previous_rating_votes",
    "years_since_previous", "previous_runtime",
]
ADDED_FEATURES = ["導演是否更換", "主演是否更換", "與前作共同主演數", "與前作片長差", "片長變化率"]
FEATURES = BASE_FEATURES + ADDED_FEATURES
BOOLEAN_FEATURES = {"導演是否更換", "主演是否更換"}
PROHIBITED = {
    "平均評分", "評分人數", "人氣", "票房", "與前作評分差", "與前作票房差",
    "票房變化率", "rating_change", "rating_valid", "rating_drop", "口碑是否下滑",
    "電影系列ID", "TMDB ID", "IMDb ID",
}
RF_PARAMS = {
    "n_estimators": 500, "max_depth": None, "min_samples_split": 2,
    "min_samples_leaf": 1, "max_features": "sqrt", "bootstrap": True,
    "class_weight": None, "criterion": "gini", "random_state": SEED, "n_jobs": 1,
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def convert_feature(frame: pd.DataFrame, feature: str) -> pd.Series:
    if feature in BOOLEAN_FEATURES:
        unexpected = frame.loc[~frame[feature].isin(["", "TRUE", "FALSE"]), feature].unique().tolist()
        if unexpected:
            raise RuntimeError(f"Unexpected boolean values for {feature}: {unexpected[:10]}")
        return frame[feature].map({"TRUE": 1.0, "FALSE": 0.0, "": np.nan}).astype(float)
    return pd.to_numeric(frame[feature], errors="coerce").replace([np.inf, -np.inf], np.nan)


def feature_matrix(frame: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({feature: convert_feature(frame, feature) for feature in FEATURES}, index=frame.index)


def gate_and_audit() -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    digest = sha256(INPUT)
    if digest != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL FAILURE: input SHA mismatch: {digest}")
    frame = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if frame.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL FAILURE: input shape mismatch: {frame.shape}")
    needed = set(FEATURES) | {"rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差", "片長(分鐘)", "前作片長", "電影系列ID", "TMDB ID", "IMDb ID"}
    if not needed.issubset(frame.columns):
        raise SystemExit(f"CRITICAL FAILURE: missing fields {sorted(needed - set(frame.columns))}")
    if set(FEATURES) & PROHIBITED:
        raise SystemExit(f"CRITICAL FAILURE: prohibited X {sorted(set(FEATURES) & PROHIBITED)}")
    mismatches = []
    for index, row in frame.iterrows():
        current, previous, change = (decimal_or_none(row[name]) for name in ["平均評分", "前作評分", "與前作評分差"])
        valid = current is not None and previous is not None and change is not None and current > 0 and previous > 0
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            mismatches.append(int(index) + 2)
    if mismatches:
        raise SystemExit(f"CRITICAL FAILURE: target mismatch rows {mismatches[:10]}")
    eligible = frame[(frame.rating_valid == "TRUE") & frame.rating_drop.isin(["0", "1"])].copy()
    counts = eligible.rating_drop.value_counts().to_dict()
    if len(eligible) != 4058 or counts != {"0": 2044, "1": 2014}:
        raise SystemExit(f"CRITICAL FAILURE: target counts n={len(eligible)}, {counts}")

    registry = pd.read_csv(T1_REGISTRY, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    registry_subset = registry[registry.feature.isin(ADDED_FEATURES)]
    if set(registry_subset.feature) != set(ADDED_FEATURES) or not registry_subset.final_decision.eq("PROVENANCE_REVIEW").all():
        raise SystemExit("CRITICAL FAILURE: added features conflict with T-1 decision registry")

    x = feature_matrix(eligible)
    audits = []
    for feature in ADDED_FEATURES:
        numeric_values = x[feature]
        raw_nonempty = eligible[feature].ne("")
        audits.append({
            "feature": feature,
            "recorded_type": "nullable boolean string" if feature in BOOLEAN_FEATURES else "nullable numeric string",
            "model_representation": "TRUE=1; FALSE=0; missing=NA" if feature in BOOLEAN_FEATURES else "recorded numeric; missing=NA",
            "eligible_n": len(eligible), "nonmissing_n": int(numeric_values.notna().sum()),
            "missing_n": int(numeric_values.isna().sum()), "missing_rate": float(numeric_values.isna().mean()),
            "unique_nonmissing_n": int(numeric_values.nunique(dropna=True)),
            "min": float(numeric_values.min()) if numeric_values.notna().any() else np.nan,
            "max": float(numeric_values.max()) if numeric_values.notna().any() else np.nan,
            "nonempty_parse_failures": int((raw_nonempty & numeric_values.isna()).sum()),
            "t1_registry_decision": "PROVENANCE_REVIEW",
            "qa_status": "PASS_WITH_WARNING",
        })
    audit_frame = pd.DataFrame(audits)
    bool_ok = all(set(eligible.loc[eligible[f].ne(""), f].unique()).issubset({"TRUE", "FALSE"}) for f in BOOLEAN_FEATURES)
    shared = x["與前作共同主演數"].dropna()
    shared_ok = bool(((shared % 1 == 0) & (shared >= 0) & (shared <= 3)).all())
    current_runtime = pd.to_numeric(eligible["片長(分鐘)"], errors="coerce")
    previous_runtime = pd.to_numeric(eligible["前作片長"], errors="coerce")
    recorded_diff = x["與前作片長差"]
    recorded_rate = x["片長變化率"]
    diff_mask = current_runtime.notna() & previous_runtime.notna() & recorded_diff.notna()
    rate_mask = diff_mask & recorded_rate.notna() & previous_runtime.ne(0)
    diff_mismatches = int(((recorded_diff[diff_mask] - (current_runtime[diff_mask] - previous_runtime[diff_mask])).abs() > 1e-9).sum())
    rate_mismatches = int(((recorded_rate[rate_mask] - ((current_runtime[rate_mask] - previous_runtime[rate_mask]) / previous_runtime[rate_mask])).abs() > 1e-9).sum())
    if not bool_ok or not shared_ok or diff_mismatches or rate_mismatches:
        raise SystemExit(f"CRITICAL FAILURE: added-field definition conflict boolean={bool_ok}, shared={shared_ok}, diff={diff_mismatches}, rate={rate_mismatches}")
    tmdb, imdb = frame["TMDB ID"], frame.loc[frame["IMDb ID"].ne(""), "IMDb ID"]
    if tmdb.eq("").any() or tmdb.duplicated().any() or imdb.duplicated().any():
        raise SystemExit("CRITICAL FAILURE: identity gate failed")
    gate = {
        "input_sha256": digest, "input_shape": list(frame.shape), "eligible_n": len(eligible),
        "drop_n": int(counts["1"]), "non_drop_n": int(counts["0"]), "target_mismatches": 0,
        "boolean_schema_valid": bool_ok, "shared_lead_range_valid": shared_ok,
        "runtime_difference_formula_n": int(diff_mask.sum()), "runtime_difference_mismatches": diff_mismatches,
        "runtime_rate_formula_n": int(rate_mask.sum()), "runtime_rate_mismatches": rate_mismatches,
        "runtime_rate_min": float(recorded_rate.min()), "runtime_rate_max": float(recorded_rate.max()),
        "previous_runtime_lt10_n": int((previous_runtime.notna() & previous_runtime.lt(10)).sum()),
        "provenance_status": "PROVENANCE_REVIEW_REQUIRED",
    }
    return eligible, gate, audit_frame


def calibration(y: np.ndarray, probability: np.ndarray) -> tuple[float, float, str]:
    p = np.clip(probability, 1e-12, 1 - 1e-12)
    logit = np.log(p / (1 - p))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            fit = sm.GLM(y, sm.add_constant(logit, has_constant="add"), family=sm.families.Binomial()).fit(maxiter=200, tol=1e-10)
            if any(type(w.message).__name__ == "PerfectSeparationWarning" for w in caught):
                return np.nan, np.nan, "NOT_ESTIMABLE_PERFECT_PREDICTION"
            return float(fit.params[0]), float(fit.params[1]), "ESTIMABLE"
        except Exception as exc:
            return np.nan, np.nan, f"NOT_ESTIMABLE:{type(exc).__name__}"


def evaluate(y: np.ndarray, probability: np.ndarray) -> dict:
    predicted = (probability >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    intercept, slope, cal_status = calibration(y, probability)
    return {
        "roc_auc": float(roc_auc_score(y, probability)), "pr_auc": float(average_precision_score(y, probability)),
        "brier": float(brier_score_loss(y, probability)), "accuracy": float(accuracy_score(y, predicted)),
        "precision": float(precision_score(y, predicted, zero_division=0)), "recall": float(recall_score(y, predicted, zero_division=0)),
        "f1": float(f1_score(y, predicted, zero_division=0)), "specificity": float(tn / (tn + fp)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "calibration_intercept": intercept, "calibration_slope": slope, "calibration_status": cal_status,
    }


def prepare(eligible: pd.DataFrame, strategy: str) -> dict:
    x_all = feature_matrix(eligible)
    y_all = pd.to_numeric(eligible.rating_drop, errors="raise").astype(int)
    years = x_all.release_year
    train_base, test_base = years <= 2020, years >= 2021
    if years.isna().any() or not (train_base | test_base).all() or (train_base & test_base).any():
        raise RuntimeError("Invalid temporal partition")
    parameters, missingness, indicators = [], [], []
    for feature in FEATURES:
        missingness.append({
            "feature": feature, "eligible_missing_n": int(x_all[feature].isna().sum()),
            "eligible_missing_rate": float(x_all[feature].isna().mean()),
            "train_missing_n": int(x_all.loc[train_base, feature].isna().sum()),
            "test_missing_n": int(x_all.loc[test_base, feature].isna().sum()),
        })
    if strategy == "P1":
        used = x_all.notna().all(axis=1)
        train_mask, test_mask = train_base & used, test_base & used
        train_raw, test_raw = x_all.loc[train_mask].copy(), x_all.loc[test_mask].copy()
    else:
        used = pd.Series(True, index=eligible.index)
        train_mask, test_mask = train_base, test_base
        train_raw, test_raw = x_all.loc[train_mask].copy(), x_all.loc[test_mask].copy()
        for feature in FEATURES:
            train_missing, test_missing = train_raw[feature].isna(), test_raw[feature].isna()
            median = float(train_raw.loc[~train_missing, feature].median())
            if not np.isfinite(median):
                raise RuntimeError(f"Nonfinite train median for {feature}")
            if train_missing.any():
                indicator = f"{feature}__missing"
                indicators.append(indicator)
                train_raw[indicator], test_raw[indicator] = train_missing.astype(float), test_missing.astype(float)
            train_raw[feature], test_raw[feature] = train_raw[feature].fillna(median), test_raw[feature].fillna(median)
            parameters.append({"strategy": strategy, "feature": feature, "parameter": "TRAIN_MEDIAN", "value": median, "source": "TRAIN_ONLY", "indicator_included": bool(train_missing.any())})
    train, test = pd.DataFrame(index=train_raw.index), pd.DataFrame(index=test_raw.index)
    for feature in FEATURES:
        mean, std = float(train_raw[feature].mean()), float(train_raw[feature].std(ddof=0))
        if not np.isfinite(std) or std == 0:
            raise RuntimeError(f"Invalid train SD for {feature}")
        train[feature], test[feature] = (train_raw[feature] - mean) / std, (test_raw[feature] - mean) / std
        parameters.extend([
            {"strategy": strategy, "feature": feature, "parameter": "TRAIN_MEAN", "value": mean, "source": "TRAIN_ONLY", "indicator_included": f"{feature}__missing" in indicators},
            {"strategy": strategy, "feature": feature, "parameter": "TRAIN_POPULATION_SD", "value": std, "source": "TRAIN_ONLY", "indicator_included": f"{feature}__missing" in indicators},
        ])
    for indicator in indicators:
        train[indicator], test[indicator] = train_raw[indicator], test_raw[indicator]
    return {
        "x_train": train, "x_test": test, "y_train": y_all.loc[train_mask].to_numpy(), "y_test": y_all.loc[test_mask].to_numpy(),
        "used_n": int(used.sum()), "excluded_n": int((~used).sum()), "indicators": indicators,
        "parameters": pd.DataFrame(parameters), "missingness": pd.DataFrame(missingness),
    }


def fit_logistic(prepared: dict, strategy: str) -> dict:
    x_train, x_test, y_train, y_test = prepared["x_train"], prepared["x_test"], prepared["y_train"], prepared["y_test"]
    design_train, design_test = sm.add_constant(x_train, has_constant="add"), sm.add_constant(x_test, has_constant="add")
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = sm.GLM(y_train, design_train, family=sm.families.Binomial()).fit(maxiter=500, tol=1e-10)
    rank = int(np.linalg.matrix_rank(design_train.to_numpy()))
    if not bool(fit.converged):
        raise RuntimeError(f"Logistic {strategy} convergence failure")
    singular = rank != design_train.shape[1]
    p_train, p_test = np.asarray(fit.predict(design_train)), np.asarray(fit.predict(design_test))
    results = []
    for split, y, p in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        results.append({"model": "Model C", "algorithm": "Logistic Regression", "preprocessing": strategy, "split": split, "n": len(y), **evaluate(y, p), "result_source": "MODEL_C_EXECUTION"})
    ci = fit.conf_int()
    coefficients = []
    for feature in fit.params.index:
        coef, low, high = float(fit.params[feature]), float(ci.loc[feature, 0]), float(ci.loc[feature, 1])
        coefficients.append({
            "model": "Model C", "preprocessing": strategy, "feature": "Intercept" if feature == "const" else feature,
            "coefficient": coef, "std_error": float(fit.bse[feature]), "z": float(fit.tvalues[feature]), "p_value": float(fit.pvalues[feature]),
            "odds_ratio": math.exp(coef), "ci_lower": low, "ci_upper": high, "odds_ratio_ci_lower": math.exp(low), "odds_ratio_ci_upper": math.exp(high),
            "scale_definition": "INTERCEPT" if feature == "const" else ("OR FOR ORIGINAL-MISSING INDICATOR 0 TO 1" if feature.endswith("__missing") else "OR PER 1 TRAINING STANDARD DEVIATION INCREASE"),
            "identification_status": "NOT_UNIQUELY_IDENTIFIED_RANK_DEFICIENT_DESIGN" if singular else "IDENTIFIED_FULL_RANK",
        })
    diagnostic = {
        "algorithm": "Logistic Regression", "preprocessing": strategy, "converged": bool(fit.converged),
        "design_rank": rank, "design_columns": design_train.shape[1], "singular": singular,
        "numerical_issue": singular,
        "warnings": " | ".join(str(w.message) for w in caught),
    }
    return {"results": pd.DataFrame(results), "coefficients": pd.DataFrame(coefficients), "diagnostic": diagnostic}


def fit_rf(prepared: dict, strategy: str) -> dict:
    x_train, x_test, y_train, y_test = prepared["x_train"], prepared["x_test"], prepared["y_train"], prepared["y_test"]
    fit = RandomForestClassifier(**RF_PARAMS).fit(x_train, y_train)
    p_train, p_test = fit.predict_proba(x_train)[:, 1], fit.predict_proba(x_test)[:, 1]
    results = []
    for split, y, p in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        results.append({"model": "Model C", "algorithm": "Random Forest", "preprocessing": strategy, "split": split, "n": len(y), **evaluate(y, p), "result_source": "MODEL_C_EXECUTION"})
    importance = []
    for feature, value in zip(x_train.columns, fit.feature_importances_):
        importance.append({"model": "Model C", "preprocessing": strategy, "feature": feature, "importance_type": "IMPURITY_GINI", "importance": float(value), "importance_std": np.nan, "evaluation_split": "TRAIN_FIT", "n_repeats": np.nan})
    perm = permutation_importance(fit, x_test, y_test, scoring="roc_auc", n_repeats=PERMUTATION_REPEATS, random_state=SEED, n_jobs=1)
    for feature, mean, std in zip(x_test.columns, perm.importances_mean, perm.importances_std):
        importance.append({"model": "Model C", "preprocessing": strategy, "feature": feature, "importance_type": "TEST_PERMUTATION_ROC_AUC_DECREASE", "importance": float(mean), "importance_std": float(std), "evaluation_split": "TEST", "n_repeats": PERMUTATION_REPEATS})
    importance = pd.DataFrame(importance)
    importance["rank"] = importance.groupby(["preprocessing", "importance_type"])["importance"].rank(method="min", ascending=False).astype(int)
    diagnostic = {"algorithm": "Random Forest", "preprocessing": strategy, "converged": "NOT_APPLICABLE", "design_rank": np.nan, "design_columns": x_train.shape[1], "singular": False, "numerical_issue": False, "warnings": ""}
    return {"results": pd.DataFrame(results), "importance": importance, "diagnostic": diagnostic}


def model_a_results() -> pd.DataFrame:
    frames = []
    for algorithm, path in [("Logistic Regression", LOGISTIC_A), ("Random Forest", RF_A)]:
        data = pd.read_csv(path, encoding="utf-8-sig")
        data = data[data.model.eq("Model A")].copy()
        data.insert(1, "algorithm", algorithm)
        data["result_source"] = path.name
        frames.append(data)
    return pd.concat(frames, ignore_index=True)


def run_all(eligible: pd.DataFrame) -> dict[str, pd.DataFrame]:
    result_frames, coefficients, importance, diagnostics, parameters, missingness = [], [], [], [], [], []
    for strategy in ["P1", "P2"]:
        prepared = prepare(eligible, strategy)
        parameters.append(prepared["parameters"])
        missing = prepared["missingness"].copy(); missing.insert(0, "preprocessing", strategy); missingness.append(missing)
        logistic = fit_logistic(prepared, strategy)
        forest = fit_rf(prepared, strategy)
        result_frames += [logistic["results"], forest["results"]]
        coefficients.append(logistic["coefficients"]); importance.append(forest["importance"])
        for diagnostic in [logistic["diagnostic"], forest["diagnostic"]]:
            diagnostic.update({"used_n": prepared["used_n"], "excluded_n": prepared["excluded_n"], "train_n": len(prepared["y_train"]), "test_n": len(prepared["y_test"]), "technical_indicators": "|".join(prepared["indicators"])})
            diagnostics.append(diagnostic)
    return {
        "model_c_results": pd.concat(result_frames, ignore_index=True), "coefficients": pd.concat(coefficients, ignore_index=True),
        "importance": pd.concat(importance, ignore_index=True), "diagnostics": pd.DataFrame(diagnostics),
        "parameters": pd.concat(parameters, ignore_index=True), "missingness": pd.concat(missingness, ignore_index=True),
    }


def frames_equal(first: dict[str, pd.DataFrame], second: dict[str, pd.DataFrame]) -> bool:
    return all(first[key].equals(second[key]) for key in first)


def markdown_table(frame: pd.DataFrame) -> str:
    table = frame.copy()
    for column in table.columns:
        if pd.api.types.is_float_dtype(table[column]):
            table[column] = table[column].map(lambda x: "" if pd.isna(x) else f"{x:.4f}")
    headers = list(table.columns)
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    lines += ["| " + " | ".join(row) + " |" for row in table.astype(str).itertuples(index=False, name=None)]
    return "\n".join(lines)


def main() -> None:
    input_sha_before, input_size_before = sha256(INPUT), INPUT.stat().st_size
    eligible, gate, field_audit = gate_and_audit()
    first, second = run_all(eligible), run_all(eligible)
    deterministic = frames_equal(first, second)
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated Model C outputs differ")
    combined_results = pd.concat([model_a_results(), first["model_c_results"]], ignore_index=True, sort=False)
    write_csv(combined_results, RESULTS); write_csv(first["coefficients"], COEFFICIENTS); write_csv(first["importance"], IMPORTANCE)

    diagnostics = first["diagnostics"]
    p1 = diagnostics[diagnostics.preprocessing.eq("P1")].iloc[0]
    p2 = diagnostics[diagnostics.preprocessing.eq("P2")].iloc[0]
    source_immutable = sha256(INPUT) == input_sha_before and INPUT.stat().st_size == input_size_before
    added_missing = field_audit[["feature", "missing_n", "missing_rate", "unique_nonmissing_n", "min", "max", "qa_status"]]
    model_c_test = first["model_c_results"].query("split == 'TEST'")
    model_a_test = combined_results.query("model == 'Model A' and split == 'TEST'")
    comparison = model_c_test.merge(model_a_test, on=["algorithm", "preprocessing", "split"], suffixes=("_c", "_a"))
    comparison["roc_auc_gain_c_minus_a"] = comparison.roc_auc_c - comparison.roc_auc_a
    comparison["pr_auc_gain_c_minus_a"] = comparison.pr_auc_c - comparison.pr_auc_a
    comparison["brier_change_c_minus_a"] = comparison.brier_c - comparison.brier_a
    top_importance = first["importance"].query("importance_type == 'TEST_PERMUTATION_ROC_AUC_DECREASE'").sort_values(["preprocessing", "rank"]).groupby("preprocessing", as_index=False).head(5)

    checks = [
        ("Q1", "Input SHA and shape", input_sha_before == EXPECTED_SHA and tuple(gate["input_shape"]) == EXPECTED_SHAPE, f"{input_sha_before}; {gate['input_shape']}"),
        ("Q2", "Target definition and counts", gate["target_mismatches"] == 0 and gate["eligible_n"] == 4058 and gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"n={gate['eligible_n']}; 1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q3", "Model C schema exact", FEATURES == BASE_FEATURES + ADDED_FEATURES and len(FEATURES) == 11, "|".join(FEATURES)),
        ("Q4", "Added field definitions match registries", gate["boolean_schema_valid"] and gate["shared_lead_range_valid"] and gate["runtime_difference_mismatches"] == 0 and gate["runtime_rate_mismatches"] == 0, "Boolean/range/formula checks passed"),
        ("Q5", "Provenance status retained", gate["provenance_status"] == "PROVENANCE_REVIEW_REQUIRED", gate["provenance_status"]),
        ("Q6", "P1/P2 preprocessing executed", set(diagnostics.preprocessing) == {"P1", "P2"}, f"P1 used={p1.used_n}; P2 used={p2.used_n}"),
        ("Q7", "Train-only preprocessing", bool(first["parameters"].source.eq("TRAIN_ONLY").all()), "All fitted parameters train-only"),
        ("Q8", "Fixed time split", p2.train_n == 3136 and p2.test_n == 922, f"P2 train={p2.train_n}; test={p2.test_n}"),
        ("Q9", "No leakage or identity X", not (set(FEATURES) & PROHIBITED), "No prohibited intersection"),
        ("Q10", "No test information in preprocessing", bool(first["parameters"].source.eq("TRAIN_ONLY").all()), "PASS"),
        ("Q11", "No unauthorized data changes", source_immutable, "Input hash and size unchanged"),
        ("Q12", "Model parameters fixed", RF_PARAMS["random_state"] == SEED and RF_PARAMS["n_jobs"] == 1, str(RF_PARAMS)),
        ("Q13", "No selection/tuning/threshold change", THRESHOLD == 0.5, "Fixed threshold=0.5; no search"),
        ("Q14", "Feature matrix dimensions", p1.design_columns >= 11 and p2.design_columns >= 11, f"P1 columns={p1.design_columns}; P2 columns={p2.design_columns}"),
        ("Q15", "Deterministic outputs", deterministic, "Two complete executions identical"),
        ("Q16", "Algorithms complete", set(first["model_c_results"].algorithm) == {"Logistic Regression", "Random Forest"}, "Both algorithms; P1/P2; train/test"),
    ]
    failures = [test for test in checks if not test[2]]
    singular_runs = diagnostics[(diagnostics.algorithm == "Logistic Regression") & diagnostics.singular.fillna(False)]
    status = "MODEL_C_CONTINUITY_EXPERIMENT_COMPLETE_WITH_WARNINGS" if not failures else "MODEL_C_CONTINUITY_BLOCKED"

    qa_lines = ["# Model C Continuity QA", "", f"**STATUS = {status}**", "", "## Added-field audit", "", markdown_table(added_missing), "", "## Automated checks", "", "| Test | Objective | Status | Evidence |", "|---|---|---|---|"]
    qa_lines += [f"| {test} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |" for test, objective, passed, evidence in checks]
    qa_lines += [
        "", "## Warnings", "",
        "- All five added fields remain `PROVENANCE_REVIEW_REQUIRED`; this experiment does not approve them as formal T−1 predictors.",
        f"- Rank-deficient Logistic runs: {len(singular_runs)}. P2 duplicate missingness indicators are retained by specification; their individual coefficients are not uniquely identified.",
        f"- Recorded `片長變化率` ranges from {gate['runtime_rate_min']:.4f} to {gate['runtime_rate_max']:.4f}; {gate['previous_runtime_lt10_n']} target-eligible rows have predecessor runtime below 10 minutes. Values were retained unchanged.",
        "- P1 and P2 have different sample compositions.",
        "- Previous rating remains mathematically coupled to the change-based target.",
        "- Random Forest test permutation importance is interpretation-only and did not feed feature selection.",
        "- 2026 is an incomplete test-cohort year.", "",
    ]
    QA.write_text("\n".join(qa_lines), encoding="utf-8")

    report_lines = [
        "# Model C: Does production continuity add predictive signal?", "", "## Executive conclusion", "",
        "Model C was executed as a provenance-limited incremental experiment. The five continuity/runtime-change fields passed structural and formula QA, but their recorded values are not proven T−1 snapshots. Any metric difference is therefore evidence about this recorded dataset, not approval for formal deployment or a causal claim.", "",
        "## 1. Fixed design", "",
        "Model C equals Model A plus `導演是否更換`, `主演是否更換`, `與前作共同主演數`, `與前作片長差`, and `片長變化率`. Target, eligibility, temporal split, P1/P2 protocols, scaling, Logistic specification, Random Forest settings, and threshold 0.5 are unchanged.", "",
        "## 2. Added-field QA", "", markdown_table(added_missing), "",
        "Boolean fields use only the technical mapping TRUE→1, FALSE→0, missing→NA. Shared-lead values are integers 0–3. Recorded runtime difference and rate match their formulas for all jointly observed target-eligible rows. No values were corrected, capped, deleted, or recomputed into the source.", "",
        "## 3. Sample sizes and preprocessing", "",
        f"Target eligible n={gate['eligible_n']:,}. P1 Model C complete cases={int(p1.used_n):,}, excluded={int(p1.excluded_n):,}, train={int(p1.train_n):,}, test={int(p1.test_n):,}. P2 retains {int(p2.used_n):,}, train={int(p2.train_n):,}, test={int(p2.test_n):,}. All medians and scaling parameters were learned from training rows only.", "",
        "## 4. Model C train/test metrics", "", markdown_table(first["model_c_results"][["algorithm", "preprocessing", "split", "n", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope", "calibration_status"]]), "",
        "## 5. Increment over Model A", "", markdown_table(comparison[["algorithm", "preprocessing", "n_c", "roc_auc_a", "roc_auc_c", "roc_auc_gain_c_minus_a", "pr_auc_a", "pr_auc_c", "pr_auc_gain_c_minus_a", "brier_a", "brier_c", "brier_change_c_minus_a"]]), "",
        "The comparison is descriptive. No cutoff defines a 'meaningful' gain, and results cannot choose preprocessing, features, or hyperparameters.", "",
        "## 6. Logistic coefficients", "",
        "The coefficient file reports standardized coefficients, uncertainty, odds ratios, and confidence intervals. P-values were not used for selection. Coefficients are predictive/associational only.", "",
        "## 7. Random Forest importance", "", markdown_table(top_importance[["preprocessing", "feature", "importance", "importance_std", "rank"]]), "",
        "Permutation importance is the mean test ROC-AUC decrease over 30 fixed-seed permutations. It is exploratory interpretation, not causality, independent effect, or authorization to select features.", "",
        "## 8. Limitations", "",
        "- The five added fields remain T−1 provenance-limited; recorded availability is not proof of release-eve availability.",
        "- Runtime change fields use current runtime and include small-denominator extreme values.",
        "- Previous rating remains mathematically coupled to Y and may reflect regression to the mean.",
        "- P1/P2 differ in sample composition; 2026 is incomplete.",
        "- Random Forest with unrestricted depth can overfit; settings were not tuned or changed.",
        "- P2 Logistic has a rank-deficient design because some required per-feature missingness indicators are identical. Predictions are reproducible, but individual P2 coefficients/SEs are not uniquely interpretable.",
        "- This experiment does not establish causality or formal feature eligibility.", "",
        "## 9. Decision", "",
        "Model C answers whether the recorded continuity bundle adds out-of-time signal beyond Model A under fixed protocols. It does not resolve provenance. The five features must remain outside the formally cleared T−1 model until separate provenance review is completed.", "",
        f"**STATUS = {status}**", "",
    ]
    SPEC_REPORT = ROOT / "reports/model_c_continuity_spec_v1.md"
    # Preserve the specification and write results narrative into the requested QA/outputs only.
    # The full narrative is appended under a clearly separated execution section.
    with SPEC_REPORT.open("a", encoding="utf-8") as handle:
        marker = "\n## Execution Results (generated)\n"
        existing = SPEC_REPORT.read_text(encoding="utf-8")
        if marker in existing:
            base = existing.split(marker)[0]
            SPEC_REPORT.write_text(base.rstrip() + "\n", encoding="utf-8")
        handle.write(marker + "\n".join(report_lines[2:]) + "\n")

    output_paths = [RESULTS, COEFFICIENTS, IMPORTANCE, SPEC, QA]
    manifest = {
        "status": status, "input_file": str(INPUT.relative_to(ROOT)), "input_sha256": input_sha_before,
        "input_rows": EXPECTED_SHAPE[0], "input_columns": EXPECTED_SHAPE[1], "source_immutable": source_immutable,
        "target": "rating_drop", "target_definition": "rating_valid TRUE and recorded rating change <= -0.2",
        "eligible_n": gate["eligible_n"], "target_counts": {"1": gate["drop_n"], "0": gate["non_drop_n"]},
        "model_c_features": FEATURES, "added_features": ADDED_FEATURES,
        "added_feature_provenance": "PROVENANCE_REVIEW_REQUIRED",
        "preprocessing": ["P1_COMPLETE_CASE", "P2_TRAIN_ONLY_MEDIAN_PLUS_TRAIN_MISSINGNESS_INDICATOR", "TRAIN_ONLY_STANDARDIZATION"],
        "train_rule": "release_year <= 2020", "test_rule": "release_year >= 2021", "classification_threshold": THRESHOLD,
        "logistic": "unpenalized binomial GLM maximum likelihood with intercept",
        "random_forest_parameters": RF_PARAMS, "random_seed": SEED,
        "field_audit": field_audit.to_dict(orient="records"), "gate": gate,
        "missingness": first["missingness"].to_dict(orient="records"),
        "preprocessing_parameters": first["parameters"].to_dict(orient="records"),
        "diagnostics": diagnostics.to_dict(orient="records"),
        "deterministic_execution": deterministic,
        "comparison_sources": {str(LOGISTIC_A.relative_to(ROOT)): sha256(LOGISTIC_A), str(RF_A.relative_to(ROOT)): sha256(RF_A)},
        "specification": str(SPEC.relative_to(ROOT)), "specification_sha256": sha256(SPEC),
        "qa": {"pass": sum(test[2] for test in checks), "fail": len(failures), "failed_tests": [test[0] for test in failures]},
        "outputs": {str(path.relative_to(ROOT)): sha256(path) for path in output_paths},
        "script": str(Path(__file__).relative_to(ROOT)), "script_sha256": sha256(Path(__file__)),
        "software": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "scipy": scipy.__version__, "statsmodels": statsmodels.__version__, "scikit_learn": sklearn.__version__},
        "warnings": ["five additions remain provenance-review required", "runtime-rate small-denominator extremes retained", "P1/P2 sample composition differs", "previous-rating mathematical coupling", "2026 incomplete"],
        "prohibited_actions_executed": [],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True, default=json_default) + "\n", encoding="utf-8")
    if status.endswith("BLOCKED"):
        raise SystemExit("Model C blocked by critical QA")
    print(first["model_c_results"].to_string(index=False))
    print(comparison[["algorithm", "preprocessing", "roc_auc_a", "roc_auc_c", "roc_auc_gain_c_minus_a", "pr_auc_gain_c_minus_a", "brier_change_c_minus_a"]].to_string(index=False))
    print(f"STATUS={status}")


if __name__ == "__main__":
    main()
