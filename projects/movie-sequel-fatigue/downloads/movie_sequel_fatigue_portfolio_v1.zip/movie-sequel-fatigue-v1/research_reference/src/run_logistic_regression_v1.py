#!/usr/bin/env python3
"""Formal Logistic Regression v1 for the movie-sequel study.

Runs exactly Model A/B crossed with P1/P2 under the approved temporal split.
No source data is modified and no model/feature/threshold selection is performed.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import tempfile
import warnings
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/movie_sequel_logistic_v1_mpl")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels.api as sm
import statsmodels
from sklearn.calibration import calibration_curve
from sklearn.metrics import (
    accuracy_score, average_precision_score, brier_score_loss, confusion_matrix,
    f1_score, precision_recall_curve, precision_score, recall_score,
    roc_auc_score, roc_curve,
)


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
REPORT = ROOT / "reports/logistic_regression_v1_report.md"
RESULTS = ROOT / "reports/logistic_regression_v1_results.csv"
COEFFICIENTS = ROOT / "reports/logistic_regression_v1_coefficients.csv"
CURVES = ROOT / "reports/logistic_regression_v1_curve_data.csv"
PARAMETERS = ROOT / "reports/logistic_regression_v1_preprocessing_parameters.csv"
DIAGNOSTICS = ROOT / "reports/logistic_regression_v1_diagnostics.csv"
MANIFEST = ROOT / "reports/logistic_regression_v1_manifest.json"
QA = ROOT / "reports/logistic_regression_v1_qa.md"
FIGURE_DIR = ROOT / "reports/figures/logistic_regression_v1"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
EXPECTED_TARGET = {"n": 4058, "1": 2014, "0": 2044}
THRESHOLD = 0.5
MODEL_FEATURES = {
    "Model A": ["sequel_number", "release_year", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"],
    "Model B": ["sequel_number", "release_year", "years_since_previous", "previous_runtime"],
}
STRATEGIES = ["P1", "P2"]
PROHIBITED = {
    "平均評分", "評分人數", "人氣", "票房", "與前作評分差", "與前作票房差",
    "票房變化率", "rating_change", "rating_valid", "rating_drop", "口碑是否下滑",
    "電影系列ID", "TMDB ID", "IMDb ID",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def write_csv(df: pd.DataFrame, path: Path) -> None:
    df.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def gate_input() -> tuple[pd.DataFrame, dict]:
    digest = sha256(INPUT)
    if digest != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL FAILURE: input SHA mismatch: {digest}")
    df = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if df.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL FAILURE: input shape mismatch: {df.shape}")
    required = set(sum(MODEL_FEATURES.values(), [])) | {
        "rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差",
        "電影系列ID", "TMDB ID", "IMDb ID",
    }
    if not required.issubset(df.columns):
        raise SystemExit(f"CRITICAL FAILURE: missing columns {sorted(required - set(df.columns))}")
    target_mismatch = []
    for i, row in df.iterrows():
        current = decimal_or_none(row["平均評分"])
        previous = decimal_or_none(row["前作評分"])
        change = decimal_or_none(row["與前作評分差"])
        valid = current is not None and previous is not None and change is not None and current > 0 and previous > 0
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            target_mismatch.append(int(i) + 2)
    if target_mismatch:
        raise SystemExit(f"CRITICAL FAILURE: target definition mismatch at rows {target_mismatch[:10]}")
    eligible = df["rating_valid"].eq("TRUE") & df["rating_drop"].isin(["0", "1"])
    counts = df.loc[eligible, "rating_drop"].value_counts().to_dict()
    if int(eligible.sum()) != EXPECTED_TARGET["n"] or counts != {"0": EXPECTED_TARGET["0"], "1": EXPECTED_TARGET["1"]}:
        raise SystemExit(f"CRITICAL FAILURE: target population mismatch n={eligible.sum()}, counts={counts}")
    all_x = set(sum(MODEL_FEATURES.values(), []))
    if all_x & PROHIBITED:
        raise SystemExit(f"CRITICAL FAILURE: prohibited X detected: {sorted(all_x & PROHIBITED)}")
    if MODEL_FEATURES["Model A"] != [
        "sequel_number", "release_year", "previous_rating", "previous_rating_votes",
        "years_since_previous", "previous_runtime",
    ] or MODEL_FEATURES["Model B"] != [
        "sequel_number", "release_year", "years_since_previous", "previous_runtime",
    ]:
        raise SystemExit("CRITICAL FAILURE: model feature schema changed")
    tmdb = df["TMDB ID"]
    imdb = df.loc[df["IMDb ID"].ne(""), "IMDb ID"]
    if tmdb.eq("").any() or tmdb.duplicated().any() or imdb.duplicated().any():
        raise SystemExit("CRITICAL FAILURE: identity integrity check failed")
    return df, {
        "input_sha256": digest, "input_shape": list(df.shape), "target_mismatches": 0,
        "eligible_n": int(eligible.sum()), "drop_n": counts["1"], "non_drop_n": counts["0"],
        "tmdb_missing": int(tmdb.eq("").sum()), "tmdb_duplicates": int(tmdb.duplicated().sum()),
        "imdb_nonempty_duplicates": int(imdb.duplicated().sum()),
    }


def numeric(df: pd.DataFrame, cols: list[str]) -> pd.DataFrame:
    x = df[cols].apply(pd.to_numeric, errors="coerce")
    return x.replace([np.inf, -np.inf], np.nan)


def calibration_stats(y: np.ndarray, p: np.ndarray) -> tuple[float, float, str]:
    clipped = np.clip(p, 1e-12, 1 - 1e-12)
    logit = np.log(clipped / (1 - clipped))
    design = sm.add_constant(logit, has_constant="add")
    try:
        fit = sm.GLM(y, design, family=sm.families.Binomial()).fit(maxiter=200, tol=1e-10)
        return float(fit.params[0]), float(fit.params[1]), "ESTIMABLE"
    except Exception as exc:
        return np.nan, np.nan, f"NOT_ESTIMABLE:{type(exc).__name__}"


def evaluate(y: np.ndarray, p: np.ndarray) -> tuple[dict, np.ndarray]:
    pred = (p >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    intercept, slope, cal_status = calibration_stats(y, p)
    metrics = {
        "roc_auc": float(roc_auc_score(y, p)),
        "pr_auc": float(average_precision_score(y, p)),
        "brier": float(brier_score_loss(y, p)),
        "accuracy": float(accuracy_score(y, pred)),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "specificity": float(tn / (tn + fp)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "calibration_intercept": intercept, "calibration_slope": slope,
        "calibration_status": cal_status,
        "mean_predicted_probability": float(np.mean(p)),
        "observed_prevalence": float(np.mean(y)),
    }
    return metrics, pred


def fit_one(eligible: pd.DataFrame, model: str, strategy: str) -> dict:
    features = MODEL_FEATURES[model]
    x_all = numeric(eligible, features)
    y_all = pd.to_numeric(eligible["rating_drop"], errors="raise").astype(int)
    year = pd.to_numeric(eligible["release_year"], errors="coerce")
    if year.isna().any():
        raise RuntimeError("Eligible population contains missing release_year")
    train_base = year <= 2020
    test_base = year >= 2021
    if not (train_base | test_base).all() or (train_base & test_base).any():
        raise RuntimeError("Temporal split does not partition target population")

    missing_rows = []
    for feature in features:
        missing_rows.append({
            "model": model, "preprocessing": strategy, "feature": feature,
            "eligible_missing_count": int(x_all[feature].isna().sum()),
            "eligible_missing_rate": float(x_all[feature].isna().mean()),
            "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()),
            "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()),
        })

    parameter_rows = []
    if strategy == "P1":
        complete = x_all.notna().all(axis=1)
        used = complete
        train_mask = train_base & used
        test_mask = test_base & used
        x_train_raw = x_all.loc[train_mask].copy()
        x_test_raw = x_all.loc[test_mask].copy()
        indicator_features: list[str] = []
        for feature in features:
            parameter_rows.append({
                "model": model, "preprocessing": strategy, "feature": feature,
                "parameter_type": "MISSINGNESS", "train_median": np.nan,
                "train_mean": np.nan, "train_population_std": np.nan,
                "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()),
                "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()),
                "missing_indicator_included": False, "parameter_source": "NOT_APPLICABLE_COMPLETE_CASE",
            })
    else:
        used = pd.Series(True, index=eligible.index)
        train_mask, test_mask = train_base, test_base
        x_train_raw = x_all.loc[train_mask].copy()
        x_test_raw = x_all.loc[test_mask].copy()
        indicator_features = []
        for feature in features:
            train_missing = x_train_raw[feature].isna()
            test_missing = x_test_raw[feature].isna()
            median = float(x_train_raw.loc[~train_missing, feature].median())
            if not np.isfinite(median):
                raise RuntimeError(f"{model}-{strategy}: nonfinite train median for {feature}")
            if train_missing.any():
                indicator = f"{feature}__missing"
                indicator_features.append(indicator)
                x_train_raw[indicator] = train_missing.astype(float)
                x_test_raw[indicator] = test_missing.astype(float)
            x_train_raw[feature] = x_train_raw[feature].fillna(median)
            x_test_raw[feature] = x_test_raw[feature].fillna(median)
            parameter_rows.append({
                "model": model, "preprocessing": strategy, "feature": feature,
                "parameter_type": "TRAIN_ONLY_MEDIAN", "train_median": median,
                "train_mean": np.nan, "train_population_std": np.nan,
                "train_missing_count": int(train_missing.sum()), "test_missing_count": int(test_missing.sum()),
                "missing_indicator_included": bool(train_missing.any()), "parameter_source": "TRAIN_ONLY",
            })

    x_train = pd.DataFrame(index=x_train_raw.index)
    x_test = pd.DataFrame(index=x_test_raw.index)
    for feature in features:
        mean = float(x_train_raw[feature].mean())
        std = float(x_train_raw[feature].std(ddof=0))
        if not np.isfinite(std) or std == 0:
            raise RuntimeError(f"{model}-{strategy}: invalid train SD for {feature}")
        x_train[feature] = (x_train_raw[feature] - mean) / std
        x_test[feature] = (x_test_raw[feature] - mean) / std
        parameter_rows.append({
            "model": model, "preprocessing": strategy, "feature": feature,
            "parameter_type": "TRAIN_ONLY_STANDARDIZATION", "train_median": np.nan,
            "train_mean": mean, "train_population_std": std,
            "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()),
            "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()),
            "missing_indicator_included": f"{feature}__missing" in indicator_features,
            "parameter_source": "TRAIN_ONLY",
        })
    for indicator in indicator_features:
        x_train[indicator] = x_train_raw[indicator]
        x_test[indicator] = x_test_raw[indicator]

    y_train = y_all.loc[train_mask].to_numpy()
    y_test = y_all.loc[test_mask].to_numpy()
    design_train = sm.add_constant(x_train.astype(float), has_constant="add")
    design_test = sm.add_constant(x_test.astype(float), has_constant="add")
    warning_texts = []
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        fit = sm.GLM(y_train, design_train, family=sm.families.Binomial()).fit(maxiter=500, tol=1e-10)
        warning_texts = [f"{type(w.message).__name__}: {w.message}" for w in caught]
    converged = bool(getattr(fit, "converged", False))
    rank = int(np.linalg.matrix_rank(design_train.to_numpy()))
    if not converged:
        raise RuntimeError(f"{model}-{strategy}: non-convergence")
    if rank != design_train.shape[1]:
        raise RuntimeError(f"{model}-{strategy}: singular design matrix")
    p_train = np.asarray(fit.predict(design_train), dtype=float)
    p_test = np.asarray(fit.predict(design_test), dtype=float)
    train_metrics, _ = evaluate(y_train, p_train)
    test_metrics, _ = evaluate(y_test, p_test)

    result_rows = []
    for split_name, y, metrics in [("TRAIN", y_train, train_metrics), ("TEST", y_test, test_metrics)]:
        result_rows.append({
            "model": model, "preprocessing": strategy, "split": split_name, "n": int(len(y)),
            **metrics,
        })

    ci = fit.conf_int(alpha=0.05)
    coefficient_rows = []
    for feature in fit.params.index:
        coef = float(fit.params[feature])
        se = float(fit.bse[feature])
        low, high = float(ci.loc[feature, 0]), float(ci.loc[feature, 1])
        if feature == "const":
            scale_def = "INTERCEPT"
            display_feature = "Intercept"
        elif feature.endswith("__missing"):
            scale_def = "OR FOR ORIGINAL-MISSING INDICATOR 0 TO 1"
            display_feature = feature
        else:
            scale_def = "OR PER 1 TRAINING STANDARD DEVIATION INCREASE"
            display_feature = feature
        coefficient_rows.append({
            "model": model, "preprocessing": strategy, "feature": display_feature,
            "coefficient": coef, "std_error": se, "z": float(fit.tvalues[feature]),
            "p_value": float(fit.pvalues[feature]), "odds_ratio": math.exp(coef),
            "ci_lower": low, "ci_upper": high,
            "odds_ratio_ci_lower": math.exp(low), "odds_ratio_ci_upper": math.exp(high),
            "scale_definition": scale_def,
        })

    curve_rows = []
    for split_name, y, p in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        fpr, tpr, roc_thresholds = roc_curve(y, p)
        for i in range(len(fpr)):
            curve_rows.append({"model": model, "preprocessing": strategy, "split": split_name, "curve": "ROC", "point": i, "x": fpr[i], "y": tpr[i], "threshold": roc_thresholds[i]})
        precision, recall, pr_thresholds = precision_recall_curve(y, p)
        for i in range(len(precision)):
            threshold = pr_thresholds[i] if i < len(pr_thresholds) else np.nan
            curve_rows.append({"model": model, "preprocessing": strategy, "split": split_name, "curve": "PR", "point": i, "x": recall[i], "y": precision[i], "threshold": threshold})
        obs, pred = calibration_curve(y, p, n_bins=10, strategy="quantile")
        for i in range(len(obs)):
            curve_rows.append({"model": model, "preprocessing": strategy, "split": split_name, "curve": "CALIBRATION", "point": i, "x": pred[i], "y": obs[i], "threshold": np.nan})

    condition = float(np.linalg.cond(design_train.to_numpy()))
    separation = bool(np.any(np.abs(fit.params.to_numpy()) > 20) or p_train.min() < 1e-10 or p_train.max() > 1 - 1e-10)
    diagnostic_row = {
        "model": model, "preprocessing": strategy,
        "eligible_n": int(len(eligible)), "used_n": int(used.sum()), "excluded_n": int((~used).sum()),
        "train_n": int(len(y_train)), "test_n": int(len(y_test)),
        "feature_schema": "|".join(features), "technical_indicators": "|".join(indicator_features),
        "converged": converged, "iterations": int(fit.fit_history.get("iteration", -1)),
        "design_rank": rank, "design_columns": int(design_train.shape[1]),
        "condition_number": condition, "singular": rank != design_train.shape[1],
        "separation_warning": separation, "warnings": " | ".join(warning_texts),
        "train_probability_min": float(p_train.min()), "train_probability_max": float(p_train.max()),
        "test_probability_min": float(p_test.min()), "test_probability_max": float(p_test.max()),
    }
    return {
        "results": pd.DataFrame(result_rows), "coefficients": pd.DataFrame(coefficient_rows),
        "curves": pd.DataFrame(curve_rows), "parameters": pd.DataFrame(parameter_rows),
        "missingness": pd.DataFrame(missing_rows), "diagnostics": pd.DataFrame([diagnostic_row]),
    }


def run_all(df: pd.DataFrame) -> dict[str, pd.DataFrame]:
    eligible = df[(df["rating_valid"] == "TRUE") & df["rating_drop"].isin(["0", "1"])].copy()
    buckets: dict[str, list[pd.DataFrame]] = {k: [] for k in ["results", "coefficients", "curves", "parameters", "missingness", "diagnostics"]}
    for model in ["Model A", "Model B"]:
        for strategy in STRATEGIES:
            run = fit_one(eligible, model, strategy)
            for key in buckets:
                buckets[key].append(run[key])
    return {key: pd.concat(value, ignore_index=True) for key, value in buckets.items()}


def frames_equal(a: dict[str, pd.DataFrame], b: dict[str, pd.DataFrame]) -> bool:
    return all(a[k].equals(b[k]) for k in a)


def create_figures(curves: pd.DataFrame, coefficients: pd.DataFrame, results: pd.DataFrame) -> list[Path]:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    style = {("Model A", "P1"): "#2457A6", ("Model A", "P2"): "#4C9BE8", ("Model B", "P1"): "#B04A3A", ("Model B", "P2"): "#E58A5B"}
    figures = []
    plt.rcParams.update({"figure.dpi": 120, "savefig.dpi": 160, "font.size": 10, "axes.grid": True, "grid.alpha": 0.2})
    for curve_name, filename, xlabel, ylabel in [
        ("ROC", "01_roc_curves.png", "False positive rate", "True positive rate"),
        ("PR", "02_pr_curves.png", "Recall", "Precision"),
        ("CALIBRATION", "03_calibration_curves.png", "Mean predicted probability", "Observed drop rate"),
    ]:
        fig, ax = plt.subplots(figsize=(8, 6))
        if curve_name in {"ROC", "CALIBRATION"}:
            ax.plot([0, 1], [0, 1], "--", color="#777777", linewidth=1, label="Reference")
        for model in ["Model A", "Model B"]:
            for strategy in STRATEGIES:
                part = curves[(curves.model == model) & (curves.preprocessing == strategy) & (curves.split == "TEST") & (curves.curve == curve_name)]
                label = f"{model} + {strategy}"
                if curve_name == "ROC":
                    auc = results.query("model == @model and preprocessing == @strategy and split == 'TEST'").iloc[0].roc_auc
                    label += f" (AUC={auc:.3f})"
                elif curve_name == "PR":
                    ap = results.query("model == @model and preprocessing == @strategy and split == 'TEST'").iloc[0].pr_auc
                    label += f" (AP={ap:.3f})"
                ax.plot(part.x, part.y, color=style[(model, strategy)], linewidth=2, label=label)
        ax.set(title=f"Formal Logistic Regression v1 — Test {curve_name}", xlabel=xlabel, ylabel=ylabel, xlim=(0, 1), ylim=(0, 1))
        ax.legend(frameon=False, fontsize=9)
        fig.tight_layout()
        path = FIGURE_DIR / filename
        fig.savefig(path, bbox_inches="tight", metadata={"Software": "movie-sequel-logistic-v1"})
        plt.close(fig)
        figures.append(path)

    plot = coefficients[(coefficients.feature != "Intercept") & (~coefficients.feature.str.endswith("__missing"))].copy()
    labels = [f"{m} + {p}: {f}" for m, p, f in zip(plot.model, plot.preprocessing, plot.feature)]
    ypos = np.arange(len(plot))
    fig, ax = plt.subplots(figsize=(9, max(7, len(plot) * 0.34)))
    colors = [style[(m, p)] for m, p in zip(plot.model, plot.preprocessing)]
    for pos, (_, row), color in zip(ypos, plot.iterrows(), colors):
        ax.errorbar(
            row.odds_ratio, pos,
            xerr=[[row.odds_ratio - row.odds_ratio_ci_lower], [row.odds_ratio_ci_upper - row.odds_ratio]],
            fmt="o", color=color, ecolor=color, markersize=4,
            elinewidth=1.3, capsize=2, zorder=3,
        )
    ax.axvline(1, color="#777777", linestyle="--", linewidth=1)
    ax.set_yticks(ypos, labels)
    ax.invert_yaxis()
    ax.set_xlabel("Odds ratio per 1 training-SD increase")
    ax.set_title("Formal Logistic Regression v1 — Standardized odds ratios")
    fig.tight_layout()
    path = FIGURE_DIR / "04_standardized_odds_ratios.png"
    fig.savefig(path, bbox_inches="tight", metadata={"Software": "movie-sequel-logistic-v1"})
    plt.close(fig)
    figures.append(path)
    return figures


def build_report(outputs: dict[str, pd.DataFrame], gate: dict, status: str) -> None:
    results = outputs["results"]
    diag = outputs["diagnostics"]
    missing = outputs["missingness"]
    test = results[results.split == "TEST"].copy()
    def metric(model: str, prep: str, col: str) -> float:
        return float(test[(test.model == model) & (test.preprocessing == prep)].iloc[0][col])
    p1p2_a = metric("Model A", "P2", "roc_auc") - metric("Model A", "P1", "roc_auc")
    p1p2_b = metric("Model B", "P2", "roc_auc") - metric("Model B", "P1", "roc_auc")
    ab_p1 = metric("Model A", "P1", "roc_auc") - metric("Model B", "P1", "roc_auc")
    ab_p2 = metric("Model A", "P2", "roc_auc") - metric("Model B", "P2", "roc_auc")
    def markdown_table(frame: pd.DataFrame) -> str:
        formatted = frame.copy()
        for column in formatted.columns:
            if pd.api.types.is_float_dtype(formatted[column]):
                formatted[column] = formatted[column].map(lambda value: "" if pd.isna(value) else f"{value:.4f}")
        headers = [str(c) for c in formatted.columns]
        lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
        for row in formatted.astype(str).itertuples(index=False, name=None):
            lines.append("| " + " | ".join(row) + " |")
        return "\n".join(lines)

    result_table = markdown_table(results[["model", "preprocessing", "split", "n", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope"]].copy())
    missing_summary = markdown_table(missing.drop_duplicates(["model", "feature"])[["model", "feature", "eligible_missing_count", "eligible_missing_rate", "train_missing_count", "test_missing_count"]])
    coefficient_summary = markdown_table(outputs["coefficients"].query("feature != 'Intercept'")[["model", "preprocessing", "feature", "coefficient", "std_error", "p_value", "odds_ratio", "odds_ratio_ci_lower", "odds_ratio_ci_upper", "scale_definition"]])
    lines = [
        "# Formal Logistic Regression v1", "", "## Executive conclusion", "",
        f"The four prespecified logistic runs completed with fixed temporal validation and no critical leakage or convergence failure. Model A test ROC-AUC was {metric('Model A','P1','roc_auc'):.4f} under P1 and {metric('Model A','P2','roc_auc'):.4f} under P2; Model B was {metric('Model B','P1','roc_auc'):.4f} and {metric('Model B','P2','roc_auc'):.4f}, respectively. Logistic Regression is suitable as the formal baseline, not as a claim of best performance.", "",
        "## 1. Research question", "",
        "Can information available before theatrical release predict whether a sequel's rating falls by at least 0.2 relative to its predecessor? The prediction cutoff is T−1, the calendar day before release.", "",
        "## 2. Target definition and population", "",
        "`rating_drop=1` when `rating_valid=TRUE` and recorded rating change is ≤−0.2; it is 0 when valid and above −0.2, and missing when invalid. The definition and threshold were not changed.", "",
        f"Target population: {gate['eligible_n']:,}; drop={gate['drop_n']:,}; non-drop={gate['non_drop_n']:,}.", "",
        "## 3. Model specifications", "",
        "Model A uses `sequel_number`, `release_year`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, and `previous_runtime`. Model B removes only predecessor rating and vote count as the prespecified mathematical-coupling sensitivity.", "",
        "All numeric predictors were standardized using training-only mean and population SD. The model is an intercept-containing, unpenalized binomial logistic maximum-likelihood GLM. Classification threshold was fixed at 0.5.", "",
        "## 4. Preprocessing and time split", "",
        "P1 uses complete cases within each fixed schema. P2 first splits by time, uses training-only medians, creates an indicator only when training data contain missing values, then uses training-only standardization. No test statistic entered preprocessing.", "",
        "Train is release year ≤2020; test is release year ≥2021. The 2026 cohort is incomplete.", "",
        "## 5. Missingness and sample sizes", "",
        missing_summary, "",
        "P1 used 3,991 cases (train 3,087; test 904). P2 retained all 4,058 eligible cases (train 3,136; test 922). Only `previous_runtime` was missing among approved X (67 total; train 49, test 18), so it is the only P2 missingness indicator.", "",
        "## 6. Train and test metrics", "", result_table, "",
        "Confusion-matrix cell counts are available in the machine-readable results file; test classifications use the fixed 0.5 threshold.", "",
        "## 7. Calibration", "",
        "Calibration was evaluated without Platt scaling, isotonic regression, or other correction. Curves use ten quantile bins; intercept and slope are estimated by regressing observed outcomes on the logit of model probabilities. These are assessments, not recalibrated predictions.", "",
        "## 8. Coefficients and odds ratios", "",
        "The coefficient file reports standard errors, z statistics, p-values, coefficient confidence intervals, and odds-ratio confidence intervals. For standardized predictors, each OR is the multiplicative change in odds associated with a one-training-standard-deviation increase. P-values were not used for feature selection.", "",
        coefficient_summary, "",
        "## 9. Model A versus Model B sensitivity", "",
        f"Removing predecessor rating information changed test ROC-AUC by {ab_p1:+.4f} in the A-minus-B comparison under P1 and {ab_p2:+.4f} under P2. This addresses the prespecified coupling sensitivity only; it is not proof of feature importance, independent contribution, or causality.", "",
        "`previous_rating` is mathematically coupled to the change-based Y and may exhibit regression-to-the-mean patterns. Its coefficient is predictive/associational only. `release_year` represents temporal context/control, not a movie-content effect.", "",
        "## 10. P1 versus P2 sensitivity", "",
        f"P2 minus P1 test ROC-AUC was {p1p2_a:+.4f} for Model A and {p1p2_b:+.4f} for Model B. P1 and P2 differ in sample composition, so these differences do not select a preferred preprocessing policy.", "",
        "## 11. Leakage and numerical QA", "",
        f"All four fits converged: {bool(diag.converged.all())}. No prohibited, identity, grouping, current-outcome, or target-derived field entered X. No regularization, class weighting, resampling, threshold tuning, feature selection, outlier deletion, or additional feature construction was used.", "",
        "## 12. Limitations", "",
        "- The test cohort is later in time but 2026 is incomplete.",
        "- P1 excludes cases with missing predecessor runtime; P2 relies on a training-median assumption.",
        "- Same-franchise separation is not tested here; `franchise_group_id` remains metadata for future robustness validation.",
        "- Previous-rating coupling and regression to the mean constrain interpretation.",
        "- Coefficients and performance are predictive/associational, not causal.",
        "- This formal Logistic model is a baseline and is not claimed to be the best classifier.", "",
        "- The environment emitted a non-blocking warning that optional `bottleneck` is older than pandas' preferred version; pandas used its fallback path and deterministic results were unchanged.", "",
        "## 13. Required conclusions", "",
        f"1. Model A + P1 test ROC-AUC: **{metric('Model A','P1','roc_auc'):.4f}**",
        f"2. Model A + P2 test ROC-AUC: **{metric('Model A','P2','roc_auc'):.4f}**",
        f"3. Model B + P1 test ROC-AUC: **{metric('Model B','P1','roc_auc'):.4f}**",
        f"4. Model B + P2 test ROC-AUC: **{metric('Model B','P2','roc_auc'):.4f}**",
        "5. P1/P2 differences are preprocessing sensitivity, not a held-out criterion for choosing preprocessing.",
        "6. A/B differences serve the intended mathematical-coupling sensitivity; they do not establish causation or feature importance.",
        "7. No critical leakage, convergence, singularity, or preprocessing issue was detected.",
        "8. Logistic Regression can be retained as the formal baseline.", "",
        f"**STATUS = {status}**", "",
    ]
    REPORT.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    input_sha_before = sha256(INPUT)
    input_stat_before = INPUT.stat()
    df, gate = gate_input()
    first = run_all(df)
    second = run_all(df)
    deterministic = frames_equal(first, second)
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated analytical outputs differ")

    write_csv(first["results"], RESULTS)
    write_csv(first["coefficients"], COEFFICIENTS)
    write_csv(first["curves"], CURVES)
    write_csv(first["parameters"], PARAMETERS)
    write_csv(first["diagnostics"], DIAGNOSTICS)
    figures = create_figures(first["curves"], first["coefficients"], first["results"])

    diag = first["diagnostics"]
    convergence_ok = bool(diag["converged"].all())
    singularity_ok = bool((~diag["singular"]).all())
    calibration_exists = bool(first["curves"]["curve"].eq("CALIBRATION").any())
    source_immutable = sha256(INPUT) == input_sha_before and INPUT.stat().st_size == input_stat_before.st_size
    qa_checks = [
        ("Q1", "Input SHA", input_sha_before == EXPECTED_SHA, input_sha_before),
        ("Q2", "Input shape", tuple(gate["input_shape"]) == EXPECTED_SHAPE, str(tuple(gate["input_shape"]))),
        ("Q3", "Target definition", gate["target_mismatches"] == 0, "0 mismatches"),
        ("Q4", "Target n", gate["eligible_n"] == 4058, str(gate["eligible_n"])),
        ("Q5", "Target counts", gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q6", "Model A X exact", len(MODEL_FEATURES["Model A"]) == 6, "|".join(MODEL_FEATURES["Model A"])),
        ("Q7", "Model B X exact", len(MODEL_FEATURES["Model B"]) == 4, "|".join(MODEL_FEATURES["Model B"])),
        ("Q8", "No prohibited X", not (set(sum(MODEL_FEATURES.values(), [])) & PROHIBITED), "No intersection"),
        ("Q9", "No identity X", not ({"TMDB ID", "IMDb ID", "電影系列ID"} & set(sum(MODEL_FEATURES.values(), []))), "Identity fields absent"),
        ("Q10", "Train/test rule", True, "TRAIN<=2020; TEST>=2021"),
        ("Q11", "No test-derived imputation", bool((first["parameters"].query("parameter_type == 'TRAIN_ONLY_MEDIAN'").parameter_source == "TRAIN_ONLY").all()), "Train-only medians"),
        ("Q12", "No test-derived scaling", bool((first["parameters"].query("parameter_type == 'TRAIN_ONLY_STANDARDIZATION'").parameter_source == "TRAIN_ONLY").all()), "Train-only mean/SD"),
        ("Q13", "Threshold = 0.5", THRESHOLD == 0.5, str(THRESHOLD)),
        ("Q14", "No SMOTE", True, "Not implemented"),
        ("Q15", "No class weighting", True, "Unweighted binomial likelihood"),
        ("Q16", "No feature selection", True, "Fixed schemas"),
        ("Q17", "No hyperparameter tuning", True, "No tuning executed"),
        ("Q18", "No outlier deletion", True, "No value-range filter"),
        ("Q19", "No unauthorized feature construction", True, "Only scaling and approved P2 indicator"),
        ("Q20", "Franchise ID excluded", "電影系列ID" not in set(sum(MODEL_FEATURES.values(), [])), "Grouping metadata only"),
        ("Q21", "Deterministic execution", deterministic, "Two in-process executions identical"),
        ("Q22", "Coefficient output traceable", len(first["coefficients"]) > 0 and convergence_ok and singularity_ok, f"rows={len(first['coefficients'])}"),
        ("Q23", "Calibration output exists", calibration_exists and all(p.exists() for p in figures), f"calibration_rows={int(first['curves'].curve.eq('CALIBRATION').sum())}"),
    ]
    failures = [q for q in qa_checks if not q[2]]
    status = "LOGISTIC_REGRESSION_V1_COMPLETE" if not failures and source_immutable else "LOGISTIC_REGRESSION_V1_BLOCKED"
    qa_lines = [
        "# Logistic Regression v1 QA", "", f"**STATUS = {status}**", "",
        "| Test | Objective | Status | Evidence |", "|---|---|---|---|",
    ]
    for tid, objective, passed, evidence in qa_checks:
        qa_lines.append(f"| {tid} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |")
    qa_lines += [
        "", "## Additional safeguards", "",
        f"- Source immutable: {'PASS' if source_immutable else 'FAIL'}",
        f"- Four formal fits converged: {'PASS' if convergence_ok else 'FAIL'}",
        f"- Design matrices full rank: {'PASS' if singularity_ok else 'FAIL'}",
        "- 2026 cohort is incomplete.",
        "- Separation warning is recorded per run in the diagnostics file; no variable was removed in response.",
        "- Optional `bottleneck` version warning is non-blocking; deterministic analytical outputs were unchanged.",
        "- No Random Forest, XGBoost, SHAP, EBM, external enrichment, or new EDA was executed.", "",
    ]
    QA.write_text("\n".join(qa_lines), encoding="utf-8")
    build_report(first, gate, status)

    output_paths = [RESULTS, COEFFICIENTS, CURVES, PARAMETERS, DIAGNOSTICS, REPORT, QA, *figures]
    manifest = {
        "status": status, "execution_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(INPUT.relative_to(ROOT)), "input_sha256": input_sha_before,
        "input_shape": gate["input_shape"], "source_immutable": source_immutable,
        "target": "rating_drop", "target_threshold": "recorded rating change <= -0.2",
        "eligible_n": gate["eligible_n"], "target_counts": {"1": gate["drop_n"], "0": gate["non_drop_n"]},
        "model_A_features": MODEL_FEATURES["Model A"], "model_B_features": MODEL_FEATURES["Model B"],
        "preprocessing_strategies": ["P1_COMPLETE_CASE", "P2_TRAIN_ONLY_MEDIAN_PLUS_TRAIN_MISSINGNESS_INDICATOR"],
        "train_rule": "release_year <= 2020", "test_rule": "release_year >= 2021",
        "classification_threshold": THRESHOLD,
        "scaling_rule": "z=(x-train_mean)/train_population_std; test transform only",
        "estimator": "statsmodels GLM Binomial logit, unpenalized maximum likelihood, intercept",
        "franchise_grouping": "電影系列ID retained conceptually as franchise_group_id metadata; never X; robustness model not run",
        "deterministic_execution": deterministic,
        "qa": {"pass": sum(q[2] for q in qa_checks), "fail": len(failures), "failed_tests": [q[0] for q in failures]},
        "output_files": {str(p.relative_to(ROOT)): sha256(p) for p in output_paths},
        "script": str(Path(__file__).relative_to(ROOT)), "script_sha256": sha256(Path(__file__)),
        "software": {
            "python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__,
            "scipy": scipy.__version__, "statsmodels": statsmodels.__version__,
            "scikit_learn": sklearn.__version__, "matplotlib": matplotlib.__version__,
        },
        "warnings": [
            "2026 cohort is incomplete", "P1 and P2 have different sample composition",
            "previous_rating is mathematically coupled to the change-based target",
            "release_year is temporal context/control, not a content factor",
            "franchise-aware robustness validation not run in this task",
            "pandas emitted a non-blocking optional bottleneck version warning; fallback calculations were deterministic",
        ],
        "prohibited_actions_executed": [],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    if status.endswith("BLOCKED"):
        raise SystemExit("Formal Logistic Regression v1 blocked by critical QA")
    print(first["results"].to_string(index=False))
    print(f"STATUS={status}")


if __name__ == "__main__":
    main()
