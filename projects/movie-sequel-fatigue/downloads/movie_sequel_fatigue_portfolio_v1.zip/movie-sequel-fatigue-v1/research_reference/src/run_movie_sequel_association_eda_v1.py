#!/usr/bin/env python3
"""Execute Movie Sequel Association EDA v1 deterministically.

This script reads the immutable Feature Engineering v1 CSV, verifies the
approved gates, produces descriptive/association tables and figures, and
writes a provenance manifest. It performs no imputation, feature selection,
pair reconstruction, external lookup, preprocessing, or machine learning.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import shutil
import tempfile
from collections import OrderedDict
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
SPEC = ROOT / "reports/movie_sequel_association_eda_spec_v1.md"
PLAN = ROOT / "reports/movie_sequel_association_eda_analysis_plan_v1.csv"
REPORT = ROOT / "reports/movie_sequel_association_eda_v1.md"
MANIFEST = ROOT / "reports/movie_sequel_association_eda_manifest_v1.json"
FIGURE_DIR = ROOT / "reports/figures/movie_sequel_eda_v1"
TABLE_DIR = ROOT / "reports/tables/movie_sequel_eda_v1"
EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)

CORE_NUMERIC = OrderedDict([
    ("與前作評分差", "rating_change"),
    ("previous_rating", "previous_rating"),
    ("previous_rating_votes", "previous_rating_votes"),
    ("years_since_previous", "years_since_previous"),
    ("previous_runtime", "previous_runtime"),
    ("sequel_number", "sequel_number"),
])

EXPECTED_SOURCE_LABELS = [
    "Kaggle歷史資料",
    "TMDB API 2021-2026",
    "TMDB 2018–2020補充",
    "TMDB API 2018-2020",
    "Kaggle歷史資料 + TMDB API 2021-2026",
]

FEATURE_BANDS = {
    "previous_rating": ([-np.inf, 5, 6, 7, 8, np.inf], ["<5", "5–<6", "6–<7", "7–<8", "8+"]),
    "previous_rating_votes": ([-np.inf, 100, 1_000, 10_000, 100_000, np.inf], ["<100", "100–999", "1k–9,999", "10k–99,999", "100k+"]),
    "years_since_previous": ([-np.inf, 1, 3, 5, 10, np.inf], ["<1", "1–<3", "3–<5", "5–<10", "10+"]),
    "previous_runtime": ([-np.inf, 60, 90, 120, 150, np.inf], ["<60", "60–<90", "90–<120", "120–<150", "150+"]),
}

LOGISTIC_UNITS = {
    "previous_rating": 1.0,
    "previous_rating_votes": 10_000.0,
    "years_since_previous": 1.0,
    "previous_runtime": 10.0,
    "片長(分鐘)": 10.0,
    "與前作片長差": 10.0,
    "片長變化率": 0.1,
}

REQUIRED_COLUMNS = {
    "電影系列", "電影系列ID", "第幾部", "系列總部數", "電影名稱", "中文片名",
    "上映日期", "上映年", "類型", "片長(分鐘)", "預算", "票房", "人氣", "平均評分",
    "評分人數", "導演", "主演1", "主演2", "主演3", "與前作上映間隔(年)", "前作評分",
    "前作評分人數", "前作導演", "導演是否更換", "與前作共同主演數", "主演是否更換",
    "前作片長", "與前作片長差", "片長變化率", "前作預算", "與前作預算差", "預算變化率",
    "前作票房", "與前作票房差", "票房變化率", "與前作評分差", "口碑是否下滑",
    "評分樣本是否足夠", "TMDB ID", "IMDb ID", "資料來源", "rating_valid",
    "rating_drop", "sequel_number", "release_year", "previous_rating", "previous_rating_votes",
    "years_since_previous", "previous_runtime",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tree_hash(paths: list[Path], base: Path) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: str(item.relative_to(base))):
        digest.update(str(path.relative_to(base)).encode("utf-8"))
        digest.update(b"\0")
        digest.update(path.read_bytes())
        digest.update(b"\0")
    return digest.hexdigest()


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
    except InvalidOperation:
        return None
    return number if number.is_finite() else None


def load_and_gate() -> tuple[pd.DataFrame, dict]:
    input_sha = sha256(INPUT)
    if input_sha != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL GATE FAIL: input SHA256 {input_sha} != {EXPECTED_SHA}")
    frame = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if frame.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL GATE FAIL: shape {frame.shape} != {EXPECTED_SHAPE}")
    missing_required = sorted(REQUIRED_COLUMNS - set(frame.columns))
    if missing_required:
        raise SystemExit(f"CRITICAL GATE FAIL: missing required columns {missing_required}")

    target_mismatches = []
    for position, row in frame.iterrows():
        current = decimal_or_none(row["平均評分"])
        previous = decimal_or_none(row["前作評分"])
        change = decimal_or_none(row["與前作評分差"])
        valid = bool(current is not None and previous is not None and change is not None and current > 0 and previous > 0)
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            target_mismatches.append(int(position) + 2)
    if target_mismatches:
        raise SystemExit(f"CRITICAL GATE FAIL: target logic mismatches {target_mismatches[:10]}")

    tmdb = frame["TMDB ID"]
    imdb = frame.loc[frame["IMDb ID"] != "", "IMDb ID"]
    if int((tmdb == "").sum()) or int(tmdb.duplicated().sum()):
        raise SystemExit("CRITICAL GATE FAIL: TMDB ID missing or duplicated")
    if int(imdb.duplicated().sum()):
        raise SystemExit("CRITICAL GATE FAIL: nonempty IMDb ID duplicated")

    gate = {
        "input_sha256": input_sha,
        "input_rows": int(frame.shape[0]),
        "input_columns": int(frame.shape[1]),
        "required_columns_missing": 0,
        "target_logic_mismatches": 0,
        "tmdb_missing": int((tmdb == "").sum()),
        "tmdb_duplicates": int(tmdb.duplicated().sum()),
        "imdb_nonempty": int(len(imdb)),
        "imdb_duplicates": int(imdb.duplicated().sum()),
        "status": "PASS",
    }
    return frame, gate


def numeric(frame: pd.DataFrame, column: str) -> pd.Series:
    return pd.to_numeric(frame[column].replace("", np.nan), errors="coerce")


def bool_valid(frame: pd.DataFrame) -> pd.Series:
    return frame["rating_valid"].eq("TRUE") & frame["rating_drop"].isin(["0", "1"])


def wilson_ci(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if n <= 0:
        return (np.nan, np.nan)
    p = k / n
    denominator = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denominator
    spread = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denominator
    return centre - spread, centre + spread


def numeric_summary(series: pd.Series) -> dict:
    values = pd.to_numeric(series, errors="coerce")
    clean = values.dropna()
    n = int(clean.size)
    return {
        "n": n,
        "missing_count": int(values.size - n),
        "missing_rate": float((values.size - n) / values.size) if values.size else np.nan,
        "mean": float(clean.mean()) if n else np.nan,
        "sd": float(clean.std(ddof=1)) if n > 1 else np.nan,
        "median": float(clean.median()) if n else np.nan,
        "q1": float(clean.quantile(0.25)) if n else np.nan,
        "q3": float(clean.quantile(0.75)) if n else np.nan,
        "min": float(clean.min()) if n else np.nan,
        "max": float(clean.max()) if n else np.nan,
    }


def rank_correlation(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 3:
        return np.nan
    xr = pd.Series(x).rank(method="average").to_numpy(dtype=float)
    yr = pd.Series(y).rank(method="average").to_numpy(dtype=float)
    if np.std(xr) == 0 or np.std(yr) == 0:
        return np.nan
    return float(np.corrcoef(xr, yr)[0, 1])


def pearson_correlation(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return np.nan
    return float(np.corrcoef(x, y)[0, 1])


def logistic_one_predictor(x: np.ndarray, y: np.ndarray, unit: float) -> dict:
    mask = np.isfinite(x) & np.isfinite(y)
    x = x[mask].astype(float) / unit
    y = y[mask].astype(float)
    result = {
        "logistic_unit": unit,
        "logistic_beta": np.nan,
        "logistic_se": np.nan,
        "odds_ratio": np.nan,
        "odds_ratio_ci_low": np.nan,
        "odds_ratio_ci_high": np.nan,
        "logistic_status": "NOT_ESTIMABLE",
    }
    if len(x) < 20 or len(np.unique(y)) < 2 or np.std(x) == 0:
        return result
    design = np.column_stack([np.ones(len(x)), x])
    beta = np.zeros(2, dtype=float)
    converged = False
    for _ in range(100):
        eta = np.clip(design @ beta, -35, 35)
        prob = 1 / (1 + np.exp(-eta))
        weights = np.clip(prob * (1 - prob), 1e-12, None)
        information = design.T @ (weights[:, None] * design)
        score = design.T @ (y - prob)
        try:
            step = np.linalg.solve(information, score)
        except np.linalg.LinAlgError:
            return result
        beta = beta + step
        if float(np.max(np.abs(step))) < 1e-9:
            converged = True
            break
    if not converged:
        result["logistic_status"] = "UNSTABLE"
        return result
    eta = np.clip(design @ beta, -35, 35)
    prob = 1 / (1 + np.exp(-eta))
    information = design.T @ ((prob * (1 - prob))[:, None] * design)
    try:
        covariance = np.linalg.inv(information)
    except np.linalg.LinAlgError:
        result["logistic_status"] = "UNSTABLE"
        return result
    se = math.sqrt(max(float(covariance[1, 1]), 0))
    slope = float(beta[1])
    if max(abs(slope), abs(slope - 1.959963984540054 * se), abs(slope + 1.959963984540054 * se)) > 700:
        result["logistic_status"] = "UNSTABLE"
        return result
    result.update({
        "logistic_beta": slope,
        "logistic_se": se,
        "odds_ratio": math.exp(slope),
        "odds_ratio_ci_low": math.exp(slope - 1.959963984540054 * se),
        "odds_ratio_ci_high": math.exp(slope + 1.959963984540054 * se),
        "logistic_status": "ESTIMABLE",
    })
    return result


def prevalence_table(groups: pd.Series, target: pd.Series, order: list[str] | None = None) -> pd.DataFrame:
    work = pd.DataFrame({"group": groups, "target": target}).dropna(subset=["group", "target"])
    work["group"] = work["group"].astype(str)
    observed = list(dict.fromkeys(work["group"].tolist()))
    labels = order if order is not None else observed
    rows = []
    for label in labels:
        subset = work.loc[work["group"] == str(label), "target"].astype(int)
        n = int(subset.size)
        drop = int(subset.sum()) if n else 0
        low, high = wilson_ci(drop, n)
        rows.append({
            "group": str(label), "n": n, "drop_n": drop, "non_drop_n": n - drop,
            "drop_prevalence": drop / n if n else np.nan,
            "ci_method": "Wilson 95%", "ci_low": low, "ci_high": high,
        })
    return pd.DataFrame(rows)


def add_reference_comparisons(table: pd.DataFrame, reference: str) -> pd.DataFrame:
    out = table.copy()
    out["reference_group"] = reference
    out["prevalence_difference_vs_reference"] = np.nan
    out["odds_ratio_vs_reference"] = np.nan
    out["odds_ratio_ci_low"] = np.nan
    out["odds_ratio_ci_high"] = np.nan
    out["comparison_status"] = "NOT_ESTIMABLE"
    ref = out.loc[out["group"] == reference]
    if ref.empty or int(ref.iloc[0]["n"]) == 0:
        return out
    ref_row = ref.iloc[0]
    a0 = int(ref_row["drop_n"])
    b0 = int(ref_row["non_drop_n"])
    p0 = float(ref_row["drop_prevalence"])
    for idx, row in out.iterrows():
        if row["group"] == reference:
            out.loc[idx, ["prevalence_difference_vs_reference", "odds_ratio_vs_reference", "odds_ratio_ci_low", "odds_ratio_ci_high"]] = [0.0, 1.0, 1.0, 1.0]
            out.loc[idx, "comparison_status"] = "REFERENCE"
            continue
        a1 = int(row["drop_n"])
        b1 = int(row["non_drop_n"])
        out.loc[idx, "prevalence_difference_vs_reference"] = float(row["drop_prevalence"]) - p0 if int(row["n"]) else np.nan
        if min(a0, b0, a1, b1) <= 0:
            out.loc[idx, "comparison_status"] = "UNSTABLE_ZERO_CELL"
            continue
        odds_ratio = (a1 / b1) / (a0 / b0)
        se = math.sqrt(1 / a1 + 1 / b1 + 1 / a0 + 1 / b0)
        out.loc[idx, ["odds_ratio_vs_reference", "odds_ratio_ci_low", "odds_ratio_ci_high"]] = [
            odds_ratio,
            math.exp(math.log(odds_ratio) - 1.959963984540054 * se),
            math.exp(math.log(odds_ratio) + 1.959963984540054 * se),
        ]
        out.loc[idx, "comparison_status"] = "ESTIMABLE"
    return out


def era_labels(years: pd.Series) -> pd.Series:
    return pd.cut(
        years,
        bins=[-np.inf, 1959, 1989, 2009, 2019, np.inf],
        labels=["≤1959", "1960–1989", "1990–2009", "2010–2019", "2020–2026"],
        include_lowest=True,
    )


def sequel_group(values: pd.Series) -> pd.Series:
    out = pd.Series(pd.NA, index=values.index, dtype="object")
    out.loc[values == 2] = "2"
    out.loc[values == 3] = "3"
    out.loc[values == 4] = "4"
    out.loc[values >= 5] = "5+"
    out.loc[values < 2] = "OTHER"
    return out


def clean_for_association(frame: pd.DataFrame, column: str) -> tuple[np.ndarray, np.ndarray, int]:
    x = numeric(frame, column)
    eligible = bool_valid(frame)
    y = pd.to_numeric(frame["rating_drop"].replace("", np.nan), errors="coerce")
    mask = eligible & x.notna() & y.notna()
    return x[mask].to_numpy(dtype=float), y[mask].to_numpy(dtype=float), int((eligible & x.isna()).sum())


def core_numeric_associations(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for column in ["previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"]:
        x, y, missing_n = clean_for_association(frame, column)
        unit = LOGISTIC_UNITS[column]
        logistic = logistic_one_predictor(x, y, unit)
        rows.append({
            "x_variable": column,
            "eligible_n": int(len(x)),
            "missing_x_within_target_population": missing_n,
            "drop_n": int(y.sum()),
            "spearman_rho": rank_correlation(x, y),
            "point_biserial_r": pearson_correlation(x, y) if column == "previous_rating" else np.nan,
            "p_value_policy": "Not reported; effect size and 95% CI prioritized",
            **logistic,
            "interpretation": "UNADJUSTED_ASSOCIATION",
        })
    return pd.DataFrame(rows)


def build_tables(frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
    tables: dict[str, pd.DataFrame] = {}
    valid = bool_valid(frame)
    target = pd.to_numeric(frame["rating_drop"].replace("", np.nan), errors="coerce")
    years = numeric(frame, "release_year")

    overview_rows = [
        {"metric": "row_count", "value": len(frame), "note": "All source rows retained"},
        {"metric": "column_count", "value": len(frame.columns), "note": "50 input columns"},
        {"metric": "release_year_min", "value": years.min(), "note": "Nonmissing release_year"},
        {"metric": "release_year_max", "value": years.max(), "note": "2026 is incomplete-year data"},
        {"metric": "tmdb_id_nonmissing", "value": int(frame["TMDB ID"].ne("").sum()), "note": "Exact identifiers"},
        {"metric": "imdb_id_nonmissing", "value": int(frame["IMDb ID"].ne("").sum()), "note": "Exact identifiers"},
        {"metric": "target_valid", "value": int(valid.sum()), "note": "rating_valid TRUE and rating_drop nonmissing"},
        {"metric": "target_invalid_or_missing", "value": int((~valid).sum()), "note": "Retained outside binary-target population"},
    ]
    tables["dataset_overview.csv"] = pd.DataFrame(overview_rows)

    year_counts = years.value_counts(dropna=False).sort_index().rename_axis("release_year").reset_index(name="n")
    year_counts["percentage_all_rows"] = year_counts["n"] / len(frame)
    year_counts["incomplete_year_warning"] = year_counts["release_year"].eq(2026)
    tables["release_year_distribution.csv"] = year_counts

    decades = (np.floor(years / 10) * 10).astype("Int64").astype(str).replace("<NA>", "MISSING")
    decade_counts = decades.value_counts(dropna=False).sort_index().rename_axis("decade_start").reset_index(name="n")
    decade_counts["percentage_all_rows"] = decade_counts["n"] / len(frame)
    tables["decade_distribution.csv"] = decade_counts

    source_counts = frame["資料來源"].replace("", "MISSING").value_counts(dropna=False).rename_axis("source_label").reset_index(name="n")
    source_counts["percentage_all_rows"] = source_counts["n"] / len(frame)
    source_counts["expected_exact_label"] = source_counts["source_label"].isin(EXPECTED_SOURCE_LABELS)
    tables["source_distribution.csv"] = source_counts

    missing_rows = []
    for column in frame.columns:
        count = int(frame[column].eq("").sum())
        missing_rows.append({"column": column, "nonmissing_n": len(frame) - count, "missing_n": count, "missing_rate": count / len(frame)})
    tables["missingness.csv"] = pd.DataFrame(missing_rows)

    numeric_rows = []
    for source_column, analysis_name in CORE_NUMERIC.items():
        summary = numeric_summary(numeric(frame, source_column))
        numeric_rows.append({"analysis_variable": analysis_name, "source_column": source_column, **summary})
    tables["numeric_distributions.csv"] = pd.DataFrame(numeric_rows)

    drop_n = int(target[valid].sum())
    valid_n = int(valid.sum())
    ci_low, ci_high = wilson_ci(drop_n, valid_n)
    tables["target_distribution.csv"] = pd.DataFrame([
        {"category": "rating_drop=1", "n": drop_n, "proportion_valid": drop_n / valid_n, "ci_method": "Wilson 95%", "ci_low": ci_low, "ci_high": ci_high},
        {"category": "rating_drop=0", "n": valid_n - drop_n, "proportion_valid": (valid_n - drop_n) / valid_n, "ci_method": "Wilson 95%", "ci_low": 1 - ci_high, "ci_high": 1 - ci_low},
        {"category": "invalid_or_missing", "n": len(frame) - valid_n, "proportion_valid": np.nan, "ci_method": "Not applicable", "ci_low": np.nan, "ci_high": np.nan},
    ])

    rating_change = numeric(frame, "與前作評分差")
    frequency = rating_change[valid].value_counts().sort_index().rename_axis("rating_change").reset_index(name="n")
    frequency["proportion_valid"] = frequency["n"] / valid_n
    frequency["fixed_threshold"] = -0.2
    tables["rating_change_frequency.csv"] = frequency

    comparison_rows = []
    for column in ["release_year", "sequel_number", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"]:
        values = numeric(frame, column)
        for population, mask in [("ALL_ROWS", pd.Series(True, index=frame.index)), ("VALID_TARGET", valid)]:
            summary = numeric_summary(values[mask])
            comparison_rows.append({"variable": column, "population": population, **summary})
    comparison = pd.DataFrame(comparison_rows)
    tables["population_comparison.csv"] = comparison

    sequel_values = numeric(frame, "sequel_number")
    exact_labels = [str(int(value)) for value in sorted(sequel_values[valid].dropna().unique())]
    exact = prevalence_table(sequel_values[valid].astype("Int64").astype(str).replace("<NA>", np.nan), target[valid], exact_labels)
    tables["core_sequel_number_exact.csv"] = add_reference_comparisons(exact, "2")
    groups = sequel_group(sequel_values)
    grouped = prevalence_table(groups[valid], target[valid], ["2", "3", "4", "5+", "OTHER"])
    tables["core_sequel_group.csv"] = add_reference_comparisons(grouped, "2")

    sequel_change_rows = []
    for label in ["2", "3", "4", "5+"]:
        summary = numeric_summary(rating_change[valid & groups.eq(label)])
        sequel_change_rows.append({"sequel_group": label, **summary, "outcome": "recorded 與前作評分差"})
    tables["core_sequel_group_rating_change.csv"] = pd.DataFrame(sequel_change_rows)

    tables["core_numeric_associations.csv"] = core_numeric_associations(frame)
    class_distribution_rows = []
    for column in ["previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"]:
        values = numeric(frame, column)
        for target_class, class_label in [(0, "rating_drop=0"), (1, "rating_drop=1")]:
            mask = valid & target.eq(target_class)
            summary = numeric_summary(values[mask])
            class_distribution_rows.append({"x_variable": column, "target_class": class_label, **summary})
    tables["core_target_class_distributions.csv"] = pd.DataFrame(class_distribution_rows)
    for column, (edges, labels) in FEATURE_BANDS.items():
        values = numeric(frame, column)
        band = pd.cut(values, bins=edges, labels=labels, right=False, include_lowest=True)
        tables[f"core_{column}_bands.csv"] = prevalence_table(band[valid], target[valid], labels)

    eras = era_labels(years)
    tables["temporal_robustness.csv"] = prevalence_table(eras[valid], target[valid], ["≤1959", "1960–1989", "1990–2009", "2010–2019", "2020–2026"])

    source_rows = []
    source_order = EXPECTED_SOURCE_LABELS + [label for label in source_counts["source_label"] if label not in EXPECTED_SOURCE_LABELS]
    for label in source_order:
        mask = frame["資料來源"].replace("", "MISSING").eq(label)
        valid_mask = mask & valid
        n_valid = int(valid_mask.sum())
        row = {
            "source_label": label,
            "all_rows_n": int(mask.sum()),
            "valid_target_n": n_valid,
            "invalid_target_n": int(mask.sum() - n_valid),
            "rating_drop_n": int(target[valid_mask].sum()) if n_valid else 0,
            "rating_drop_prevalence": float(target[valid_mask].mean()) if n_valid else np.nan,
        }
        low, high = wilson_ci(row["rating_drop_n"], n_valid)
        row["ci_low"] = low
        row["ci_high"] = high
        for core in ["sequel_number", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"]:
            row[f"{core}_available_n"] = int((valid_mask & numeric(frame, core).notna()).sum())
            row[f"{core}_availability_rate_valid"] = row[f"{core}_available_n"] / n_valid if n_valid else np.nan
        source_rows.append(row)
    tables["source_robustness.csv"] = pd.DataFrame(source_rows)

    binary_rows = []
    for column in ["導演是否更換", "主演是否更換"]:
        raw = frame[column].replace("", np.nan)
        tab = prevalence_table(raw[valid], target[valid], ["FALSE", "TRUE"])
        tab.insert(0, "x_variable", column)
        tab["analysis_label"] = "RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED"
        binary_rows.append(tab)
    tables["secondary_continuity_binary.csv"] = pd.concat(binary_rows, ignore_index=True)

    shared = numeric(frame, "與前作共同主演數")
    shared_labels = [str(int(value)) if float(value).is_integer() else f"{float(value):g}" for value in sorted(shared[valid].dropna().unique())]
    shared_groups = shared.map(lambda value: np.nan if pd.isna(value) else (str(int(value)) if float(value).is_integer() else f"{float(value):g}"))
    shared_tab = prevalence_table(shared_groups[valid], target[valid], shared_labels)
    shared_tab["analysis_label"] = "RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED"
    tables["secondary_shared_cast_count.csv"] = shared_tab

    genre_raw = frame["類型"].replace("", np.nan)
    genre_rows = []
    for label, count in genre_raw.value_counts(dropna=False).items():
        if pd.isna(label):
            genre_rows.append({"raw_genre_label": "MISSING", "all_rows_n": int(count), "valid_target_n": 0, "drop_n": 0, "drop_prevalence": np.nan, "analysis_label": "RAW_LABEL_ONLY / NO_TOKENIZATION"})
            continue
        mask = genre_raw.eq(label) & valid
        n = int(mask.sum())
        genre_rows.append({"raw_genre_label": label, "all_rows_n": int(count), "valid_target_n": n, "drop_n": int(target[mask].sum()) if n else 0, "drop_prevalence": float(target[mask].mean()) if n else np.nan, "analysis_label": "RAW_LABEL_ONLY / NO_TOKENIZATION"})
    tables["secondary_genre_raw_frequency.csv"] = pd.DataFrame(genre_rows)

    runtime_rows = []
    for column in ["片長(分鐘)", "與前作片長差", "片長變化率"]:
        x, y, missing_n = clean_for_association(frame, column)
        runtime_rows.append({
            "x_variable": column,
            "eligible_n": len(x),
            "missing_x_within_target_population": missing_n,
            "spearman_rho": rank_correlation(x, y),
            **logistic_one_predictor(x, y, LOGISTIC_UNITS[column]),
            "analysis_label": "RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED",
        })
    tables["secondary_runtime_associations.csv"] = pd.DataFrame(runtime_rows)

    dates = pd.to_datetime(frame["上映日期"].replace("", np.nan), errors="coerce")
    tables["secondary_release_date_distribution.csv"] = pd.DataFrame([
        {"metric": "nonmissing_raw", "value": int(frame["上映日期"].ne("").sum()), "note": "Recorded release-date strings"},
        {"metric": "parsed_valid", "value": int(dates.notna().sum()), "note": "Descriptive parse only"},
        {"metric": "invalid_or_missing", "value": int(dates.isna().sum()), "note": "No source modification"},
        {"metric": "minimum_date", "value": dates.min().date().isoformat() if dates.notna().any() else "", "note": "Descriptive"},
        {"metric": "maximum_date", "value": dates.max().date().isoformat() if dates.notna().any() else "", "note": "2026 incomplete-year warning applies"},
    ])

    financial_rows = []
    for column in ["預算", "前作預算", "與前作預算差", "預算變化率", "前作票房"]:
        summary = numeric_summary(numeric(frame, column))
        financial_rows.append({"variable": column, **summary, "analysis_label": "EXPLORATORY_ONLY / PROVENANCE_UNRESOLVED"})
    tables["financial_exploratory.csv"] = pd.DataFrame(financial_rows)

    extreme_rows = []
    for column in ["預算", "前作預算", "與前作預算差", "預算變化率", "前作票房"]:
        values = numeric(frame, column)
        for direction, indices in [("LOWEST", values.nsmallest(10).index), ("HIGHEST", values.nlargest(10).index)]:
            for rank, idx in enumerate(indices, start=1):
                extreme_rows.append({
                    "variable": column, "direction": direction, "rank": rank,
                    "value": values.loc[idx], "電影系列": frame.loc[idx, "電影系列"],
                    "電影名稱": frame.loc[idx, "電影名稱"], "TMDB ID": frame.loc[idx, "TMDB ID"],
                    "IMDb ID": frame.loc[idx, "IMDb ID"], "資料來源": frame.loc[idx, "資料來源"],
                    "analysis_label": "EXPLORATORY_ONLY / PROVENANCE_UNRESOLVED",
                })
    tables["financial_extreme_cases.csv"] = pd.DataFrame(extreme_rows)

    franchise = frame.loc[valid, ["電影系列ID", "rating_drop"]].copy()
    franchise["rating_drop"] = pd.to_numeric(franchise["rating_drop"], errors="coerce")
    franchise_summary = franchise.groupby("電影系列ID", dropna=False)["rating_drop"].agg(["size", "sum", "mean"]).reset_index()
    franchise_summary.columns = ["電影系列ID", "valid_target_n", "drop_n", "drop_prevalence"]
    franchise_summary["analysis_label"] = "GROUPING_STRUCTURE_ONLY / NOT_X"
    tables["secondary_franchise_structure.csv"] = franchise_summary

    post_release_rows = []
    for column in ["人氣", "評分人數"]:
        x, y, missing_n = clean_for_association(frame, column)
        post_release_rows.append({"x_variable": column, "eligible_n": len(x), "missing_x_within_target_population": missing_n, "spearman_rho": rank_correlation(x, y), "analysis_label": "POST_RELEASE_DESCRIPTIVE / EXCLUDED_FROM_PREDICTION"})
    tables["exploratory_post_release_associations.csv"] = pd.DataFrame(post_release_rows)
    return tables


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        Path("/Library/Fonts/Arial Unicode.ttf"),
        Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf"),
        Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf") if bold else Path("/System/Library/Fonts/Supplemental/Arial.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


COLORS = {"navy": "#16324F", "blue": "#2D6CDF", "teal": "#2A9D8F", "orange": "#F4A261", "red": "#D1495B", "gray": "#687386", "light": "#E9EEF5", "ink": "#17212B"}


def canvas(title: str, subtitle: str = "") -> tuple[Image.Image, ImageDraw.ImageDraw]:
    image = Image.new("RGB", (1400, 900), "white")
    draw = ImageDraw.Draw(image)
    draw.text((70, 45), title, fill=COLORS["ink"], font=font(36, True))
    if subtitle:
        draw.text((70, 95), subtitle, fill=COLORS["gray"], font=font(20))
    draw.line((70, 130, 1330, 130), fill=COLORS["light"], width=2)
    return image, draw


def save_bar(path: Path, labels: list[str], values: list[float], title: str, ylabel: str, subtitle: str = "", horizontal: bool = False, ci_low: list[float] | None = None, ci_high: list[float] | None = None, percent: bool = False) -> None:
    image, draw = canvas(title, subtitle)
    left, top, right, bottom = (480 if horizontal else 145), 185, 1320, 790
    draw.line((left, bottom, right, bottom), fill=COLORS["ink"], width=2)
    draw.line((left, top, left, bottom), fill=COLORS["ink"], width=2)
    missing_flags = [not np.isfinite(v) for v in values]
    clean_values = [0.0 if missing else float(value) for value, missing in zip(values, missing_flags)]
    maximum = max(clean_values + ([max([v for v in ci_high if np.isfinite(v)], default=0)] if ci_high else [0]))
    maximum = maximum * 1.15 if maximum > 0 else 1.0
    if horizontal:
        step = (bottom - top) / max(len(labels), 1)
        for i, (label, value, missing) in enumerate(zip(labels, clean_values, missing_flags)):
            y = top + i * step + step * 0.18
            width = (right - left) * value / maximum
            if not missing:
                draw.rectangle((left, y, left + width, y + step * 0.58), fill=COLORS["blue"])
            draw.text((left - 12, y + 3), str(label)[:42], fill=COLORS["ink"], font=font(15), anchor="ra")
            shown = "N/A" if missing else (f"{value:.1%}" if percent else f"{value:,.0f}")
            draw.text((left + width + 8, y + 3), shown, fill=COLORS["ink"], font=font(17))
    else:
        step = (right - left) / max(len(labels), 1)
        bar_width = step * 0.62
        for i, (label, value) in enumerate(zip(labels, clean_values)):
            x = left + i * step + step * 0.19
            height = (bottom - top) * value / maximum
            draw.rectangle((x, bottom - height, x + bar_width, bottom), fill=COLORS["blue"])
            if ci_low is not None and ci_high is not None and np.isfinite(ci_low[i]) and np.isfinite(ci_high[i]):
                low_y = bottom - (bottom - top) * ci_low[i] / maximum
                high_y = bottom - (bottom - top) * ci_high[i] / maximum
                mid_x = x + bar_width / 2
                draw.line((mid_x, low_y, mid_x, high_y), fill=COLORS["ink"], width=3)
                draw.line((mid_x - 7, low_y, mid_x + 7, low_y), fill=COLORS["ink"], width=3)
                draw.line((mid_x - 7, high_y, mid_x + 7, high_y), fill=COLORS["ink"], width=3)
            draw.text((x + bar_width / 2, bottom + 12), str(label), fill=COLORS["ink"], font=font(13 if len(labels) > 7 else 15), anchor="mt")
            shown = f"{value:.1%}" if percent else f"{value:,.0f}"
            draw.text((x + bar_width / 2, bottom - height - 24), shown, fill=COLORS["ink"], font=font(16), anchor="mm")
    draw.text((left, top - 35), ylabel, fill=COLORS["ink"], font=font(18), anchor="la")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=False)


def save_line(path: Path, x: list[float], y: list[float], title: str, xlabel: str, ylabel: str, subtitle: str = "", percent: bool = False) -> None:
    image, draw = canvas(title, subtitle)
    left, top, right, bottom = 120, 175, 1320, 790
    draw.line((left, bottom, right, bottom), fill=COLORS["ink"], width=2)
    draw.line((left, top, left, bottom), fill=COLORS["ink"], width=2)
    if not x or not y:
        draw.text(((left + right) / 2, (top + bottom) / 2), "No estimable data", fill=COLORS["gray"], font=font(28), anchor="mm")
    else:
        xmin, xmax = min(x), max(x)
        ymin, ymax = min(y), max(y)
        if ymin == ymax:
            ymin, ymax = 0, ymax if ymax else 1
        points = []
        for xv, yv in zip(x, y):
            px = left + (xv - xmin) / (xmax - xmin if xmax != xmin else 1) * (right - left)
            py = bottom - (yv - ymin) / (ymax - ymin) * (bottom - top)
            points.append((px, py))
        if len(points) > 1:
            draw.line(points, fill=COLORS["blue"], width=4)
        for point in points:
            draw.ellipse((point[0] - 4, point[1] - 4, point[0] + 4, point[1] + 4), fill=COLORS["red"])
        draw.text((left, bottom + 12), f"{xmin:g}", fill=COLORS["ink"], font=font(16), anchor="la")
        draw.text((right, bottom + 12), f"{xmax:g}", fill=COLORS["ink"], font=font(16), anchor="ra")
        draw.text((left - 10, top), f"{ymax:.1%}" if percent else f"{ymax:,.0f}", fill=COLORS["ink"], font=font(16), anchor="ra")
        draw.text((left - 10, bottom), f"{ymin:.1%}" if percent else f"{ymin:,.0f}", fill=COLORS["ink"], font=font(16), anchor="ra")
    draw.text(((left + right) / 2, 845), xlabel, fill=COLORS["ink"], font=font(20), anchor="mm")
    draw.text((35, (top + bottom) / 2), ylabel, fill=COLORS["ink"], font=font(20), anchor="mm")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=False)


def save_histogram(path: Path, values: np.ndarray, title: str, xlabel: str, subtitle: str = "", threshold: float | None = None, bins: int = 30) -> None:
    values = values[np.isfinite(values)]
    image, draw = canvas(title, subtitle)
    left, top, right, bottom = 120, 175, 1320, 790
    draw.line((left, bottom, right, bottom), fill=COLORS["ink"], width=2)
    draw.line((left, top, left, bottom), fill=COLORS["ink"], width=2)
    if len(values):
        counts, edges = np.histogram(values, bins=bins)
        maximum = max(int(counts.max()), 1)
        step = (right - left) / len(counts)
        for i, count in enumerate(counts):
            height = (bottom - top) * count / maximum
            draw.rectangle((left + i * step, bottom - height, left + (i + 1) * step - 1, bottom), fill=COLORS["blue"])
        if threshold is not None and edges[0] <= threshold <= edges[-1]:
            tx = left + (threshold - edges[0]) / (edges[-1] - edges[0]) * (right - left)
            draw.line((tx, top, tx, bottom), fill=COLORS["red"], width=4)
            draw.text((tx + 8, top + 8), f"Fixed threshold {threshold:g}", fill=COLORS["red"], font=font(18))
        draw.text((left, bottom + 12), f"{edges[0]:.2g}", fill=COLORS["ink"], font=font(16), anchor="la")
        draw.text((right, bottom + 12), f"{edges[-1]:.2g}", fill=COLORS["ink"], font=font(16), anchor="ra")
        draw.text((left - 10, top), f"{maximum:,}", fill=COLORS["ink"], font=font(16), anchor="ra")
    draw.text(((left + right) / 2, 845), xlabel, fill=COLORS["ink"], font=font(20), anchor="mm")
    draw.text((left, top - 35), "Count", fill=COLORS["ink"], font=font(18), anchor="la")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=False)


def save_boxplot(path: Path, grouped_values: OrderedDict[str, np.ndarray], title: str, ylabel: str, subtitle: str = "", threshold: float | None = None, log10_display: bool = False) -> None:
    image, draw = canvas(title, subtitle)
    left, top, right, bottom = 145, 185, 1320, 790
    prepared: list[tuple[str, np.ndarray]] = []
    for label, values in grouped_values.items():
        clean = np.asarray(values, dtype=float)
        clean = clean[np.isfinite(clean)]
        if log10_display:
            clean = clean[clean > 0]
            clean = np.log10(clean)
        prepared.append((label, clean))
    all_values = np.concatenate([values for _, values in prepared if len(values)]) if any(len(values) for _, values in prepared) else np.array([])
    draw.line((left, bottom, right, bottom), fill=COLORS["ink"], width=2)
    draw.line((left, top, left, bottom), fill=COLORS["ink"], width=2)
    if len(all_values):
        ymin, ymax = float(np.min(all_values)), float(np.max(all_values))
        if threshold is not None and not log10_display:
            ymin, ymax = min(ymin, threshold), max(ymax, threshold)
        padding = max((ymax - ymin) * 0.05, 0.05)
        ymin, ymax = ymin - padding, ymax + padding
        def py(value: float) -> float:
            return bottom - (value - ymin) / (ymax - ymin) * (bottom - top)
        if threshold is not None and not log10_display:
            y_threshold = py(threshold)
            draw.line((left, y_threshold, right, y_threshold), fill=COLORS["red"], width=3)
            draw.text((right - 5, y_threshold - 8), f"Fixed threshold {threshold:g}", fill=COLORS["red"], font=font(16), anchor="rd")
        step = (right - left) / max(len(prepared), 1)
        for i, (label, values) in enumerate(prepared):
            center = left + (i + 0.5) * step
            if len(values):
                q05, q25, median, q75, q95 = np.quantile(values, [0.05, 0.25, 0.5, 0.75, 0.95])
                width = step * 0.36
                draw.line((center, py(q05), center, py(q95)), fill=COLORS["ink"], width=3)
                draw.rectangle((center - width, py(q75), center + width, py(q25)), fill=COLORS["light"], outline=COLORS["blue"], width=3)
                draw.line((center - width, py(median), center + width, py(median)), fill=COLORS["red"], width=4)
                draw.line((center - width / 2, py(q05), center + width / 2, py(q05)), fill=COLORS["ink"], width=3)
                draw.line((center - width / 2, py(q95), center + width / 2, py(q95)), fill=COLORS["ink"], width=3)
            draw.text((center, bottom + 14), str(label), fill=COLORS["ink"], font=font(15), anchor="mt")
            draw.text((center, bottom + 36), f"n={len(values):,}", fill=COLORS["gray"], font=font(14), anchor="mt")
        draw.text((left - 12, top), f"{ymax:.2g}", fill=COLORS["ink"], font=font(15), anchor="ra")
        draw.text((left - 12, bottom), f"{ymin:.2g}", fill=COLORS["ink"], font=font(15), anchor="ra")
    draw.text((left, top - 35), ylabel, fill=COLORS["ink"], font=font(18), anchor="la")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=False)


def save_core_grid(path: Path, frame: pd.DataFrame) -> None:
    image, draw = canvas("Core feature distributions", "Raw stored values; no feature transformation or imputation")
    positions = [(60, 165), (500, 165), (940, 165), (60, 500), (500, 500), (940, 500)]
    items = [
        ("sequel_number", numeric(frame, "sequel_number")),
        ("previous_rating", numeric(frame, "previous_rating")),
        ("previous_rating_votes", numeric(frame, "previous_rating_votes")),
        ("years_since_previous", numeric(frame, "years_since_previous")),
        ("previous_runtime", numeric(frame, "previous_runtime")),
        ("rating_change", numeric(frame, "與前作評分差")),
    ]
    for (x0, y0), (label, values) in zip(positions, items):
        clean = values.dropna().to_numpy(dtype=float)
        if label == "previous_rating_votes":
            clean = clean[clean > 0]
            display = np.log10(clean) if len(clean) else clean
            axis_note = "log10 axis display"
        else:
            display = clean
            axis_note = "raw axis"
        draw.text((x0, y0), label, fill=COLORS["ink"], font=font(20, True))
        draw.text((x0, y0 + 27), f"n={len(clean):,}; {axis_note}", fill=COLORS["gray"], font=font(14))
        if len(display):
            counts, _ = np.histogram(display, bins=20)
            max_count = max(int(counts.max()), 1)
            width, height = 360, 220
            for i, count in enumerate(counts):
                bar_h = height * count / max_count
                step = width / len(counts)
                draw.rectangle((x0 + i * step, y0 + 280 - bar_h, x0 + (i + 1) * step - 1, y0 + 280), fill=COLORS["teal"])
            draw.line((x0, y0 + 280, x0 + width, y0 + 280), fill=COLORS["ink"], width=1)
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path, format="PNG", optimize=False)


def build_figures(frame: pd.DataFrame, tables: dict[str, pd.DataFrame], directory: Path) -> list[Path]:
    directory.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    def target_path(name: str) -> Path:
        path = directory / name
        paths.append(path)
        return path

    years = tables["release_year_distribution.csv"].dropna(subset=["release_year"])
    save_line(target_path("01_release_year_distribution.png"), years["release_year"].astype(float).tolist(), years["n"].astype(float).tolist(), "Release year distribution", "Release year", "Films", "All 6,481 rows; 2026 is an incomplete year")
    decades = tables["decade_distribution.csv"]
    save_bar(target_path("02_decade_distribution.png"), decades["decade_start"].astype(str).tolist(), decades["n"].astype(float).tolist(), "Release decade distribution", "Films", "All rows; counts use recorded release year")
    sources = tables["source_distribution.csv"]
    save_bar(target_path("03_source_distribution.png"), sources["source_label"].astype(str).tolist(), sources["n"].astype(float).tolist(), "Recorded data-source distribution", "Rows", "Exact source labels retained", horizontal=True)
    miss = tables["missingness.csv"].sort_values("missing_rate", ascending=False).head(15)
    save_bar(target_path("04_missingness_overview.png"), miss["column"].astype(str).tolist(), miss["missing_rate"].astype(float).tolist(), "Highest missingness fields", "Missing rate", "Top 15 fields; missing is not zero", horizontal=True, percent=True)
    valid = bool_valid(frame)
    target = pd.to_numeric(frame["rating_drop"].replace("", np.nan), errors="coerce")
    rating_change = numeric(frame, "與前作評分差")[valid].dropna().to_numpy(dtype=float)
    save_histogram(target_path("05_rating_change_distribution.png"), rating_change, "Recorded rating-change distribution", "Current rating − predecessor rating", f"Target-valid n={len(rating_change):,}; fixed threshold −0.2", threshold=-0.2, bins=40)
    target_table = tables["target_distribution.csv"].iloc[:2]
    save_bar(target_path("06_rating_drop_distribution.png"), ["Drop", "Non-drop"], target_table["n"].astype(float).tolist(), "Formal rating-drop target", "Pairs", f"Valid target population n={int(target_table['n'].sum()):,}; threshold fixed at ≤−0.2")
    sequel_counts = numeric(frame, "sequel_number").value_counts().sort_index()
    save_bar(target_path("07_sequel_number_distribution.png"), [str(int(x)) for x in sequel_counts.index], sequel_counts.astype(float).tolist(), "Sequel-number distribution", "Rows", "Exact recorded sequel number; no regrouping in source data")
    save_core_grid(target_path("08_core_feature_distributions.png"), frame)

    group_chart = tables["core_sequel_group.csv"].query("group != 'OTHER'")
    save_bar(target_path("09_sequel_group_drop_prevalence.png"), group_chart["group"].tolist(), group_chart["drop_prevalence"].astype(float).tolist(), "Rating-drop prevalence by sequel group", "Drop prevalence", "Wilson 95% intervals; unadjusted association", ci_low=group_chart["ci_low"].astype(float).tolist(), ci_high=group_chart["ci_high"].astype(float).tolist(), percent=True)
    for number, (column, title) in enumerate([
        ("previous_rating", "Predecessor rating and rating-drop prevalence"),
        ("previous_rating_votes", "Predecessor rating votes and rating-drop prevalence"),
        ("years_since_previous", "Time since predecessor and rating-drop prevalence"),
        ("previous_runtime", "Predecessor runtime and rating-drop prevalence"),
    ], start=10):
        tab = tables[f"core_{column}_bands.csv"]
        subtitle = "Fixed descriptive bands; no outcome-optimized cutoff"
        if column == "previous_rating_votes":
            subtitle += "; labels reflect raw vote counts"
        save_bar(target_path(f"{number:02d}_{column}_association.png"), tab["group"].tolist(), tab["drop_prevalence"].astype(float).tolist(), title, "Drop prevalence", subtitle, ci_low=tab["ci_low"].astype(float).tolist(), ci_high=tab["ci_high"].astype(float).tolist(), percent=True)

    temporal = tables["temporal_robustness.csv"]
    save_bar(target_path("14_temporal_robustness.png"), temporal["group"].tolist(), temporal["drop_prevalence"].astype(float).tolist(), "Rating-drop prevalence by release era", "Drop prevalence", "Descriptive temporal robustness; year is not a causal exposure", ci_low=temporal["ci_low"].astype(float).tolist(), ci_high=temporal["ci_high"].astype(float).tolist(), percent=True)
    source = tables["source_robustness.csv"]
    save_bar(target_path("15_source_robustness.png"), source["source_label"].tolist(), source["rating_drop_prevalence"].astype(float).tolist(), "Rating-drop prevalence by recorded source", "Drop prevalence", "Exact source labels; differences are descriptive, not source effects", horizontal=True, percent=True)
    continuity = tables["secondary_continuity_binary.csv"].copy()
    continuity["label"] = continuity["x_variable"] + "=" + continuity["group"]
    save_bar(target_path("16_continuity_retrospective.png"), continuity["label"].tolist(), continuity["drop_prevalence"].astype(float).tolist(), "Continuity fields and rating-drop prevalence", "Drop prevalence", "RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED", ci_low=continuity["ci_low"].astype(float).tolist(), ci_high=continuity["ci_high"].astype(float).tolist(), percent=True)
    sequel_groups = sequel_group(numeric(frame, "sequel_number"))
    rating_change_series = numeric(frame, "與前作評分差")
    grouped_change = OrderedDict((label, rating_change_series[valid & sequel_groups.eq(label)].dropna().to_numpy(dtype=float)) for label in ["2", "3", "4", "5+"])
    save_boxplot(target_path("17_rating_change_by_sequel_group.png"), grouped_change, "Rating change by sequel group", "Recorded rating change", "5th–95th whiskers; boxes show IQR; fixed target boundary", threshold=-0.2)
    previous_rating = numeric(frame, "previous_rating")
    grouped_rating = OrderedDict([
        ("Non-drop", previous_rating[valid & target.eq(0)].dropna().to_numpy(dtype=float)),
        ("Drop", previous_rating[valid & target.eq(1)].dropna().to_numpy(dtype=float)),
    ])
    save_boxplot(target_path("18_previous_rating_by_target.png"), grouped_rating, "Predecessor rating by target class", "Previous rating", "UNADJUSTED ASSOCIATION; mathematical coupling and regression-to-the-mean risk")
    previous_votes = numeric(frame, "previous_rating_votes")
    grouped_votes = OrderedDict([
        ("Non-drop", previous_votes[valid & target.eq(0)].dropna().to_numpy(dtype=float)),
        ("Drop", previous_votes[valid & target.eq(1)].dropna().to_numpy(dtype=float)),
    ])
    save_boxplot(target_path("19_previous_rating_votes_by_target.png"), grouped_votes, "Predecessor rating votes by target class", "log10(previous rating votes)", "Display axis only; stored values are unchanged", log10_display=True)
    return paths


def write_tables(tables: dict[str, pd.DataFrame], directory: Path) -> list[Path]:
    directory.mkdir(parents=True, exist_ok=True)
    paths = []
    for filename, table in sorted(tables.items()):
        path = directory / filename
        table.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", float_format="%.10g")
        paths.append(path)
    return paths


def fmt_pct(value: float) -> str:
    return "NA" if not np.isfinite(value) else f"{value:.1%}"


def fmt_num(value: float, digits: int = 3) -> str:
    return "NA" if not np.isfinite(value) else f"{value:.{digits}f}"


def report_text(frame: pd.DataFrame, tables: dict[str, pd.DataFrame], gate: dict, warnings: list[str]) -> str:
    target_table = tables["target_distribution.csv"]
    drop = target_table.iloc[0]
    nondrop = target_table.iloc[1]
    numeric_table = tables["numeric_distributions.csv"].set_index("analysis_variable")
    assoc = tables["core_numeric_associations.csv"].set_index("x_variable")
    sequel = tables["core_sequel_group.csv"].set_index("group")
    temporal = tables["temporal_robustness.csv"].set_index("group")
    source = tables["source_robustness.csv"].sort_values("rating_drop_prevalence", ascending=False)
    continuity = tables["secondary_continuity_binary.csv"]
    finance = tables["financial_exploratory.csv"].set_index("variable")
    population = tables["population_comparison.csv"].set_index(["variable", "population"])
    shared_cast = tables["secondary_shared_cast_count.csv"].set_index("group")
    valid_n = int(drop["n"] + nondrop["n"])
    invalid_n = len(frame) - valid_n

    sequel_lines = []
    for group in ["2", "3", "4", "5+"]:
        row = sequel.loc[group]
        comparison = "reference" if group == "2" else f"OR {fmt_num(float(row['odds_ratio_vs_reference']), 2)} ({fmt_num(float(row['odds_ratio_ci_low']), 2)}–{fmt_num(float(row['odds_ratio_ci_high']), 2)})"
        sequel_lines.append(f"| {group} | {int(row['n']):,} | {fmt_pct(float(row['drop_prevalence']))} | {fmt_pct(float(row['prevalence_difference_vs_reference'])) if group != '2' else 'reference'} | {comparison} |")

    assoc_lines = []
    for variable in ["previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"]:
        row = assoc.loc[variable]
        coupling = "Mathematical coupling / regression-to-the-mean" if variable == "previous_rating" else "Unadjusted; descriptive"
        assoc_lines.append(f"| `{variable}` | {int(row['eligible_n']):,} | {fmt_num(float(row['spearman_rho']))} | {fmt_num(float(row['odds_ratio']), 3)} | {fmt_num(float(row['odds_ratio_ci_low']), 3)}–{fmt_num(float(row['odds_ratio_ci_high']), 3)} | {float(row['logistic_unit']):g} | {coupling} |")

    source_lines = []
    for _, row in source.iterrows():
        source_lines.append(f"| {row['source_label']} | {int(row['all_rows_n']):,} | {int(row['valid_target_n']):,} | {fmt_pct(float(row['rating_drop_prevalence']))} |")

    warning_lines = "\n".join(f"- {item}" for item in warnings)
    core_missing = "\n".join(
        f"- `{name}`: n={int(numeric_table.loc[name, 'n']):,}; missing={int(numeric_table.loc[name, 'missing_count']):,} ({fmt_pct(float(numeric_table.loc[name, 'missing_rate']))})."
        for name in ["rating_change", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime", "sequel_number"]
    )

    return f"""# Movie Sequel Association EDA v1

## Executive Summary

- **DATASET DESCRIPTION:** The immutable input contains {len(frame):,} sequel-pair rows and {len(frame.columns)} columns. The formal binary outcome is available for {valid_n:,} pairs; {invalid_n:,} rows remain retained but outside target analyses.
- **DATASET DESCRIPTION:** Within the valid target population, {int(drop['n']):,} pairs meet the fixed `rating_drop` definition and {int(nondrop['n']):,} do not. Drop prevalence is **{fmt_pct(float(drop['proportion_valid']))}** (Wilson 95% CI {fmt_pct(float(drop['ci_low']))}–{fmt_pct(float(drop['ci_high']))}).
- **UNADJUSTED ASSOCIATION:** Core relationships are descriptive and unadjusted. They do not establish causality or out-of-sample predictive performance.
- **PREDICTIVE-RELEVANCE CANDIDATE:** The five core Tier 1 variables can proceed to researcher review, but EDA alone does not select them. `previous_rating` needs special treatment because it is mathematically coupled to the change-based target.

## 1. Research Questions

- **RQ1:** Which factors are associated with a sequel receiving a lower rating than its predecessor?
- **RQ2:** Which historical variables merit later evaluation as pre-release predictors of rating decline?

This report separates dataset description, unadjusted association, and predictive-relevance review. It does not perform feature selection, preprocessing, splitting, or ML.

## 2. Data and Population

- Input: `{INPUT}`
- Input SHA256: `{gate['input_sha256']}`
- Shape: {len(frame):,} × {len(frame.columns)}
- Binary-target population: `rating_valid = TRUE` and `rating_drop` nonmissing.
- Target threshold: recorded `與前作評分差 <= -0.2`; unchanged and not optimized.
- All-row population: {len(frame):,}.
- Valid target population: {valid_n:,}.
- Invalid/missing target rows retained: {invalid_n:,}.
- TMDB ID coverage: {gate['input_rows'] - gate['tmdb_missing']:,}/{gate['input_rows']:,}; duplicates: {gate['tmdb_duplicates']}.
- IMDb ID coverage: {gate['imdb_nonempty']:,}/{gate['input_rows']:,}; nonempty duplicates: {gate['imdb_duplicates']}.
- Release year maximum is 2026; **2026 is an incomplete year and must not be interpreted as a complete annual cohort.**

## 3. Dataset Distribution

Core field availability:

{core_missing}

Population-comparison tables retain separate denominators for all rows and target-valid rows. Differences are population description only; this report does not label them selection bias.

The all-row population includes recorded part-1 rows (`sequel_number` minimum {fmt_num(float(population.loc[('sequel_number', 'ALL_ROWS'), 'min']), 0)}), whereas the valid target population begins at part {fmt_num(float(population.loc[('sequel_number', 'VALID_TARGET'), 'min']), 0)} because a predecessor rating is required. Median sequel number is {fmt_num(float(population.loc[('sequel_number', 'ALL_ROWS'), 'median']), 0)} in all rows and {fmt_num(float(population.loc[('sequel_number', 'VALID_TARGET'), 'median']), 0)} in the valid target population. This is a structural population difference, not by itself evidence of selection bias.

Exact `資料來源` labels were retained without consolidation. Detailed year, decade, source, missingness, numeric-distribution, and population-comparison results are in `reports/tables/movie_sequel_eda_v1/`.

## 4. Target Distribution

| Target status | n | Share of valid target population |
|---|---:|---:|
| `rating_drop = 1` | {int(drop['n']):,} | {fmt_pct(float(drop['proportion_valid']))} |
| `rating_drop = 0` | {int(nondrop['n']):,} | {fmt_pct(float(nondrop['proportion_valid']))} |
| Invalid/missing | {invalid_n:,} | Not in target denominator |

The continuous outcome description uses the recorded `與前作評分差` only for rating-valid pairs. The histogram marks the fixed −0.2 threshold. No alternate threshold was searched.

## 5. Core Association Results

### 5.1 Sequel number

**UNADJUSTED ASSOCIATION.** The prespecified groups were retained exactly.

| Sequel group | Eligible n | Drop prevalence | Difference vs part 2 | Odds ratio vs part 2 (95% CI) |
|---|---:|---:|---:|---|
{chr(10).join(sequel_lines)}

These estimates may reflect franchise survival, era, and within-franchise dependence. They do not show that sequel stage causes rating decline.

### 5.2 Continuous Tier 1 variables

| Variable | Eligible n | Spearman rho | OR per stated unit | 95% CI | Unit | Interpretation warning |
|---|---:|---:|---:|---|---:|---|
{chr(10).join(assoc_lines)}

Odds ratios are from separate one-predictor, unadjusted logistic models. Units are 1 rating point, 10,000 votes, 1 year, and 10 runtime minutes, respectively. Rescaling is only for coefficient interpretation; stored values were unchanged.

`previous_rating` is a predecessor/baseline measure mathematically embedded in `current rating − previous rating`. Its association may reflect mathematical coupling and regression-to-the-mean. A predictive association is not a causal effect.

## 6. Temporal / Source Robustness

`release_year` remains a **TEMPORAL_CONTROL_CANDIDATE**. Era differences may represent rating-system, market, franchise, source, or industry composition.

| Era | Eligible n | Drop prevalence |
|---|---:|---:|
{chr(10).join(f'| {idx} | {int(row["n"]):,} | {fmt_pct(float(row["drop_prevalence"]))} |' for idx, row in temporal.iterrows())}

Source composition:

| Exact source label | All rows | Valid target n | Drop prevalence |
|---|---:|---:|---:|
{chr(10).join(source_lines)}

Source differences are descriptive. They are not evidence of source bias or a causal source effect.

## 7. Secondary Retrospective Results

The director-change, lead-cast-change, shared-cast-count, current-runtime, raw-genre, release-date, and franchise-structure analyses are labeled **RETROSPECTIVE / PROVENANCE_REVIEW_REQUIRED**.

| Recorded continuity field | Group | Eligible n | Drop prevalence |
|---|---|---:|---:|
{chr(10).join(f'| {row["x_variable"]} | {row["group"]} | {int(row["n"]):,} | {fmt_pct(float(row["drop_prevalence"]))} |' for _, row in continuity.iterrows())}

For recorded shared lead-cast count, observed drop prevalence ranges from {fmt_pct(float(shared_cast['drop_prevalence'].min()))} to {fmt_pct(float(shared_cast['drop_prevalence'].max()))} across the available exact counts. This remains retrospective and does not prove T−1 availability or an independent association.

- Continuity analyses use the recorded flags/count only; no names were rematched.
- Genre analysis uses exact raw `、`-delimited strings. No tokenization, count feature, one-hot, or multi-hot encoding occurred.
- Current runtime and its recorded difference/rate remain temporally unresolved at T−1. The known 39-row small-denominator warning for runtime rate remains; no row was removed or altered.
- `電影系列ID` was used only to describe clustering structure and remains excluded as X.

## 8. Financial Exploratory Results

Financial fields remain **EXPLORATORY_ONLY / PROVENANCE_UNRESOLVED**.

| Variable | Available n | Missing rate | Median | Q1 | Q3 | Minimum | Maximum |
|---|---:|---:|---:|---:|---:|---:|---:|
{chr(10).join(f'| {name} | {int(row["n"]):,} | {fmt_pct(float(row["missing_rate"]))} | {fmt_num(float(row["median"]), 2)} | {fmt_num(float(row["q1"]), 2)} | {fmt_num(float(row["q3"]), 2)} | {fmt_num(float(row["min"]), 2)} | {fmt_num(float(row["max"]), 2)} |' for name, row in finance.iterrows())}

Currency, unit, geography, gross definition, snapshot timing, and row-level provenance remain unresolved. No currency conversion, inflation adjustment, log transformation, winsorization, capping, imputation, or outlier deletion was performed. Financial associations do not promote these variables to formal predictors.

## 9. Main Findings

1. **DATASET DESCRIPTION:** The fixed binary target is available for {valid_n:,} of {len(frame):,} rows; missing-target rows remain part of the source population but not the target denominator.
2. **DATASET DESCRIPTION:** Rating-drop prevalence under the approved ≤−0.2 rule is {fmt_pct(float(drop['proportion_valid']))} among valid pairs.
3. **UNADJUSTED ASSOCIATION:** Prespecified sequel groups show different observed drop prevalences; interpretation must account for era, franchise survival, and repeated franchise observations.
4. **UNADJUSTED ASSOCIATION:** `previous_rating` shows a change-outcome relationship that is structurally vulnerable to mathematical coupling and regression-to-the-mean.
5. **DATASET DESCRIPTION:** Source/era composition is material: one recorded source group has no valid target pairs, while observed prevalence differs across other source and era groups. These differences are descriptive and require design review, not a source-effect interpretation.

## 10. Limitations

{warning_lines}

No inferential p-values are reported. Therefore there is no multiple-comparison p-value family or post-hoc significance selection in this execution. Effect sizes and 95% intervals are descriptive and unadjusted.

## 11. Variables Worth Researcher Review

- Tier 1 candidates: `sequel_number`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, and `previous_runtime`.
- Temporal control candidate: `release_year`.
- Provenance/temporal review: recorded director/cast continuity and current-runtime measures.
- Representation review: raw genre labels require a separate tokenization policy before use.
- Financial fields remain exploratory until provenance is resolved.

“Worth review” is not feature selection. Advancement still requires T−1 eligibility, leakage, provenance, missing-data, redundancy, and validation review.

## 12. What EDA Does NOT Establish

This EDA does not establish causality, independent effects, temporal availability at T−1, out-of-sample prediction, calibrated risk estimates, a final feature set, or model performance. It does not modify the target, source data, pairing, or threshold. It performs no imputation, encoding, scaling, train/test split, Logistic Regression model development, Random Forest, XGBoost, SHAP, or threshold optimization.

**STATUS = EDA_COMPLETE_WITH_WARNINGS**
"""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true", help="Run input gate without writing outputs")
    args = parser.parse_args()

    input_metadata_before = INPUT.stat()
    frame, gate = load_and_gate()
    if args.verify_only:
        print(json.dumps(gate, ensure_ascii=False, indent=2))
        return 0

    warnings = [
        "2026 is an incomplete year; annual results are cumulative rather than a full-year cohort.",
        "`previous_rating` is mathematically coupled to the change-based Y and may reflect regression-to-the-mean.",
        "All associations are unadjusted and may reflect era, source composition, franchise survival, or within-franchise dependence.",
        "Core-feature missingness uses pairwise eligible populations; no imputation or global listwise deletion occurred.",
        "Director/cast continuity and current-runtime analyses are retrospective and require T−1 provenance review.",
        "Financial metrics have unresolved currency, geography, definition, snapshot, and row-level provenance.",
        "Raw genre labels were not tokenized; exact label combinations are descriptive only.",
        "No p-values were used for selection; no multiple-comparison correction was required in this effect-size-first execution.",
    ]

    tables = build_tables(frame)
    zero_valid_sources = tables["source_robustness.csv"].loc[
        tables["source_robustness.csv"]["valid_target_n"].eq(0), "source_label"
    ].tolist()
    if zero_valid_sources:
        warnings.append(
            "Recorded source group(s) with zero valid target pairs: "
            + ", ".join(zero_valid_sources)
            + ". Their rating-drop prevalence is NOT ESTIMABLE, not 0%."
        )
    with tempfile.TemporaryDirectory(prefix="movie_sequel_eda_v1_", dir=str(ROOT)) as temp_name:
        temp_root = Path(temp_name)
        run_dirs = [temp_root / "run1", temp_root / "run2"]
        run_hashes = []
        figure_hashes = []
        for run_dir in run_dirs:
            table_paths = write_tables(tables, run_dir / "tables")
            figure_paths = build_figures(frame, tables, run_dir / "figures")
            run_hashes.append(tree_hash(table_paths, run_dir / "tables"))
            figure_hashes.append(tree_hash(figure_paths, run_dir / "figures"))
        if run_hashes[0] != run_hashes[1] or figure_hashes[0] != figure_hashes[1]:
            raise SystemExit("CRITICAL FAIL: deterministic rerun mismatch")

        if TABLE_DIR.exists():
            shutil.rmtree(TABLE_DIR)
        if FIGURE_DIR.exists():
            shutil.rmtree(FIGURE_DIR)
        shutil.copytree(run_dirs[0] / "tables", TABLE_DIR)
        shutil.copytree(run_dirs[0] / "figures", FIGURE_DIR)

    table_paths = sorted(TABLE_DIR.glob("*.csv"))
    figure_paths = sorted(FIGURE_DIR.glob("*.png"))
    REPORT.write_text(report_text(frame, tables, gate, warnings), encoding="utf-8")

    input_sha_after = sha256(INPUT)
    input_metadata_after = INPUT.stat()
    immutable = input_sha_after == EXPECTED_SHA and (
        input_metadata_before.st_size == input_metadata_after.st_size
        and input_metadata_before.st_mtime_ns == input_metadata_after.st_mtime_ns
        and input_metadata_before.st_ino == input_metadata_after.st_ino
    )
    if not immutable:
        raise SystemExit("CRITICAL FAIL: input immutability check failed")

    valid = bool_valid(frame)
    target = pd.to_numeric(frame["rating_drop"].replace("", np.nan), errors="coerce")
    manifest = {
        "status": "EDA_COMPLETE_WITH_WARNINGS",
        "execution_timestamp": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "input_path": str(INPUT),
        "input_sha256_before": gate["input_sha256"],
        "input_sha256_after": input_sha_after,
        "input_shape": [int(frame.shape[0]), int(frame.shape[1])],
        "input_gate": gate,
        "input_immutable": immutable,
        "specification_path": str(SPEC),
        "specification_sha256": sha256(SPEC),
        "analysis_plan_path": str(PLAN),
        "analysis_plan_sha256": sha256(PLAN),
        "script_path": str(Path(__file__)),
        "script_sha256": sha256(Path(__file__)),
        "report_path": str(REPORT),
        "report_sha256": sha256(REPORT),
        "output_files": [str(REPORT), str(MANIFEST)] + [str(path) for path in table_paths + figure_paths],
        "table_files": [{"path": str(path), "sha256": sha256(path)} for path in table_paths],
        "figure_files": [{"path": str(path), "sha256": sha256(path)} for path in figure_paths],
        "table_count": len(table_paths),
        "figure_count": len(figure_paths),
        "analysis_population_counts": {
            "all_rows": int(len(frame)),
            "valid_target": int(valid.sum()),
            "invalid_or_missing_target": int((~valid).sum()),
            "rating_drop_1": int(target[valid].sum()),
            "rating_drop_0": int(valid.sum() - target[valid].sum()),
        },
        "determinism": {
            "table_tree_sha256_run1": run_hashes[0],
            "table_tree_sha256_run2": run_hashes[1],
            "figure_tree_sha256_run1": figure_hashes[0],
            "figure_tree_sha256_run2": figure_hashes[1],
            "result": "PASS",
        },
        "methods": {
            "proportion_ci": "Wilson 95%",
            "odds_ratio_ci": "Wald interval on log odds ratio; zero-cell estimates marked UNSTABLE",
            "numeric_association": "Spearman rank correlation and separate unadjusted one-predictor logistic model",
            "p_values": "Not reported; no significance-driven feature selection",
            "missingness": "Pairwise eligible observations; no imputation",
        },
        "warnings": warnings,
        "specification_deviations": [],
        "prohibited_actions_confirmed_absent": {
            "source_modification": True,
            "target_redefinition": True,
            "global_listwise_deletion": True,
            "imputation": True,
            "encoding_for_ml": True,
            "feature_selection": True,
            "train_test_split": True,
            "machine_learning": True,
            "external_api_or_enrichment": True,
            "fuzzy_matching_or_pair_reconstruction": True,
        },
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": manifest["status"],
        "input_sha256": gate["input_sha256"],
        "input_shape": manifest["input_shape"],
        "analysis_population_counts": manifest["analysis_population_counts"],
        "table_count": len(table_paths),
        "figure_count": len(figure_paths),
        "determinism": manifest["determinism"],
        "input_immutable": immutable,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
