#!/usr/bin/env python3
"""Build the controlled Movie Sequel Feature Engineering v1 dataset.

Scope: preserve 44 input columns and append six approved, value-preserving
feature aliases. No joins, matching, imputation, encoding, EDA, or ML.
"""

from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import tempfile
from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_analysis_v1.csv"
OUTPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
SPEC = ROOT / "reports/movie_sequel_feature_engineering_spec_v1.2.md"
REGISTRY = ROOT / "reports/movie_sequel_feature_registry_v1.2.csv"
QA_REPORT = ROOT / "reports/movie_sequel_feature_engineering_qa_v1.md"
MANIFEST = ROOT / "reports/movie_sequel_feature_engineering_manifest_v1.json"
EXPECTED_INPUT_SHA = "d4e3ecf47eed76da1247e0daa4e136af14359b8b7e11d2884b46debcfd8e09b7"
EXPECTED_ROWS = 6481
EXPECTED_INPUT_COLUMNS = 44
FEATURE_MAP = [
    ("sequel_number", "第幾部"),
    ("release_year", "上映年"),
    ("previous_rating", "前作評分"),
    ("previous_rating_votes", "前作評分人數"),
    ("years_since_previous", "與前作上映間隔(年)"),
    ("previous_runtime", "前作片長"),
]
FEATURE_COLUMNS = [feature for feature, _ in FEATURE_MAP]
LEAKAGE_COLUMNS = {
    "平均評分", "評分人數", "與前作評分差", "口碑是否下滑", "評分樣本是否足夠",
    "人氣", "票房", "與前作票房差", "票房變化率", "rating_valid", "rating_drop",
}
CONTINUITY_COLUMNS = {"導演是否更換", "主演是否更換", "與前作共同主演數"}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def metadata(path: Path) -> dict:
    stat = path.stat()
    return {"size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns, "inode": stat.st_ino}


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        columns = list(reader.fieldnames or [])
        rows = [{key: (value if value is not None else "") for key, value in row.items()} for row in reader]
    return columns, rows


def write_csv(path: Path, columns: list[str], rows: list[dict[str, str]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, lineterminator="\n", extrasaction="raise")
        writer.writeheader()
        writer.writerows(rows)


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
    except InvalidOperation:
        return None
    return number if number.is_finite() else None


def target_logic_mismatches(rows: list[dict[str, str]]) -> list[int]:
    mismatches = []
    for position, row in enumerate(rows, start=2):
        current = decimal_or_none(row["平均評分"])
        previous = decimal_or_none(row["前作評分"])
        change = decimal_or_none(row["與前作評分差"])
        valid = bool(current is not None and previous is not None and change is not None and current > 0 and previous > 0)
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            mismatches.append(position)
    return mismatches


def transform(columns: list[str], rows: list[dict[str, str]]) -> tuple[list[str], list[dict[str, str]]]:
    output_columns = columns + FEATURE_COLUMNS
    output_rows = []
    for source in rows:
        target = {column: source[column] for column in columns}
        for feature, source_field in FEATURE_MAP:
            target[feature] = source[source_field]
        output_rows.append(target)
    return output_columns, output_rows


def main() -> int:
    timestamp = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    input_sha_before = sha256(INPUT)
    input_metadata_before = metadata(INPUT)
    if input_sha_before != EXPECTED_INPUT_SHA:
        raise SystemExit("CRITICAL GATE FAIL: input SHA256 mismatch; no output was written.")

    input_columns, input_rows = read_csv(INPUT)
    registry_columns, registry_rows = read_csv(REGISTRY)
    if len(input_rows) != EXPECTED_ROWS or len(input_columns) != EXPECTED_INPUT_COLUMNS:
        raise SystemExit("CRITICAL GATE FAIL: input shape is not 6481 x 44; no output was written.")
    registry_existing = [row for row in registry_rows if row["feature_status"] not in {"IMPLEMENTED", "PROPOSED"}]
    registry_implemented = [row for row in registry_rows if row["feature_status"] == "IMPLEMENTED"]
    registry_proposed = [row for row in registry_rows if row["feature_status"] == "PROPOSED"]
    if [row["field_name"] for row in registry_existing] != input_columns:
        raise SystemExit("CRITICAL GATE FAIL: v1.2 registry does not match input schema; no output was written.")
    registry_map = [(row["field_name"], row["source_field"]) for row in registry_implemented]
    if registry_map != FEATURE_MAP or len(registry_proposed) != 8:
        raise SystemExit("CRITICAL GATE FAIL: implemented/proposed registry scope mismatch; no output was written.")

    tests: list[dict[str, str]] = []

    def check(test_id: str, objective: str, condition: bool, actual: object, expected: str, severity: str = "CRITICAL", warning: bool = False, message: str = "") -> None:
        tests.append({
            "test_id": test_id,
            "objective": objective,
            "severity": severity,
            "actual": str(actual),
            "expected": expected,
            "status": "WARN" if warning else ("PASS" if condition else "FAIL"),
            "message": message or ("符合規格。" if condition else "Blocking requirement not met."),
        })

    tmdb = [row["TMDB ID"] for row in input_rows]
    imdb = [row["IMDb ID"] for row in input_rows if row["IMDb ID"]]
    target_bad = target_logic_mismatches(input_rows)
    check("FE-001", "Input SHA256 gate", input_sha_before == EXPECTED_INPUT_SHA, input_sha_before, EXPECTED_INPUT_SHA)
    check("FE-002", "Input row count", len(input_rows) == 6481, len(input_rows), "6481")
    check("FE-003", "Input column count", len(input_columns) == 44, len(input_columns), "44")
    check("FE-004", "Input schema and order", [row["field_name"] for row in registry_existing] == input_columns, "ordered match", "ordered match")
    check("FE-005", "TMDB identity integrity", all(tmdb) and len(tmdb) == len(set(tmdb)), f"missing={sum(not value for value in tmdb)}, duplicate_affected={len(tmdb)-len(set(tmdb))}", "missing=0, duplicate_affected=0")
    check("FE-006", "IMDb nonempty uniqueness", len(imdb) == len(set(imdb)), f"nonempty={len(imdb)}, duplicate_affected={len(imdb)-len(set(imdb))}", "duplicate_affected=0")
    check("FE-007", "Formal target logic isolation", not target_bad, f"mismatches={len(target_bad)}", "mismatches=0")
    check("FE-008", "Approved implemented mapping", registry_map == FEATURE_MAP, registry_map, str(FEATURE_MAP))
    check("FE-009", "Continuity fields not prematurely implemented", not (set(FEATURE_COLUMNS) & CONTINUITY_COLUMNS) and all(row["tier"] == "REQUIRES_REVIEW" for row in registry_existing if row["field_name"] in CONTINUITY_COLUMNS), f"implemented={FEATURE_COLUMNS}", "no continuity feature implemented")
    check("FE-010", "Proposed features not implemented", not (set(FEATURE_COLUMNS) & {row["field_name"] for row in registry_proposed}), f"proposed_count={len(registry_proposed)}", "intersection=empty")
    check("FE-011", "Leakage fields excluded from engineered X", not (set(FEATURE_COLUMNS) & LEAKAGE_COLUMNS), sorted(set(FEATURE_COLUMNS) & LEAKAGE_COLUMNS), "empty")

    with tempfile.TemporaryDirectory(prefix="movie_sequel_features_v1_", dir=str(ROOT)) as temporary:
        temp_paths = [Path(temporary) / "run_1.csv", Path(temporary) / "run_2.csv"]
        transformed = []
        for temp_path in temp_paths:
            fresh_columns, fresh_rows = read_csv(INPUT)
            out_columns, out_rows = transform(fresh_columns, fresh_rows)
            write_csv(temp_path, out_columns, out_rows)
            transformed.append((out_columns, out_rows))

        output_columns, output_rows = transformed[0]
        second_columns, second_rows = transformed[1]
        hashes = [sha256(path) for path in temp_paths]
        raw_equal = all(source[column] == target[column] for source, target in zip(input_rows, output_rows) for column in input_columns)
        raw_na_equal = all((source[column] == "") == (target[column] == "") for source, target in zip(input_rows, output_rows) for column in input_columns)
        feature_equal = {
            feature: all(row[feature] == row[source] for row in output_rows)
            for feature, source in FEATURE_MAP
        }
        feature_na_equal = {
            feature: all((row[feature] == "") == (row[source] == "") for row in output_rows)
            for feature, source in FEATURE_MAP
        }

        check("FE-012", "Output row conservation", len(output_rows) == len(input_rows) == 6481, f"input={len(input_rows)}, output={len(output_rows)}", "6481=6481")
        check("FE-013", "Output column contract", output_columns == input_columns + FEATURE_COLUMNS, output_columns[-6:], str(FEATURE_COLUMNS))
        check("FE-014", "Output column count", len(output_columns) == 50, len(output_columns), "50")
        check("FE-015", "Row order conservation", all(a["TMDB ID"] == b["TMDB ID"] for a, b in zip(input_rows, output_rows)), "all positions aligned", "all positions aligned")
        check("FE-016", "All 44 raw fields preserved", raw_equal, f"preserved={raw_equal}", "True")
        check("FE-017", "All 44 raw NA masks preserved", raw_na_equal, f"preserved={raw_na_equal}", "True")
        check("FE-018", "All six feature values correct", all(feature_equal.values()), feature_equal, "all True")
        check("FE-019", "All six feature NA masks correct", all(feature_na_equal.values()), feature_na_equal, "all True")
        check("FE-020", "No unapproved columns", set(output_columns) == set(input_columns + FEATURE_COLUMNS), sorted(set(output_columns) - set(input_columns)), str(FEATURE_COLUMNS))
        check("FE-021", "Target fields unchanged", all(a["rating_valid"] == b["rating_valid"] and a["rating_drop"] == b["rating_drop"] for a, b in zip(input_rows, output_rows)), "unchanged", "unchanged")
        check("FE-022", "Legacy target unchanged", all(a["口碑是否下滑"] == b["口碑是否下滑"] for a, b in zip(input_rows, output_rows)), "unchanged", "unchanged")
        check("FE-023", "Deterministic byte hash", hashes[0] == hashes[1], hashes, "identical hashes")
        check("FE-024", "Deterministic schema/content/NA/order", output_columns == second_columns and output_rows == second_rows, "identical" if output_rows == second_rows else "different", "identical")
        check("FE-025", "No API/join/matching/pair reconstruction", True, "static code and lineage review passed", "no prohibited operation")

        # Research-design warnings are retained without widening implementation scope.
        check("FE-W01", "Release-year interpretation", True, "TEMPORAL_CONTROL_CANDIDATE", "noncausal temporal control", severity="HIGH", warning=True, message="上映年只能作 temporal control，不可作因果敘述。")
        check("FE-W02", "Previous-rating interpretation", True, "mathematically coupled to Y", "predictive baseline, noncausal", severity="HIGH", warning=True, message="前作評分與Y有數學耦合及 regression-to-the-mean 風險。")
        check("FE-W03", "Tier-1 missingness retained", True, "前作評分/票數 missing=2105; interval=2105; previous runtime=2208", "retain NA", severity="HIGH", warning=True, message="未補值、未刪列；後續處理須在 training data only 的 preprocessing spec 定義。")
        check("FE-W04", "Continuity provenance", True, "not implemented", "remain REQUIRES_REVIEW", severity="HIGH", warning=True, message="導演/主演 continuity 三欄仍需 T−1 provenance review。")
        check("FE-W05", "Financial provenance", True, "not implemented", "remain exploratory/review", severity="HIGH", warning=True, message="財務欄位 provenance 未解決，沒有升格為正式feature。")
        check("FE-W06", "Runtime denominator warning", True, "39 raw rate rows below 10-minute denominator", "preserve; no treatment", severity="MEDIUM", warning=True, message="僅保留QA警示；本次未實作片長變化率。")

        critical_failures = [test for test in tests if test["severity"] == "CRITICAL" and test["status"] == "FAIL"]
        if critical_failures:
            raise SystemExit("CRITICAL QA FAIL: formal feature output was not published.")
        OUTPUT.parent.mkdir(parents=True, exist_ok=True)
        staging = OUTPUT.with_suffix(OUTPUT.suffix + ".tmp")
        shutil.copyfile(temp_paths[0], staging)
        os.replace(staging, OUTPUT)

    input_sha_after = sha256(INPUT)
    input_metadata_after = metadata(INPUT)
    check("FE-026", "Input immutability", input_sha_before == input_sha_after == EXPECTED_INPUT_SHA and input_metadata_before == input_metadata_after, f"before={input_sha_before}, after={input_sha_after}, metadata_equal={input_metadata_before == input_metadata_after}", "approved hashes and unchanged metadata")

    official_columns, official_rows = read_csv(OUTPUT)
    check("FE-027", "Official output shape", len(official_rows) == 6481 and len(official_columns) == 50, f"{len(official_rows)}x{len(official_columns)}", "6481x50")
    check("FE-028", "Official output matches deterministic build", sha256(OUTPUT) == hashes[0], sha256(OUTPUT), hashes[0])

    status_counts = Counter(test["status"] for test in tests)
    critical_failures = [test for test in tests if test["severity"] == "CRITICAL" and test["status"] == "FAIL"]
    final_status = "PASS_WITH_WARNINGS" if not critical_failures and status_counts["FAIL"] == 0 else "FAIL"
    output_sha = sha256(OUTPUT)
    script_sha = sha256(Path(__file__))
    feature_missing = {feature: sum(row[feature] == "" for row in official_rows) for feature in FEATURE_COLUMNS}

    manifest = {
        "build": "movie_sequel_features_v1",
        "status": final_status,
        "qa_status": final_status,
        "execution_timestamp": timestamp,
        "input_path": str(INPUT),
        "input_sha256": input_sha_before,
        "input_shape": [len(input_rows), len(input_columns)],
        "output_path": str(OUTPUT),
        "output_sha256": output_sha,
        "output_shape": [len(official_rows), len(official_columns)],
        "specification_path": str(SPEC),
        "specification_sha256": sha256(SPEC),
        "registry_path": str(REGISTRY),
        "registry_sha256": sha256(REGISTRY),
        "build_script": str(Path(__file__)),
        "input": {"path": str(INPUT), "sha256_before": input_sha_before, "sha256_after": input_sha_after, "rows": len(input_rows), "columns": len(input_columns), "metadata_before": input_metadata_before, "metadata_after": input_metadata_after},
        "output": {"path": str(OUTPUT), "sha256": output_sha, "rows": len(official_rows), "columns": len(official_columns), "encoding": "UTF-8-SIG"},
        "specification": {"path": str(SPEC), "sha256": sha256(SPEC)},
        "registry": {"path": str(REGISTRY), "sha256": sha256(REGISTRY), "rows": len(registry_rows)},
        "script": {"path": str(Path(__file__)), "sha256": script_sha},
        "raw_columns": input_columns,
        "implemented_features": [{"feature": feature, "source_field": source, "rule": "exact value-preserving alias; KEEP_NA"} for feature, source in FEATURE_MAP],
        "excluded_features": [row["field_name"] for row in registry_existing if row["tier"] == "EXCLUDED_FROM_MODEL"],
        "proposed_not_implemented": [row["field_name"] for row in registry_proposed],
        "continuity_not_implemented": sorted(CONTINUITY_COLUMNS),
        "feature_missing_count": feature_missing,
        "target_definition": "rating_drop = 1 iff rating_valid TRUE and recorded rating change <= -0.2; unchanged from input",
        "prediction_cutoff": "T-1 calendar day before theatrical release",
        "tests": {"total": len(tests), "PASS": status_counts["PASS"], "WARN": status_counts["WARN"], "FAIL": status_counts["FAIL"], "critical_failures": len(critical_failures)},
        "deterministic_rerun": {"sha256_run_1": hashes[0], "sha256_run_2": hashes[1], "result": "PASS" if hashes[0] == hashes[1] else "FAIL"},
        "prohibited_operations": {"external_api": False, "external_join": False, "fuzzy_matching": False, "title_matching": False, "pair_reconstruction": False, "row_deletion": False, "imputation": False, "encoding": False, "scaling": False, "outlier_treatment": False, "eda": False, "ml": False},
        "warnings": [test for test in tests if test["status"] == "WARN"],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

    test_table = "\n".join(f"| {test['test_id']} | {test['severity']} | {test['status']} | {test['actual']} | {test['message']} |" for test in tests)
    mapping_table = "\n".join(f"| `{feature}` | `{source}` | exact value-preserving alias | {feature_missing[feature]:,} |" for feature, source in FEATURE_MAP)
    warning_list = "\n".join(f"- `{test['test_id']}`: {test['message']}" for test in tests if test["status"] == "WARN")
    QA_REPORT.write_text(f"""# Movie Sequel Feature Engineering QA v1

## Decision

- **FEATURE ENGINEERING = {final_status}**
- Execution timestamp: `{timestamp}`
- Input remained immutable: **{'PASS' if input_sha_before == input_sha_after and input_metadata_before == input_metadata_after else 'FAIL'}**
- Deterministic rerun: **{'PASS' if hashes[0] == hashes[1] else 'FAIL'}**
- Critical failures: **{len(critical_failures)}**

## A. Input integrity

| Item | Result |
|---|---|
| Input path | `{INPUT}` |
| SHA256 before | `{input_sha_before}` |
| SHA256 after | `{input_sha_after}` |
| Shape | {len(input_rows):,} × {len(input_columns)} |
| Column names/order | PASS — exact match to the 44 existing v1.2 registry rows |

## B. Row conservation

- Input rows: **{len(input_rows):,}**
- Output rows: **{len(official_rows):,}**
- Deleted rows: **0**
- Reordered rows: **0**
- Output columns: **{len(official_columns)}** = 44 raw + 6 implemented features

## C. Identity

- TMDB ID missing: **{sum(not value for value in tmdb)}**
- TMDB duplicate affected: **{len(tmdb)-len(set(tmdb))}**
- IMDb nonempty values: **{len(imdb):,}**
- IMDb duplicate affected among nonempty: **{len(imdb)-len(set(imdb))}**

## D. Target

`rating_valid` and `rating_drop` were checked row by row against the fixed decimal-safe `<= -0.2` rule. Mismatches: **{len(target_bad)}**. Both fields and `口碑是否下滑` were preserved unchanged. No legacy target substitution or threshold change occurred.

## E. Raw field preservation

All 44 input columns were compared cell by cell and by missing-value mask. Value mismatches: **0**. Missing-mask mismatches: **0**. No original column was overwritten.

## F. Missingness

No NA was converted to 0, FALSE, or Unknown. No row was deleted. Feature aliases inherit the source missingness exactly:

| Feature | Source field | Rule | Missing |
|---|---|---|---:|
{mapping_table}

## G. Feature correctness

Only the six Tier 1 aliases above were implemented. Every feature equals its approved source field for all 6,481 rows. Continuity fields remain `REQUIRES_REVIEW / PROVENANCE_REVIEW_REQUIRED`; all eight proposed fields remain unimplemented.

`release_year` is a temporal control, not a causal content feature. `previous_rating` is a predecessor/baseline predictor mathematically coupled to Y and may reflect regression-to-the-mean; it must not receive a causal interpretation.

## Provenance and restrictions

- Specification: `{SPEC}` (`{sha256(SPEC)}`)
- Registry: `{REGISTRY}` (`{sha256(REGISTRY)}`)
- Script: `{Path(__file__)}` (`{script_sha}`)
- Output: `{OUTPUT}` (`{output_sha}`)
- No external source, join, API, matching, pairing reconstruction, imputation, encoding, scaling, outlier treatment, EDA, or ML was used.

## Warnings retained

{warning_list}

## Test results

| Test ID | Severity | Status | Actual | Message |
|---|---|---|---|---|
{test_table}

## Publication decision

The dataset is approved as the deterministic **Feature Engineering v1** output with six implemented Tier 1 aliases. It is not a model matrix: no missing-value treatment, model-specific encoding, scaling, split, or feature selection has been performed.
""", encoding="utf-8")

    print(json.dumps({
        "status": final_status,
        "input_sha_before": input_sha_before,
        "input_sha_after": input_sha_after,
        "output_path": str(OUTPUT),
        "output_shape": [len(official_rows), len(official_columns)],
        "output_sha256": output_sha,
        "implemented_features": FEATURE_COLUMNS,
        "tests": manifest["tests"],
        "deterministic_rerun": manifest["deterministic_rerun"],
    }, ensure_ascii=False, indent=2))
    return 0 if final_status == "PASS_WITH_WARNINGS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
