#!/usr/bin/env python3
"""Run the four prespecified Formal Random Forest v1 analyses."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import warnings
from decimal import Decimal, InvalidOperation
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")
os.environ.setdefault("MPLCONFIGDIR", "/tmp/movie_sequel_random_forest_v1_mpl")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels.api as sm
import statsmodels
from sklearn.calibration import calibration_curve
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance
from sklearn.metrics import (
    accuracy_score, average_precision_score, brier_score_loss, confusion_matrix,
    f1_score, precision_recall_curve, precision_score, recall_score,
    roc_auc_score, roc_curve,
)


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
PREPROCESSING_SPEC = ROOT / "reports/ml_preprocessing_spec_v1.md"
LOGISTIC_RESULTS = ROOT / "reports/logistic_regression_v1_results.csv"
REPORT = ROOT / "reports/random_forest_v1_report.md"
RESULTS = ROOT / "reports/random_forest_v1_results.csv"
IMPORTANCE = ROOT / "reports/random_forest_v1_feature_importance.csv"
PREDICTIONS = ROOT / "reports/random_forest_v1_predictions.csv"
CURVES = ROOT / "reports/random_forest_v1_curve_data.csv"
PARAMETERS = ROOT / "reports/random_forest_v1_preprocessing_parameters.csv"
DIAGNOSTICS = ROOT / "reports/random_forest_v1_diagnostics.csv"
MANIFEST = ROOT / "reports/random_forest_v1_manifest.json"
QA = ROOT / "reports/random_forest_v1_qa.md"
FIGURE_DIR = ROOT / "reports/figures/random_forest_v1"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
EXPECTED_TARGET = {"n": 4058, "1": 2014, "0": 2044}
SEED = 20260913
THRESHOLD = 0.5
PERMUTATION_REPEATS = 30
MODEL_FEATURES = {
    "Model A": ["sequel_number", "release_year", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"],
    "Model B": ["sequel_number", "release_year", "years_since_previous", "previous_runtime"],
}
STRATEGIES = ["P1", "P2"]
RF_PARAMS = {
    "n_estimators": 500, "max_depth": None, "min_samples_split": 2,
    "min_samples_leaf": 1, "max_features": "sqrt", "bootstrap": True,
    "class_weight": None, "criterion": "gini", "random_state": SEED, "n_jobs": 1,
}
PROHIBITED = {
    "平均評分", "評分人數", "人氣", "票房", "與前作評分差", "與前作票房差",
    "票房變化率", "rating_change", "rating_valid", "rating_drop", "口碑是否下滑",
    "電影系列ID", "TMDB ID", "IMDb ID",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def json_default(value):
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def gate_input() -> tuple[pd.DataFrame, dict]:
    digest = sha256(INPUT)
    if digest != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL FAILURE: input SHA mismatch: {digest}")
    frame = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if frame.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL FAILURE: input shape mismatch: {frame.shape}")
    required = set(sum(MODEL_FEATURES.values(), [])) | {
        "rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差",
        "電影系列ID", "TMDB ID", "IMDb ID",
    }
    if not required.issubset(frame.columns):
        raise SystemExit(f"CRITICAL FAILURE: missing columns {sorted(required - set(frame.columns))}")
    mismatch_rows = []
    for index, row in frame.iterrows():
        current = decimal_or_none(row["平均評分"])
        previous = decimal_or_none(row["前作評分"])
        change = decimal_or_none(row["與前作評分差"])
        valid = current is not None and previous is not None and change is not None and current > 0 and previous > 0
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            mismatch_rows.append(int(index) + 2)
    if mismatch_rows:
        raise SystemExit(f"CRITICAL FAILURE: target mismatch rows {mismatch_rows[:10]}")
    eligible = frame["rating_valid"].eq("TRUE") & frame["rating_drop"].isin(["0", "1"])
    counts = frame.loc[eligible, "rating_drop"].value_counts().to_dict()
    if int(eligible.sum()) != 4058 or counts != {"0": 2044, "1": 2014}:
        raise SystemExit(f"CRITICAL FAILURE: target population mismatch n={eligible.sum()}, counts={counts}")
    all_x = set(sum(MODEL_FEATURES.values(), []))
    if all_x & PROHIBITED:
        raise SystemExit(f"CRITICAL FAILURE: prohibited X {sorted(all_x & PROHIBITED)}")
    tmdb = frame["TMDB ID"]
    imdb = frame.loc[frame["IMDb ID"].ne(""), "IMDb ID"]
    if tmdb.eq("").any() or tmdb.duplicated().any() or imdb.duplicated().any():
        raise SystemExit("CRITICAL FAILURE: identity integrity failed")
    return frame, {
        "input_sha256": digest, "input_shape": list(frame.shape), "target_mismatches": 0,
        "eligible_n": int(eligible.sum()), "drop_n": int(counts["1"]), "non_drop_n": int(counts["0"]),
    }


def numeric(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    return frame[columns].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)


def calibration_stats(y: np.ndarray, probability: np.ndarray) -> tuple[float, float, str]:
    clipped = np.clip(probability, 1e-12, 1 - 1e-12)
    logit = np.log(clipped / (1 - clipped))
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            fitted = sm.GLM(y, sm.add_constant(logit, has_constant="add"), family=sm.families.Binomial()).fit(maxiter=200, tol=1e-10)
        if any(type(item.message).__name__ == "PerfectSeparationWarning" for item in caught):
            return np.nan, np.nan, "NOT_ESTIMABLE_PERFECT_PREDICTION"
        return float(fitted.params[0]), float(fitted.params[1]), "ESTIMABLE"
    except Exception as exc:
        return np.nan, np.nan, f"NOT_ESTIMABLE:{type(exc).__name__}"


def metrics(y: np.ndarray, probability: np.ndarray) -> dict:
    predicted = (probability >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    intercept, slope, calibration_status = calibration_stats(y, probability)
    return {
        "roc_auc": float(roc_auc_score(y, probability)),
        "pr_auc": float(average_precision_score(y, probability)),
        "brier": float(brier_score_loss(y, probability)),
        "accuracy": float(accuracy_score(y, predicted)),
        "precision": float(precision_score(y, predicted, zero_division=0)),
        "recall": float(recall_score(y, predicted, zero_division=0)),
        "f1": float(f1_score(y, predicted, zero_division=0)),
        "specificity": float(tn / (tn + fp)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "calibration_intercept": intercept, "calibration_slope": slope,
        "calibration_status": calibration_status,
        "mean_predicted_probability": float(probability.mean()),
        "observed_prevalence": float(y.mean()),
    }


def prepare(eligible: pd.DataFrame, model: str, strategy: str) -> dict:
    features = MODEL_FEATURES[model]
    x_all = numeric(eligible, features)
    y_all = pd.to_numeric(eligible["rating_drop"], errors="raise").astype(int)
    years = pd.to_numeric(eligible["release_year"], errors="coerce")
    if years.isna().any():
        raise RuntimeError("Missing release year in target-eligible population")
    train_base, test_base = years <= 2020, years >= 2021
    if not (train_base | test_base).all() or (train_base & test_base).any():
        raise RuntimeError("Temporal split does not partition eligible population")
    parameter_rows = []
    missing_rows = []
    for feature in features:
        missing_rows.append({
            "model": model, "preprocessing": strategy, "feature": feature,
            "eligible_missing_count": int(x_all[feature].isna().sum()),
            "eligible_missing_rate": float(x_all[feature].isna().mean()),
            "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()),
            "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()),
        })
    if strategy == "P1":
        used = x_all.notna().all(axis=1)
        train_mask, test_mask = train_base & used, test_base & used
        x_train_raw, x_test_raw = x_all.loc[train_mask].copy(), x_all.loc[test_mask].copy()
        indicators = []
    else:
        used = pd.Series(True, index=eligible.index)
        train_mask, test_mask = train_base, test_base
        x_train_raw, x_test_raw = x_all.loc[train_mask].copy(), x_all.loc[test_mask].copy()
        indicators = []
        for feature in features:
            train_missing = x_train_raw[feature].isna()
            test_missing = x_test_raw[feature].isna()
            median = float(x_train_raw.loc[~train_missing, feature].median())
            if not np.isfinite(median):
                raise RuntimeError(f"{model}-{strategy}: invalid train median for {feature}")
            if train_missing.any():
                indicator = f"{feature}__missing"
                indicators.append(indicator)
                x_train_raw[indicator] = train_missing.astype(float)
                x_test_raw[indicator] = test_missing.astype(float)
            x_train_raw[feature] = x_train_raw[feature].fillna(median)
            x_test_raw[feature] = x_test_raw[feature].fillna(median)
            parameter_rows.append({
                "model": model, "preprocessing": strategy, "feature": feature,
                "parameter_type": "TRAIN_ONLY_MEDIAN", "value": median,
                "train_missing_count": int(train_missing.sum()), "test_missing_count": int(test_missing.sum()),
                "indicator_included": bool(train_missing.any()), "parameter_source": "TRAIN_ONLY",
            })
    x_train, x_test = pd.DataFrame(index=x_train_raw.index), pd.DataFrame(index=x_test_raw.index)
    for feature in features:
        mean = float(x_train_raw[feature].mean())
        std = float(x_train_raw[feature].std(ddof=0))
        if not np.isfinite(std) or std == 0:
            raise RuntimeError(f"{model}-{strategy}: invalid train SD for {feature}")
        x_train[feature] = (x_train_raw[feature] - mean) / std
        x_test[feature] = (x_test_raw[feature] - mean) / std
        parameter_rows.extend([
            {"model": model, "preprocessing": strategy, "feature": feature, "parameter_type": "TRAIN_MEAN", "value": mean, "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()), "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()), "indicator_included": f"{feature}__missing" in indicators, "parameter_source": "TRAIN_ONLY"},
            {"model": model, "preprocessing": strategy, "feature": feature, "parameter_type": "TRAIN_POPULATION_SD", "value": std, "train_missing_count": int(x_all.loc[train_base, feature].isna().sum()), "test_missing_count": int(x_all.loc[test_base, feature].isna().sum()), "indicator_included": f"{feature}__missing" in indicators, "parameter_source": "TRAIN_ONLY"},
        ])
    for indicator in indicators:
        x_train[indicator] = x_train_raw[indicator]
        x_test[indicator] = x_test_raw[indicator]
    return {
        "x_train": x_train, "x_test": x_test,
        "y_train": y_all.loc[train_mask], "y_test": y_all.loc[test_mask],
        "train_rows": eligible.loc[train_mask], "test_rows": eligible.loc[test_mask],
        "used": used, "parameters": pd.DataFrame(parameter_rows),
        "missingness": pd.DataFrame(missing_rows), "indicators": indicators,
    }


def curve_rows(model: str, strategy: str, split: str, y: np.ndarray, probability: np.ndarray) -> list[dict]:
    rows = []
    fpr, tpr, thresholds = roc_curve(y, probability)
    rows += [{"model": model, "preprocessing": strategy, "split": split, "curve": "ROC", "point": i, "x": fpr[i], "y": tpr[i], "threshold": thresholds[i]} for i in range(len(fpr))]
    precision, recall, thresholds = precision_recall_curve(y, probability)
    rows += [{"model": model, "preprocessing": strategy, "split": split, "curve": "PR", "point": i, "x": recall[i], "y": precision[i], "threshold": thresholds[i] if i < len(thresholds) else np.nan} for i in range(len(precision))]
    observed, predicted = calibration_curve(y, probability, n_bins=10, strategy="quantile")
    rows += [{"model": model, "preprocessing": strategy, "split": split, "curve": "CALIBRATION", "point": i, "x": predicted[i], "y": observed[i], "threshold": np.nan} for i in range(len(observed))]
    return rows


def fit_one(eligible: pd.DataFrame, model: str, strategy: str) -> dict[str, pd.DataFrame]:
    prepared = prepare(eligible, model, strategy)
    x_train, x_test = prepared["x_train"], prepared["x_test"]
    y_train, y_test = prepared["y_train"].to_numpy(), prepared["y_test"].to_numpy()
    classifier = RandomForestClassifier(**RF_PARAMS)
    classifier.fit(x_train, y_train)
    p_train = classifier.predict_proba(x_train)[:, 1]
    p_test = classifier.predict_proba(x_test)[:, 1]
    results_rows, curves = [], []
    for split, y, p in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        results_rows.append({"model": model, "preprocessing": strategy, "split": split, "n": len(y), **metrics(y, p)})
        curves.extend(curve_rows(model, strategy, split, y, p))

    importance_rows = []
    for feature, value in zip(x_train.columns, classifier.feature_importances_):
        importance_rows.append({
            "model": model, "preprocessing": strategy, "feature": feature,
            "importance_type": "IMPURITY_GINI", "importance": float(value),
            "importance_std": np.nan, "evaluation_split": "TRAIN_FIT", "n_repeats": np.nan,
        })
    permutation = permutation_importance(
        classifier, x_test, y_test, scoring="roc_auc", n_repeats=PERMUTATION_REPEATS,
        random_state=SEED, n_jobs=1,
    )
    for feature, mean, std in zip(x_test.columns, permutation.importances_mean, permutation.importances_std):
        importance_rows.append({
            "model": model, "preprocessing": strategy, "feature": feature,
            "importance_type": "TEST_PERMUTATION_ROC_AUC_DECREASE", "importance": float(mean),
            "importance_std": float(std), "evaluation_split": "TEST", "n_repeats": PERMUTATION_REPEATS,
        })
    importance_frame = pd.DataFrame(importance_rows)
    importance_frame["rank"] = importance_frame.groupby(["model", "preprocessing", "importance_type"])["importance"].rank(method="min", ascending=False).astype(int)

    prediction_rows = []
    for split, rows, y, p in [("TRAIN", prepared["train_rows"], y_train, p_train), ("TEST", prepared["test_rows"], y_test, p_test)]:
        for source_index, tmdb, imdb, group, observed, probability in zip(rows.index, rows["TMDB ID"], rows["IMDb ID"], rows["電影系列ID"], y, p):
            prediction_rows.append({
                "model": model, "preprocessing": strategy, "split": split,
                "source_row_index": int(source_index), "TMDB_ID": tmdb, "IMDb_ID": imdb,
                "franchise_group_id": group, "rating_drop": int(observed),
                "predicted_probability": float(probability),
                "predicted_class": int(probability >= THRESHOLD),
            })
    diagnostics = pd.DataFrame([{
        "model": model, "preprocessing": strategy, "eligible_n": len(eligible),
        "used_n": int(prepared["used"].sum()), "excluded_n": int((~prepared["used"]).sum()),
        "train_n": len(y_train), "test_n": len(y_test), "model_feature_count": x_train.shape[1],
        "feature_schema": "|".join(MODEL_FEATURES[model]),
        "technical_indicators": "|".join(prepared["indicators"]),
        "fitted_estimators": len(classifier.estimators_), "classes": "|".join(map(str, classifier.classes_)),
        "random_state": SEED, "n_jobs": 1, "numerical_issue": False,
    }])
    return {
        "results": pd.DataFrame(results_rows), "importance": importance_frame,
        "predictions": pd.DataFrame(prediction_rows), "curves": pd.DataFrame(curves),
        "parameters": prepared["parameters"], "missingness": prepared["missingness"],
        "diagnostics": diagnostics,
    }


def run_all(frame: pd.DataFrame) -> dict[str, pd.DataFrame]:
    eligible = frame[(frame["rating_valid"] == "TRUE") & frame["rating_drop"].isin(["0", "1"])].copy()
    buckets = {key: [] for key in ["results", "importance", "predictions", "curves", "parameters", "missingness", "diagnostics"]}
    for model in ["Model A", "Model B"]:
        for strategy in STRATEGIES:
            fitted = fit_one(eligible, model, strategy)
            for key in buckets:
                buckets[key].append(fitted[key])
    return {key: pd.concat(frames, ignore_index=True) for key, frames in buckets.items()}


def deterministic_equal(first: dict[str, pd.DataFrame], second: dict[str, pd.DataFrame]) -> bool:
    return all(first[key].equals(second[key]) for key in first)


def make_figures(outputs: dict[str, pd.DataFrame]) -> list[Path]:
    FIGURE_DIR.mkdir(parents=True, exist_ok=True)
    curves, results, importance = outputs["curves"], outputs["results"], outputs["importance"]
    colors = {("Model A", "P1"): "#2457A6", ("Model A", "P2"): "#4C9BE8", ("Model B", "P1"): "#B04A3A", ("Model B", "P2"): "#E58A5B"}
    plt.rcParams.update({"figure.dpi": 120, "savefig.dpi": 160, "font.size": 10, "axes.grid": True, "grid.alpha": .2})
    paths = []
    for curve, name, xlabel, ylabel in [
        ("ROC", "01_roc_curves.png", "False positive rate", "True positive rate"),
        ("PR", "02_pr_curves.png", "Recall", "Precision"),
        ("CALIBRATION", "03_calibration_curves.png", "Mean predicted probability", "Observed drop rate"),
    ]:
        fig, ax = plt.subplots(figsize=(8, 6))
        if curve in {"ROC", "CALIBRATION"}:
            ax.plot([0, 1], [0, 1], "--", color="#777", linewidth=1, label="Reference")
        for model in ["Model A", "Model B"]:
            for prep in STRATEGIES:
                subset = curves.query("model == @model and preprocessing == @prep and split == 'TEST' and curve == @curve")
                label = f"{model} + {prep}"
                row = results.query("model == @model and preprocessing == @prep and split == 'TEST'").iloc[0]
                if curve == "ROC": label += f" (AUC={row.roc_auc:.3f})"
                if curve == "PR": label += f" (AP={row.pr_auc:.3f})"
                ax.plot(subset.x, subset.y, color=colors[(model, prep)], linewidth=2, label=label)
        ax.set(title=f"Random Forest v1 — Test {curve}", xlabel=xlabel, ylabel=ylabel, xlim=(0, 1), ylim=(0, 1))
        ax.legend(frameon=False, fontsize=9)
        fig.tight_layout()
        path = FIGURE_DIR / name
        fig.savefig(path, bbox_inches="tight", metadata={"Software": "movie-sequel-random-forest-v1"})
        plt.close(fig); paths.append(path)

    for kind, name, title, xlabel in [
        ("IMPURITY_GINI", "04_impurity_feature_importance.png", "Random Forest v1 — Impurity importance", "Mean decrease in Gini impurity"),
        ("TEST_PERMUTATION_ROC_AUC_DECREASE", "05_test_permutation_importance.png", "Random Forest v1 — Test permutation importance", "Mean test ROC-AUC decrease after permutation"),
    ]:
        data = importance.query("importance_type == @kind").copy()
        labels = [f"{m} + {p}: {f}" for m, p, f in zip(data.model, data.preprocessing, data.feature)]
        ypos = np.arange(len(data))
        fig, ax = plt.subplots(figsize=(9, max(7, len(data) * .34)))
        bar_colors = [colors[(m, p)] for m, p in zip(data.model, data.preprocessing)]
        ax.barh(ypos, data.importance, xerr=data.importance_std if kind.startswith("TEST") else None, color=bar_colors, alpha=.9, capsize=2)
        ax.axvline(0, color="#777", linewidth=1)
        ax.set_yticks(ypos, labels); ax.invert_yaxis(); ax.set_xlabel(xlabel); ax.set_title(title)
        fig.tight_layout()
        path = FIGURE_DIR / name
        fig.savefig(path, bbox_inches="tight", metadata={"Software": "movie-sequel-random-forest-v1"})
        plt.close(fig); paths.append(path)
    return paths


def markdown_table(frame: pd.DataFrame) -> str:
    formatted = frame.copy()
    for column in formatted.columns:
        if pd.api.types.is_float_dtype(formatted[column]):
            formatted[column] = formatted[column].map(lambda value: "" if pd.isna(value) else f"{value:.4f}")
    headers = [str(column) for column in formatted.columns]
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    for row in formatted.astype(str).itertuples(index=False, name=None):
        lines.append("| " + " | ".join(row) + " |")
    return "\n".join(lines)


def make_report(outputs: dict[str, pd.DataFrame], gate: dict, status: str) -> None:
    results, importance, diagnostics = outputs["results"], outputs["importance"], outputs["diagnostics"]
    test = results.query("split == 'TEST'").copy()
    logistic = pd.read_csv(LOGISTIC_RESULTS, encoding="utf-8-sig")
    logistic_test = logistic.query("split == 'TEST'")[["model", "preprocessing", "roc_auc"]].rename(columns={"roc_auc": "logistic_test_roc_auc"})
    comparison = test[["model", "preprocessing", "n", "roc_auc", "pr_auc", "brier"]].merge(logistic_test, on=["model", "preprocessing"], how="left")
    comparison["rf_minus_logistic_roc_auc"] = comparison["roc_auc"] - comparison["logistic_test_roc_auc"]
    if bool((comparison["rf_minus_logistic_roc_auc"] < 0).all()):
        improvement_statement = "No. All four observed Random Forest test ROC-AUC values were below their matching Logistic baselines; there was no marked improvement."
    else:
        improvement_statement = "Results were mixed; observed differences are shown in the comparison table and do not define a marked improvement without a prespecified margin."
    top = importance.query("importance_type == 'TEST_PERMUTATION_ROC_AUC_DECREASE'").sort_values(["model", "preprocessing", "rank"]).groupby(["model", "preprocessing"], as_index=False).first()
    def value(model: str, prep: str, column: str) -> float:
        return float(test.query("model == @model and preprocessing == @prep").iloc[0][column])
    p_sens_a = value("Model A", "P2", "roc_auc") - value("Model A", "P1", "roc_auc")
    p_sens_b = value("Model B", "P2", "roc_auc") - value("Model B", "P1", "roc_auc")
    coupling_p1 = value("Model A", "P1", "roc_auc") - value("Model B", "P1", "roc_auc")
    coupling_p2 = value("Model A", "P2", "roc_auc") - value("Model B", "P2", "roc_auc")
    lines = [
        "# Formal Random Forest v1", "", "## Executive conclusion", "",
        f"All four prespecified Random Forest runs passed critical QA. Test ROC-AUC ranged from {test.roc_auc.min():.4f} to {test.roc_auc.max():.4f}. The comparison with Logistic is descriptive only; no hyperparameter, preprocessing strategy, threshold, or feature set was selected from test performance.", "",
        "## 1. Research question", "",
        "Can T−1 information predict whether a sequel's rating falls by at least 0.2 relative to its predecessor? This is predictive, not causal, analysis.", "",
        "## 2. Target and population", "",
        "The unchanged Y is `rating_drop`: 1 for valid rating change ≤−0.2, 0 for valid change >−0.2, and missing for invalid rating pairs.", "",
        f"Eligible population: {gate['eligible_n']:,}; drop={gate['drop_n']:,}; non-drop={gate['non_drop_n']:,}.", "",
        "## 3. Models and preprocessing", "",
        "Model A uses the six approved predictors. Model B removes only `previous_rating` and `previous_rating_votes` as the prespecified mathematical-coupling sensitivity. P1 is complete-case; P2 splits first, uses training-only medians and a training-determined original-missingness indicator. Numeric predictors use training-only standardization; although scaling does not change tree ordering, it preserves the approved preprocessing pipeline.", "",
        "Train is release year ≤2020 and test is release year ≥2021. The 2026 cohort is incomplete.", "",
        "## 4. Fixed Random Forest specification", "",
        "500 trees; unrestricted depth; minimum split 2; minimum leaf 1; sqrt feature sampling; bootstrap enabled; Gini criterion; no class weights; seed 20260913; one execution thread. No tuning or cross-validation search was performed.", "",
        "## 5. Train and test metrics", "",
        markdown_table(results[["model", "preprocessing", "split", "n", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "tn", "fp", "fn", "tp", "calibration_intercept", "calibration_slope"]]), "",
        "## 6. Calibration", "",
        "Calibration uses ten quantile bins. Intercept and slope were estimated against the logit of predicted probabilities. No calibration correction, Platt scaling, or isotonic regression was applied.", "",
        "## 7. Feature importance", "",
        "Impurity importance describes split usage within the fitted forest. Test permutation importance is the mean test ROC-AUC decrease across 30 fixed-seed permutations. Neither is causal, an independent effect, or a feature-selection rule.", "",
        markdown_table(top[["model", "preprocessing", "feature", "importance", "importance_std", "rank"]]), "",
        "Complete importance values and ranks are in the machine-readable feature-importance file.", "",
        "## 8. A/B mathematical-coupling sensitivity", "",
        f"Model A minus Model B test ROC-AUC was {coupling_p1:+.4f} under P1 and {coupling_p2:+.4f} under P2. This only describes performance after removing predecessor-rating information; it does not prove feature importance, independent contribution, or causality.", "",
        "## 9. P1/P2 preprocessing sensitivity", "",
        f"P2 minus P1 test ROC-AUC was {p_sens_a:+.4f} for Model A and {p_sens_b:+.4f} for Model B. P1 and P2 use different sample compositions, so this is not a basis for declaring one preprocessing policy best.", "",
        "## 10. Comparison with formal Logistic baseline", "",
        markdown_table(comparison), "",
        "The differences are descriptive on one fixed later-time test cohort. They do not authorize Random Forest tuning or changes to Logistic Regression.", "",
        "## 11. Leakage and reproducibility QA", "",
        "No prohibited, current-outcome, target-derived, identity, or grouping field entered X. The seed and single-thread execution were fixed. Two complete analytical executions produced identical predictions, probabilities, metrics, importance values, parameters, and curve data.", "",
        "## 12. Limitations", "",
        "- 2026 is an incomplete test-cohort year.",
        "- P1 excludes missing predecessor-runtime rows; P2 makes a training-median assumption.",
        "- Same-franchise separation remains a future robustness analysis; franchise identity was not X.",
        "- Model A includes predecessor-rating information mathematically coupled to the change-based Y.",
        "- Permutation importance uses the test cohort for exploratory interpretation only and cannot feed feature selection or retraining.",
        "- Random Forest probabilities may be miscalibrated even when discrimination is useful.",
        "- This model is not causal and is not declared best from this single comparison.",
        "- The environment emitted a non-blocking optional `bottleneck` version warning; deterministic outputs were unchanged.", "",
        "## 13. Required conclusions", "",
        f"1. Model A + P1 Test ROC-AUC: **{value('Model A','P1','roc_auc'):.4f}**",
        f"2. Model A + P2 Test ROC-AUC: **{value('Model A','P2','roc_auc'):.4f}**",
        f"3. Model B + P1 Test ROC-AUC: **{value('Model B','P1','roc_auc'):.4f}**",
        f"4. Model B + P2 Test ROC-AUC: **{value('Model B','P2','roc_auc'):.4f}**",
        f"5. Random Forest versus Logistic: **{improvement_statement}**",
        "6. P1/P2 sensitivity is small or large only as shown numerically; it is not used to select preprocessing.",
        "7. A/B results fulfill the coupling sensitivity and do not establish causal or independent effects.",
        "8. No leakage was detected.",
        f"9. Numerical/reproducibility issue: {'none detected' if not diagnostics.numerical_issue.any() else 'review required'}.",
        "10. Higher-importance features are listed above and in the feature-importance file; they remain interpretation-only.", "",
        f"**STATUS = {status}**", "",
    ]
    REPORT.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    input_sha_before = sha256(INPUT)
    input_size_before = INPUT.stat().st_size
    frame, gate = gate_input()
    first = run_all(frame)
    second = run_all(frame)
    deterministic = deterministic_equal(first, second)
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated analytical executions differ")

    write_csv(first["results"], RESULTS)
    write_csv(first["importance"], IMPORTANCE)
    write_csv(first["predictions"], PREDICTIONS)
    write_csv(first["curves"], CURVES)
    write_csv(first["parameters"], PARAMETERS)
    write_csv(first["diagnostics"], DIAGNOSTICS)
    figures = make_figures(first)

    source_immutable = sha256(INPUT) == input_sha_before and INPUT.stat().st_size == input_size_before
    expected_runs = set((m, p) for m in MODEL_FEATURES for p in STRATEGIES)
    actual_runs = set(map(tuple, first["diagnostics"][["model", "preprocessing"]].to_numpy()))
    p2_params = first["parameters"].query("parameter_type == 'TRAIN_ONLY_MEDIAN'")
    scaling_params = first["parameters"].query("parameter_type in ['TRAIN_MEAN','TRAIN_POPULATION_SD']")
    qa_checks = [
        ("Q1", "Input SHA correct", input_sha_before == EXPECTED_SHA, input_sha_before),
        ("Q2", "Input shape correct", tuple(gate["input_shape"]) == EXPECTED_SHAPE, str(tuple(gate["input_shape"]))),
        ("Q3", "Target definition unchanged", gate["target_mismatches"] == 0, "0 mismatches"),
        ("Q4", "Target n = 4,058", gate["eligible_n"] == 4058, str(gate["eligible_n"])),
        ("Q5", "Class counts correct", gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q6", "Model A feature schema exact", MODEL_FEATURES["Model A"] == ["sequel_number","release_year","previous_rating","previous_rating_votes","years_since_previous","previous_runtime"], "|".join(MODEL_FEATURES["Model A"])),
        ("Q7", "Model B feature schema exact", MODEL_FEATURES["Model B"] == ["sequel_number","release_year","years_since_previous","previous_runtime"], "|".join(MODEL_FEATURES["Model B"])),
        ("Q8", "P1/P2 rules exact", actual_runs == expected_runs, str(sorted(actual_runs))),
        ("Q9", "No leakage fields", not (set(sum(MODEL_FEATURES.values(), [])) & PROHIBITED), "No prohibited intersection"),
        ("Q10", "No identity fields", not ({"TMDB ID","IMDb ID","電影系列ID"} & set(sum(MODEL_FEATURES.values(), []))), "Identity fields absent"),
        ("Q11", "Franchise ID excluded", "電影系列ID" not in set(sum(MODEL_FEATURES.values(), [])), "Grouping only"),
        ("Q12", "Train/test split exact", True, "TRAIN<=2020; TEST>=2021"),
        ("Q13", "No test-derived preprocessing", bool((p2_params.parameter_source == "TRAIN_ONLY").all() and (scaling_params.parameter_source == "TRAIN_ONLY").all()), "All fitted preprocessing parameters train-only"),
        ("Q14", "No SMOTE", True, "Not implemented"),
        ("Q15", "No class weighting", RF_PARAMS["class_weight"] is None, "class_weight=None"),
        ("Q16", "Threshold = 0.5", THRESHOLD == .5, str(THRESHOLD)),
        ("Q17", "No hyperparameter tuning", True, "One fixed parameter set"),
        ("Q18", "No feature selection", True, "Fixed schemas"),
        ("Q19", "No outlier deletion", True, "No value-range filters"),
        ("Q20", "No unauthorized feature construction", True, "Only standardization and approved P2 indicator"),
        ("Q21", "Deterministic random seed", RF_PARAMS["random_state"] == SEED and RF_PARAMS["n_jobs"] == 1, f"seed={SEED}; n_jobs=1"),
        ("Q22", "Repeated execution deterministic", deterministic, "All analytical frames identical"),
        ("Q23", "Feature importance generated", first["importance"].importance_type.eq("IMPURITY_GINI").any(), "Impurity rows present"),
        ("Q24", "Permutation importance generated", first["importance"].importance_type.eq("TEST_PERMUTATION_ROC_AUC_DECREASE").any(), f"test-only; repeats={PERMUTATION_REPEATS}"),
        ("Q25", "Calibration generated", first["curves"].curve.eq("CALIBRATION").any(), "Ten-quantile curve data present"),
    ]
    failed = [q for q in qa_checks if not q[2]]
    status = "RANDOM_FOREST_V1_COMPLETE" if not failed and source_immutable else "RANDOM_FOREST_V1_BLOCKED"
    qa_lines = ["# Random Forest v1 QA", "", f"**STATUS = {status}**", "", "| Test | Objective | Status | Evidence |", "|---|---|---|---|"]
    for test, objective, passed, evidence in qa_checks:
        qa_lines.append(f"| {test} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |")
    qa_lines += [
        "", "## Additional safeguards", "",
        f"- Source immutability: {'PASS' if source_immutable else 'FAIL'}",
        "- Four fixed Random Forest runs completed with 500 fitted estimators each.",
        "- 2026 cohort is incomplete.",
        "- Permutation importance is test-only exploratory interpretation and did not feed retraining.",
        "- Optional `bottleneck` version warning is non-blocking; deterministic results were unchanged.",
        "- No XGBoost, SHAP, EBM, tuning, feature selection, threshold optimization, external enrichment, or new EDA was executed.", "",
    ]
    QA.write_text("\n".join(qa_lines), encoding="utf-8")
    make_report(first, gate, status)

    output_files = [RESULTS, IMPORTANCE, PREDICTIONS, CURVES, PARAMETERS, DIAGNOSTICS, REPORT, QA, *figures]
    manifest = {
        "status": status,
        "input_path": str(INPUT.relative_to(ROOT)), "input_sha256": input_sha_before,
        "input_shape": gate["input_shape"], "source_immutable": source_immutable,
        "target": "rating_drop", "target_threshold": "recorded rating change <= -0.2",
        "eligible_n": gate["eligible_n"], "target_counts": {"1": gate["drop_n"], "0": gate["non_drop_n"]},
        "model_A_features": MODEL_FEATURES["Model A"], "model_B_features": MODEL_FEATURES["Model B"],
        "preprocessing_strategies": ["P1_COMPLETE_CASE", "P2_TRAIN_ONLY_MEDIAN_PLUS_TRAIN_MISSINGNESS_INDICATOR"],
        "train_rule": "release_year <= 2020", "test_rule": "release_year >= 2021",
        "rf_hyperparameters": RF_PARAMS, "threshold": THRESHOLD, "random_seed": SEED,
        "permutation_importance": {"split": "TEST", "scoring": "ROC_AUC", "n_repeats": PERMUTATION_REPEATS, "random_state": SEED, "interpretation_only": True},
        "preprocessing_specification": str(PREPROCESSING_SPEC.relative_to(ROOT)), "preprocessing_specification_sha256": sha256(PREPROCESSING_SPEC),
        "logistic_comparison_source": str(LOGISTIC_RESULTS.relative_to(ROOT)), "logistic_comparison_source_sha256": sha256(LOGISTIC_RESULTS),
        "deterministic_execution": deterministic,
        "qa": {"pass": sum(q[2] for q in qa_checks), "fail": len(failed), "failed_tests": [q[0] for q in failed]},
        "output_files": {str(path.relative_to(ROOT)): sha256(path) for path in output_files},
        "script": str(Path(__file__).relative_to(ROOT)), "script_sha256": sha256(Path(__file__)),
        "software": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "scipy": scipy.__version__, "statsmodels": statsmodels.__version__, "scikit_learn": sklearn.__version__, "matplotlib": matplotlib.__version__},
        "warnings": ["2026 cohort is incomplete", "P1/P2 sample composition differs", "previous_rating is mathematically coupled to target", "test permutation importance is interpretation-only", "franchise-aware robustness not run", "optional bottleneck version warning was non-blocking"],
        "prohibited_actions_executed": [],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True, default=json_default) + "\n", encoding="utf-8")
    if status.endswith("BLOCKED"):
        raise SystemExit("Formal Random Forest v1 blocked by critical QA")
    print(first["results"].to_string(index=False))
    print(f"STATUS={status}")


if __name__ == "__main__":
    main()
