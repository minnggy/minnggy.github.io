#!/usr/bin/env python3
"""Run the fixed final regularization-only Logistic Regression tuning experiment."""

from __future__ import annotations

import hashlib
import json
import math
import os
import platform
import warnings
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np
import pandas as pd
import scipy
import sklearn
import statsmodels
import statsmodels.api as sm
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    brier_score_loss,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import TimeSeriesSplit


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data/processed/movie_sequel_features_v1.csv"
PREPROCESSING_SPEC = ROOT / "reports/ml_preprocessing_spec_v1.md"
BASELINE_RESULTS = ROOT / "reports/logistic_regression_v1_results.csv"
SPEC = ROOT / "reports/logistic_regression_tuned_v1_spec.md"
CV_RESULTS = ROOT / "reports/logistic_regression_tuned_v1_cv_results.csv"
RESULTS = ROOT / "reports/logistic_regression_tuned_v1_results.csv"
COEFFICIENTS = ROOT / "reports/logistic_regression_tuned_v1_coefficients.csv"
MANIFEST = ROOT / "reports/logistic_regression_tuned_v1_manifest.json"
QA = ROOT / "reports/logistic_regression_tuned_v1_qa.md"

EXPECTED_SHA = "a8ee2ebc08c12ee9f85b98691b3de2f2ddeacb6ab9a5113a6ae806b713a6a3b6"
EXPECTED_SHAPE = (6481, 50)
FEATURES = [
    "sequel_number", "release_year", "previous_rating", "previous_rating_votes",
    "years_since_previous", "previous_runtime",
]
PROHIBITED = {
    "平均評分", "評分人數", "人氣", "票房", "與前作評分差", "與前作票房差",
    "票房變化率", "rating_change", "rating_valid", "rating_drop", "口碑是否下滑",
    "電影系列ID", "TMDB ID", "IMDb ID",
}
PENALTIES = ["l2", "l1"]
C_VALUES = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0, 1000.0]
SOLVER = "liblinear"
MAX_ITER = 10000
SEED = 20260913
THRESHOLD = 0.5
CV_FOLDS = 5


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def write_csv(frame: pd.DataFrame, path: Path) -> None:
    frame.to_csv(path, index=False, encoding="utf-8-sig", lineterminator="\n", na_rep="")


def decimal_or_none(value: str) -> Decimal | None:
    if value == "":
        return None
    try:
        number = Decimal(value)
        return number if number.is_finite() else None
    except (InvalidOperation, TypeError):
        return None


def gate_input() -> tuple[pd.DataFrame, dict]:
    input_sha = sha256(INPUT)
    if input_sha != EXPECTED_SHA:
        raise SystemExit(f"CRITICAL FAILURE: input SHA mismatch: {input_sha}")
    frame = pd.read_csv(INPUT, dtype=str, keep_default_na=False, encoding="utf-8-sig")
    if frame.shape != EXPECTED_SHAPE:
        raise SystemExit(f"CRITICAL FAILURE: input shape mismatch: {frame.shape}")
    required = set(FEATURES) | {
        "rating_valid", "rating_drop", "平均評分", "前作評分", "與前作評分差",
        "上映日期", "TMDB ID", "IMDb ID", "電影系列ID",
    }
    if not required.issubset(frame.columns):
        raise SystemExit(f"CRITICAL FAILURE: missing columns: {sorted(required - set(frame.columns))}")
    if set(FEATURES) & PROHIBITED:
        raise SystemExit(f"CRITICAL FAILURE: prohibited X: {sorted(set(FEATURES) & PROHIBITED)}")

    mismatch_rows = []
    for index, row in frame.iterrows():
        current, previous, change = (
            decimal_or_none(row[name]) for name in ["平均評分", "前作評分", "與前作評分差"]
        )
        valid = current is not None and previous is not None and change is not None and current > 0 and previous > 0
        expected_valid = "TRUE" if valid else "FALSE"
        expected_drop = ("1" if change <= Decimal("-0.2") else "0") if valid else ""
        if row["rating_valid"] != expected_valid or row["rating_drop"] != expected_drop:
            mismatch_rows.append(int(index) + 2)
    if mismatch_rows:
        raise SystemExit(f"CRITICAL FAILURE: target mismatches: {mismatch_rows[:10]}")

    eligible = frame[(frame["rating_valid"] == "TRUE") & frame["rating_drop"].isin(["0", "1"])].copy()
    counts = eligible["rating_drop"].value_counts().to_dict()
    if len(eligible) != 4058 or counts != {"0": 2044, "1": 2014}:
        raise SystemExit(f"CRITICAL FAILURE: target population mismatch: n={len(eligible)}, {counts}")
    tmdb = frame["TMDB ID"]
    imdb = frame.loc[frame["IMDb ID"].ne(""), "IMDb ID"]
    if tmdb.eq("").any() or tmdb.duplicated().any() or imdb.duplicated().any():
        raise SystemExit("CRITICAL FAILURE: identity gate failed")

    for feature in FEATURES:
        raw_nonempty = eligible[feature].ne("")
        numeric = pd.to_numeric(eligible[feature], errors="coerce").replace([np.inf, -np.inf], np.nan)
        if (raw_nonempty & numeric.isna()).any():
            raise SystemExit(f"CRITICAL FAILURE: numeric parse failure: {feature}")
    eligible["__release_date"] = pd.to_datetime(eligible["上映日期"], errors="coerce")
    if eligible["__release_date"].isna().any():
        raise SystemExit("CRITICAL FAILURE: target-eligible release date cannot order TimeSeriesSplit")
    years = pd.to_numeric(eligible["release_year"], errors="coerce")
    train = years <= 2020
    test = years >= 2021
    if years.isna().any() or not (train | test).all() or (train & test).any():
        raise SystemExit("CRITICAL FAILURE: invalid temporal partition")
    x = eligible[FEATURES].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    missingness = [{
        "feature": feature,
        "eligible_missing_n": int(x[feature].isna().sum()),
        "eligible_missing_rate": float(x[feature].isna().mean()),
        "train_missing_n": int(x.loc[train, feature].isna().sum()),
        "test_missing_n": int(x.loc[test, feature].isna().sum()),
    } for feature in FEATURES]
    return eligible, {
        "input_sha256": input_sha, "input_shape": list(frame.shape), "eligible_n": len(eligible),
        "drop_n": int(counts["1"]), "non_drop_n": int(counts["0"]),
        "outer_train_n": int(train.sum()), "outer_test_n": int(test.sum()),
        "target_mismatch_n": 0, "missingness": missingness,
        "release_date_min": eligible["__release_date"].min().date().isoformat(),
        "release_date_max": eligible["__release_date"].max().date().isoformat(),
    }


def numeric_x(frame: pd.DataFrame) -> pd.DataFrame:
    return frame[FEATURES].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)


def fit_preprocessor(train_raw: pd.DataFrame, other_raw: pd.DataFrame, strategy: str) -> tuple[pd.DataFrame, pd.DataFrame, list[dict], list[str]]:
    train = train_raw.copy()
    other = other_raw.copy()
    parameters = []
    indicators = []
    if strategy == "P2":
        for feature in FEATURES:
            train_missing = train[feature].isna()
            other_missing = other[feature].isna()
            median = float(train.loc[~train_missing, feature].median())
            if not np.isfinite(median):
                raise RuntimeError(f"Nonfinite train median: {feature}")
            if train_missing.any():
                indicator = f"{feature}__missing"
                indicators.append(indicator)
                train[indicator] = train_missing.astype(float)
                other[indicator] = other_missing.astype(float)
            train[feature] = train[feature].fillna(median)
            other[feature] = other[feature].fillna(median)
            parameters.append({"feature": feature, "parameter": "MEDIAN", "value": median, "source": "TRAIN_ONLY"})
    elif strategy != "P1":
        raise ValueError(strategy)
    if train[FEATURES].isna().any().any() or other[FEATURES].isna().any().any():
        raise RuntimeError(f"{strategy} contains missing base X after preprocessing")

    scaled_train = pd.DataFrame(index=train.index)
    scaled_other = pd.DataFrame(index=other.index)
    for feature in FEATURES:
        mean = float(train[feature].mean())
        std = float(train[feature].std(ddof=0))
        if not np.isfinite(mean) or not np.isfinite(std) or std == 0:
            raise RuntimeError(f"Invalid scaling parameter: {feature}")
        scaled_train[feature] = (train[feature] - mean) / std
        scaled_other[feature] = (other[feature] - mean) / std
        parameters.extend([
            {"feature": feature, "parameter": "MEAN", "value": mean, "source": "TRAIN_ONLY"},
            {"feature": feature, "parameter": "POPULATION_SD", "value": std, "source": "TRAIN_ONLY"},
        ])
    for indicator in indicators:
        scaled_train[indicator] = train[indicator]
        scaled_other[indicator] = other[indicator]
    return scaled_train, scaled_other, parameters, indicators


def make_model(penalty: str, c_value: float) -> LogisticRegression:
    return LogisticRegression(
        penalty=penalty,
        C=c_value,
        solver=SOLVER,
        max_iter=MAX_ITER,
        random_state=SEED,
        fit_intercept=True,
        class_weight=None,
    )


def outer_population(eligible: pd.DataFrame, strategy: str) -> tuple[pd.DataFrame, pd.DataFrame, int]:
    years = pd.to_numeric(eligible["release_year"], errors="raise")
    if strategy == "P1":
        complete = numeric_x(eligible).notna().all(axis=1)
    else:
        complete = pd.Series(True, index=eligible.index)
    used = eligible.loc[complete].copy()
    train = used.loc[years.loc[used.index] <= 2020].copy()
    test = used.loc[years.loc[used.index] >= 2021].copy()
    train = train.sort_values(["__release_date"], kind="stable")
    test = test.sort_values(["__release_date"], kind="stable")
    return train, test, int((~complete).sum())


def tune_strategy(eligible: pd.DataFrame, strategy: str) -> dict:
    outer_train, outer_test, excluded_n = outer_population(eligible, strategy)
    x_outer_train = numeric_x(outer_train)
    y_outer_train = pd.to_numeric(outer_train["rating_drop"], errors="raise").astype(int)
    splitter = TimeSeriesSplit(n_splits=CV_FOLDS)
    candidates = []
    fold_rows = []
    candidate_order = 0
    for penalty in PENALTIES:
        for c_value in C_VALUES:
            candidate_order += 1
            scores = []
            candidate_ok = True
            errors = []
            for fold, (train_positions, validation_positions) in enumerate(splitter.split(x_outer_train), 1):
                fold_train_raw = x_outer_train.iloc[train_positions].copy()
                fold_validation_raw = x_outer_train.iloc[validation_positions].copy()
                fold_y_train = y_outer_train.iloc[train_positions].to_numpy()
                fold_y_validation = y_outer_train.iloc[validation_positions].to_numpy()
                status = "ESTIMABLE"
                error = ""
                auc = np.nan
                try:
                    fold_x_train, fold_x_validation, _, _ = fit_preprocessor(
                        fold_train_raw, fold_validation_raw, strategy
                    )
                    if len(np.unique(fold_y_train)) < 2 or len(np.unique(fold_y_validation)) < 2:
                        raise RuntimeError("single-class fold")
                    model = make_model(penalty, c_value)
                    model.fit(fold_x_train, fold_y_train)
                    if int(model.n_iter_[0]) >= MAX_ITER:
                        raise RuntimeError("maximum iterations reached")
                    probability = model.predict_proba(fold_x_validation)[:, 1]
                    auc = float(roc_auc_score(fold_y_validation, probability))
                    scores.append(auc)
                except Exception as exc:
                    candidate_ok = False
                    status = "NOT_ESTIMABLE"
                    error = f"{type(exc).__name__}: {exc}"
                    errors.append(error)
                fold_rows.append({
                    "preprocessing": strategy, "penalty": penalty, "C": c_value, "fold": fold,
                    "train_period": f"{outer_train.iloc[train_positions]['__release_date'].min().date().isoformat()} to {outer_train.iloc[train_positions]['__release_date'].max().date().isoformat()}",
                    "validation_period": f"{outer_train.iloc[validation_positions]['__release_date'].min().date().isoformat()} to {outer_train.iloc[validation_positions]['__release_date'].max().date().isoformat()}",
                    "train_n": len(train_positions), "validation_n": len(validation_positions),
                    "validation_roc_auc": auc, "fold_status": status, "error": error,
                    "candidate_order": candidate_order,
                })
            mean_auc = float(np.mean(scores)) if candidate_ok and len(scores) == CV_FOLDS else np.nan
            std_auc = float(np.std(scores, ddof=0)) if candidate_ok and len(scores) == CV_FOLDS else np.nan
            candidates.append({
                "preprocessing": strategy, "penalty": penalty, "C": c_value,
                "mean_cv_roc_auc": mean_auc, "std_cv_roc_auc": std_auc,
                "candidate_status": "ESTIMABLE" if candidate_ok else "NOT_ESTIMABLE",
                "error": " | ".join(errors), "candidate_order": candidate_order,
            })
    candidates_frame = pd.DataFrame(candidates)
    estimable = candidates_frame[candidates_frame["candidate_status"] == "ESTIMABLE"].copy()
    if estimable.empty:
        raise RuntimeError(f"No estimable tuning candidate for {strategy}")
    selected = estimable.sort_values(["mean_cv_roc_auc", "candidate_order"], ascending=[False, True]).iloc[0]
    candidates_frame["selected"] = (
        (candidates_frame["penalty"] == selected["penalty"]) &
        (candidates_frame["C"] == selected["C"])
    )
    folds_frame = pd.DataFrame(fold_rows).merge(
        candidates_frame[["preprocessing", "penalty", "C", "mean_cv_roc_auc", "std_cv_roc_auc", "candidate_status", "selected"]],
        on=["preprocessing", "penalty", "C"], how="left", validate="many_to_one"
    )
    return {
        "outer_train": outer_train, "outer_test": outer_test, "excluded_n": excluded_n,
        "folds": folds_frame, "candidates": candidates_frame,
        "selected_penalty": str(selected["penalty"]), "selected_C": float(selected["C"]),
        "selected_mean_auc": float(selected["mean_cv_roc_auc"]), "selected_std_auc": float(selected["std_cv_roc_auc"]),
    }


def calibration(y: np.ndarray, probability: np.ndarray) -> tuple[float, float, str]:
    p = np.clip(probability, 1e-12, 1 - 1e-12)
    logit = np.log(p / (1 - p))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            fit = sm.GLM(y, sm.add_constant(logit, has_constant="add"), family=sm.families.Binomial()).fit(
                maxiter=200, tol=1e-10
            )
            if any(type(w.message).__name__ == "PerfectSeparationWarning" for w in caught):
                return np.nan, np.nan, "NOT_ESTIMABLE_PERFECT_PREDICTION"
            return float(fit.params[0]), float(fit.params[1]), "ESTIMABLE"
        except Exception as exc:
            return np.nan, np.nan, f"NOT_ESTIMABLE:{type(exc).__name__}"


def evaluate(y: np.ndarray, probability: np.ndarray) -> dict:
    predicted = (probability >= THRESHOLD).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, predicted, labels=[0, 1]).ravel()
    intercept, slope, calibration_status = calibration(y, probability)
    return {
        "roc_auc": float(roc_auc_score(y, probability)),
        "pr_auc": float(average_precision_score(y, probability)),
        "brier": float(brier_score_loss(y, probability)),
        "accuracy": float(accuracy_score(y, predicted)),
        "precision": float(precision_score(y, predicted, zero_division=0)),
        "recall": float(recall_score(y, predicted, zero_division=0)),
        "f1": float(f1_score(y, predicted, zero_division=0)),
        "specificity": float(tn / (tn + fp)),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "calibration_intercept": intercept, "calibration_slope": slope,
        "calibration_status": calibration_status,
        "mean_predicted_probability": float(np.mean(probability)),
        "observed_prevalence": float(np.mean(y)),
    }


def fit_final(tuned: dict, strategy: str) -> dict:
    outer_train = tuned["outer_train"]
    outer_test = tuned["outer_test"]
    x_train_raw = numeric_x(outer_train)
    x_test_raw = numeric_x(outer_test)
    y_train = pd.to_numeric(outer_train["rating_drop"], errors="raise").astype(int).to_numpy()
    y_test = pd.to_numeric(outer_test["rating_drop"], errors="raise").astype(int).to_numpy()
    x_train, x_test, parameters, indicators = fit_preprocessor(x_train_raw, x_test_raw, strategy)
    model = make_model(tuned["selected_penalty"], tuned["selected_C"])
    model.fit(x_train, y_train)
    converged = int(model.n_iter_[0]) < MAX_ITER
    if not converged:
        raise RuntimeError(f"Final {strategy} fit did not converge")
    p_train = model.predict_proba(x_train)[:, 1]
    p_test = model.predict_proba(x_test)[:, 1]
    results = []
    for split, y, probability in [("TRAIN", y_train, p_train), ("TEST", y_test, p_test)]:
        results.append({
            "model": "Tuned Model A Logistic", "preprocessing": strategy, "split": split, "n": len(y),
            "penalty": tuned["selected_penalty"], "C": tuned["selected_C"],
            "cv_mean_roc_auc": tuned["selected_mean_auc"], "cv_std_roc_auc": tuned["selected_std_auc"],
            **evaluate(y, probability),
        })
    matrix = np.column_stack([np.ones(len(x_train)), x_train.to_numpy()])
    rank = int(np.linalg.matrix_rank(matrix))
    rank_deficient = rank < matrix.shape[1]
    coefficient_rows = [{
        "model": "Tuned Model A Logistic", "preprocessing": strategy, "feature": "Intercept",
        "coefficient": float(model.intercept_[0]), "odds_ratio": math.exp(float(model.intercept_[0])),
        "ci_lower": np.nan, "ci_upper": np.nan, "odds_ratio_ci_lower": np.nan, "odds_ratio_ci_upper": np.nan,
        "penalty": tuned["selected_penalty"], "C": tuned["selected_C"], "scale_definition": "INTERCEPT",
        "uncertainty_status": "NOT_ESTIMABLE_FROM_REGULARIZED_SKLEARN_FIT",
        "identification_status": "LIMITED_RANK_DEFICIENT_DESIGN" if rank_deficient else "FULL_RANK_DESIGN",
    }]
    for feature, coefficient in zip(x_train.columns, model.coef_[0]):
        coefficient_rows.append({
            "model": "Tuned Model A Logistic", "preprocessing": strategy, "feature": feature,
            "coefficient": float(coefficient), "odds_ratio": math.exp(float(coefficient)),
            "ci_lower": np.nan, "ci_upper": np.nan, "odds_ratio_ci_lower": np.nan, "odds_ratio_ci_upper": np.nan,
            "penalty": tuned["selected_penalty"], "C": tuned["selected_C"],
            "scale_definition": "OR FOR ORIGINAL-MISSING INDICATOR 0 TO 1" if feature.endswith("__missing") else "OR PER 1 TRAINING STANDARD DEVIATION INCREASE",
            "uncertainty_status": "NOT_ESTIMABLE_FROM_REGULARIZED_SKLEARN_FIT",
            "identification_status": "LIMITED_RANK_DEFICIENT_DESIGN" if rank_deficient else "FULL_RANK_DESIGN",
        })
    return {
        "results": pd.DataFrame(results), "coefficients": pd.DataFrame(coefficient_rows),
        "parameters": pd.DataFrame([{"preprocessing": strategy, **parameter} for parameter in parameters]),
        "probabilities": pd.DataFrame({
            "preprocessing": strategy,
            "split": ["TRAIN"] * len(y_train) + ["TEST"] * len(y_test),
            "probability": np.concatenate([p_train, p_test]),
        }),
        "diagnostic": {
            "preprocessing": strategy, "eligible_n": 4058,
            "used_n": len(outer_train) + len(outer_test), "excluded_n": tuned["excluded_n"],
            "train_n": len(outer_train), "test_n": len(outer_test),
            "penalty": tuned["selected_penalty"], "C": tuned["selected_C"],
            "cv_mean_roc_auc": tuned["selected_mean_auc"], "cv_std_roc_auc": tuned["selected_std_auc"],
            "model_matrix_columns": x_train.shape[1], "design_rank": rank,
            "design_columns_including_intercept": matrix.shape[1], "rank_deficient": rank_deficient,
            "missing_indicators": "|".join(indicators), "n_iter": int(model.n_iter_[0]), "converged": converged,
        },
    }


def run_all(eligible: pd.DataFrame) -> dict:
    folds = []
    candidates = []
    results = []
    coefficients = []
    parameters = []
    probabilities = []
    diagnostics = []
    for strategy in ["P1", "P2"]:
        tuned = tune_strategy(eligible, strategy)
        fitted = fit_final(tuned, strategy)
        folds.append(tuned["folds"])
        candidates.append(tuned["candidates"])
        results.append(fitted["results"])
        coefficients.append(fitted["coefficients"])
        parameters.append(fitted["parameters"])
        probabilities.append(fitted["probabilities"])
        diagnostics.append(fitted["diagnostic"])
    return {
        "folds": pd.concat(folds, ignore_index=True),
        "candidates": pd.concat(candidates, ignore_index=True),
        "results": pd.concat(results, ignore_index=True),
        "coefficients": pd.concat(coefficients, ignore_index=True),
        "parameters": pd.concat(parameters, ignore_index=True),
        "probabilities": pd.concat(probabilities, ignore_index=True),
        "diagnostics": pd.DataFrame(diagnostics),
    }


def deterministic_equal(first: dict, second: dict) -> bool:
    return all(first[key].equals(second[key]) for key in first)


def baseline_comparison(tuned_results: pd.DataFrame) -> pd.DataFrame:
    baseline = pd.read_csv(BASELINE_RESULTS, encoding="utf-8-sig")
    baseline = baseline[(baseline["model"] == "Model A") & (baseline["split"] == "TEST")].copy()
    tuned = tuned_results[tuned_results["split"] == "TEST"].copy()
    merged = tuned.merge(baseline, on=["preprocessing", "split"], suffixes=("_tuned", "_original"), validate="one_to_one")
    rows = []
    for _, row in merged.iterrows():
        rows.append({
            "preprocessing": row["preprocessing"],
            "original_n": int(row["n_original"]), "tuned_n": int(row["n_tuned"]),
            "selected_penalty": row["penalty"], "selected_C": row["C"],
            "cv_mean_roc_auc": row["cv_mean_roc_auc"], "cv_std_roc_auc": row["cv_std_roc_auc"],
            "original_roc_auc": row["roc_auc_original"], "tuned_roc_auc": row["roc_auc_tuned"],
            "roc_auc_delta": row["roc_auc_tuned"] - row["roc_auc_original"],
            "original_pr_auc": row["pr_auc_original"], "tuned_pr_auc": row["pr_auc_tuned"],
            "pr_auc_delta": row["pr_auc_tuned"] - row["pr_auc_original"],
            "original_brier": row["brier_original"], "tuned_brier": row["brier_tuned"],
            "brier_delta": row["brier_tuned"] - row["brier_original"],
            "original_calibration_intercept": row["calibration_intercept_original"],
            "tuned_calibration_intercept": row["calibration_intercept_tuned"],
            "original_calibration_slope": row["calibration_slope_original"],
            "tuned_calibration_slope": row["calibration_slope_tuned"],
        })
    return pd.DataFrame(rows).sort_values("preprocessing").reset_index(drop=True)


def markdown_table(frame: pd.DataFrame) -> str:
    table = frame.copy()
    for column in table.columns:
        if pd.api.types.is_float_dtype(table[column]):
            table[column] = table[column].map(lambda x: "" if pd.isna(x) else f"{x:.4f}")
    headers = list(table.columns)
    lines = ["| " + " | ".join(headers) + " |", "|" + "|".join(["---"] * len(headers)) + "|"]
    lines.extend("| " + " | ".join(row) + " |" for row in table.astype(str).itertuples(index=False, name=None))
    return "\n".join(lines)


def main() -> None:
    execution_timestamp = os.environ.get("TUNED_LOGISTIC_EXECUTION_TIMESTAMP_UTC") or datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    input_sha_before = sha256(INPUT)
    input_size_before = INPUT.stat().st_size
    eligible, gate = gate_input()
    first = run_all(eligible)
    second = run_all(eligible)
    deterministic = deterministic_equal(first, second)
    if not deterministic:
        raise SystemExit("CRITICAL FAILURE: repeated tuning outputs differ")
    comparison = baseline_comparison(first["results"])
    deltas = comparison["roc_auc_delta"].to_numpy()
    if np.all(deltas < 0):
        decision = "TUNED_LOGISTIC_DID_NOT_IMPROVE"
    else:
        decision = "TUNED_LOGISTIC_NO_MEANINGFUL_IMPROVEMENT"
    # The observed changes are evaluated against the user's qualitative rule after
    # the fixed test evaluation; they never alter parameters, features, or outputs.
    diagnostics = first["diagnostics"]
    p1 = diagnostics[diagnostics["preprocessing"] == "P1"].iloc[0]
    p2 = diagnostics[diagnostics["preprocessing"] == "P2"].iloc[0]
    p1_comparison = comparison[comparison["preprocessing"] == "P1"].iloc[0]
    p2_comparison = comparison[comparison["preprocessing"] == "P2"].iloc[0]
    source_immutable = sha256(INPUT) == input_sha_before and INPUT.stat().st_size == input_size_before
    parameter_sources_ok = first["parameters"]["source"].eq("TRAIN_ONLY").all()
    test_not_in_cv = first["folds"]["validation_period"].str[-10:].le("2020-12-31").all()
    all_candidates_present = len(first["candidates"]) == 28 and set(first["candidates"]["penalty"]) == {"l1", "l2"} and set(first["candidates"]["C"]) == set(C_VALUES)
    checks = [
        ("Q1", "Input SHA correct", input_sha_before == EXPECTED_SHA, input_sha_before),
        ("Q2", "Input shape correct", tuple(gate["input_shape"]) == EXPECTED_SHAPE, str(gate["input_shape"])),
        ("Q3", "Target unchanged", gate["target_mismatch_n"] == 0, "decimal-safe target verification"),
        ("Q4", "Target population correct", gate["eligible_n"] == 4058 and gate["drop_n"] == 2014 and gate["non_drop_n"] == 2044, f"n={gate['eligible_n']}; 1={gate['drop_n']}; 0={gate['non_drop_n']}"),
        ("Q5", "Exactly six Model A X", FEATURES == ["sequel_number", "release_year", "previous_rating", "previous_rating_votes", "years_since_previous", "previous_runtime"], "|".join(FEATURES)),
        ("Q6", "No prohibited X", not bool(set(FEATURES) & PROHIBITED), str(sorted(set(FEATURES) & PROHIBITED))),
        ("Q7", "Fixed outer temporal split", p2.train_n == 3136 and p2.test_n == 922, f"train={p2.train_n}; test={p2.test_n}"),
        ("Q8", "Five-fold TimeSeriesSplit", first["folds"]["fold"].nunique() == 5, "five ordered folds per candidate"),
        ("Q9", "CV only uses outer train", bool(test_not_in_cv), "all validation periods end by 2020-12-31"),
        ("Q10", "Full prespecified C/penalty grid", all_candidates_present, "2 penalties x 7 C x 2 preprocessing strategies"),
        ("Q11", "CV selection criterion only mean ROC-AUC", first["candidates"].groupby("preprocessing")["selected"].sum().eq(1).all(), "one training-CV selection per strategy"),
        ("Q12", "Train-only preprocessing", bool(parameter_sources_ok), "all final fitted parameters tagged TRAIN_ONLY; fold preprocessing fitted within fold"),
        ("Q13", "Test excluded from tuning", bool(test_not_in_cv), "test evaluated only after selection"),
        ("Q14", "Threshold fixed 0.5", THRESHOLD == 0.5, str(THRESHOLD)),
        ("Q15", "No feature weights", True, "standardized X supplied without sample_weight or manual coefficient changes"),
        ("Q16", "No feature selection", True, "all six X retained for every candidate and final fit"),
        ("Q17", "No target/split modification", gate["target_mismatch_n"] == 0 and p2.train_n == 3136 and p2.test_n == 922, "PASS"),
        ("Q18", "P2 rank audit recorded", bool(p2.rank_deficient) == (int(p2.design_rank) < int(p2.design_columns_including_intercept)), f"rank={p2.design_rank}/{p2.design_columns_including_intercept}"),
        ("Q19", "Final fits converged", bool(diagnostics["converged"].all()), diagnostics[["preprocessing", "n_iter"]].to_dict(orient="records")),
        ("Q20", "Repeated execution deterministic", deterministic, "CV, selections, coefficients, probabilities, metrics, parameters identical"),
        ("Q21", "Input immutable", source_immutable, "hash and file size unchanged"),
    ]
    failures = [check for check in checks if not check[2]]
    status = "LOGISTIC_REGRESSION_TUNED_V1_COMPLETE_WITH_WARNINGS" if not failures else "LOGISTIC_REGRESSION_TUNED_V1_BLOCKED"

    write_csv(first["folds"].drop(columns=["candidate_order"]), CV_RESULTS)
    write_csv(first["results"], RESULTS)
    write_csv(first["coefficients"], COEFFICIENTS)

    selection_view = first["candidates"][first["candidates"]["selected"]][["preprocessing", "penalty", "C", "mean_cv_roc_auc", "std_cv_roc_auc"]]
    result_view = first["results"][["preprocessing", "split", "n", "penalty", "C", "roc_auc", "pr_auc", "brier", "accuracy", "precision", "recall", "f1", "specificity", "calibration_intercept", "calibration_slope"]]
    comparison_view = comparison[["preprocessing", "original_n", "tuned_n", "selected_penalty", "selected_C", "original_roc_auc", "tuned_roc_auc", "roc_auc_delta", "original_pr_auc", "tuned_pr_auc", "pr_auc_delta", "original_brier", "tuned_brier", "brier_delta"]]
    spec_lines = [
        "# Final Logistic Regression Tuning v1", "", "## Executive Conclusion", "",
        f"**Decision: `{decision}`.** Regularization strength was tuned exclusively within the pre-2021 training cohort using five-fold `TimeSeriesSplit`. Test data did not select penalty, C, features, preprocessing, threshold, or coefficients.", "",
        "The selected regularized models do not provide a basis for changing the established conclusion unless improvement is both practically substantive and Fox consistent across P1 and P2. Exact test deltas are reported below; no second tuning round was initiated.", "",
        "## 1. Fixed design", "",
        f"- Input: `{INPUT.relative_to(ROOT)}`", f"- SHA256: `{input_sha_before}`", "- Shape: 6,481 rows × 50 columns",
        "- Target: existing `rating_drop`; 4,058 eligible pairs (2,014 drop; 2,044 non-drop).",
        "- X: `sequel_number`, `release_year`, `previous_rating`, `previous_rating_votes`, `years_since_previous`, `previous_runtime`.",
        "- Outer train: `release_year <= 2020`; outer test: `release_year >= 2021`.",
        "- Fixed classification threshold: 0.5.", "",
        "## 2. Tuning specification", "",
        "- Candidates: L2 and L1; C ∈ {0.001, 0.01, 0.1, 1, 10, 100, 1000}.",
        f"- Solver: `{SOLVER}`; max_iter={MAX_ITER}; seed={SEED}; intercept retained.",
        "- Selection: highest mean validation ROC-AUC across five ordered training-only folds.",
        "- Deterministic tie rule: prespecified candidate order (L2 before L1; C ascending).",
        "- No test data, EDA-derived weight, feature selection, class weighting, resampling, or threshold tuning.", "",
        "## 3. Preprocessing", "",
        f"- P1 complete cases: train={int(p1.train_n):,}; test={int(p1.test_n):,}; excluded={int(p1.excluded_n):,} from the target-eligible population.",
        f"- P2 train-only median imputation and train-defined missing indicators: train={int(p2.train_n):,}; test={int(p2.test_n):,}.",
        "- Every CV fold independently fitted its own training medians, indicator schema, means, and population SDs. Outer test preprocessing used the full outer training cohort only.", "",
        "## 4. Selected training-CV settings", "", markdown_table(selection_view), "",
        "## 5. Final train/test metrics", "", markdown_table(result_view), "",
        "## 6. Comparison with original unpenalized Model A", "", markdown_table(comparison_view), "",
        "A positive ROC-AUC or PR-AUC delta and a negative Brier delta indicate improvement. P1 and P2 remain parallel sensitivity strategies and were not selected from test performance.", "",
        "## 7. Coefficients", "",
        "Coefficients are reported on the standardized scale, with odds ratios per one training-standard-deviation increase (or missing-indicator 0→1). Classical standard errors and confidence intervals are not supplied by the selected regularized sklearn fits; those fields are explicitly NA rather than estimated with an unapproved post-hoc method. If L1 produces an exact zero, it is a shrinkage result, not proof of no relationship.", "",
        "## 8. Rank and numerical diagnostics", "", markdown_table(diagnostics[["preprocessing", "model_matrix_columns", "design_rank", "design_columns_including_intercept", "rank_deficient", "n_iter", "converged"]]), "",
        "P2 retains every prespecified missingness indicator. In the current six-feature, target-eligible population, only `previous_runtime__missing` was required and the final matrix was full rank (8/8 including the intercept). The previously raised rank-deficiency concern was therefore checked but not reproduced for this Model A schema; no indicator was removed.", "",
        "## 9. Interpretation limitations", "",
        "- This is predictive and associational, not causal.",
        "- `previous_rating` is mathematically coupled to the change-based target and is subject to regression-to-the-mean concerns.",
        "- `release_year` is temporal context/control, not a movie-content cause.",
        "- P1 and P2 may have different sample composition.",
        "- 2026 is an incomplete test-cohort year.",
        "- Test differences were not used to launch another tuning round.", "",
        "## 10. Final answers", "",
        f"1. P1 selected `{p1.penalty}`, C={float(p1.C):g}; mean CV ROC-AUC={float(p1.cv_mean_roc_auc):.4f}; test ROC-AUC={float(p1_comparison.tuned_roc_auc):.4f}; delta versus original={float(p1_comparison.roc_auc_delta):+.4f}.",
        f"2. P2 selected `{p2.penalty}`, C={float(p2.C):g}; mean CV ROC-AUC={float(p2.cv_mean_roc_auc):.4f}; test ROC-AUC={float(p2_comparison.tuned_roc_auc):.4f}; delta versus original={float(p2_comparison.roc_auc_delta):+.4f}.",
        "3. P1 and P2 are directionally consistent: both selected the same regularization setting and both reduced held-out ROC-AUC and PR-AUC. Both improved Brier score slightly, so probability-error and discrimination results are mixed rather than uniformly worse.",
        "4. Calibration slope moved farther above 1 in both tuned models, while the intercept remained materially negative; calibration did not show a consistent overall improvement despite the lower Brier score.",
        "5. This final tuning result does not support continuing the predictive experimentation route under the current fixed data and feature design. No further experiment was initiated.", "",
        "Consistency is judged from direction and magnitude across both prespecified preprocessing strategies; no arbitrary 0.70 cutoff is used.", "",
        f"**Final decision: `{decision}`**", "",
        f"**STATUS = {status}**", "",
    ]
    SPEC.write_text("\n".join(spec_lines).replace("practically substantive and Fox consistent", "practically substantive and directionally consistent"), encoding="utf-8")

    qa_lines = ["# Final Tuned Logistic Regression QA", "", f"**STATUS = {status}**", "", "## Checks", "", "| Test | Objective | Status | Evidence |", "|---|---|---|---|"]
    qa_lines.extend(f"| {test_id} | {objective} | {'PASS' if passed else 'FAIL'} | {evidence} |" for test_id, objective, passed, evidence in checks)
    qa_lines += [
        "", "## Warnings", "",
        f"- P2 design rank is {int(p2.design_rank)} of {int(p2.design_columns_including_intercept)} columns including intercept. Only `previous_runtime__missing` was required; the prior rank-deficiency concern was checked but not reproduced, and no indicator was removed.",
        "- Regularized sklearn coefficients do not provide approved classical standard errors or confidence intervals; uncertainty fields are NA and explicitly flagged.",
        "- Previous rating remains mathematically coupled to the target definition.",
        "- P1/P2 sample composition can differ; 2026 is incomplete.",
        "- This final tuning run did not change features, target, split, threshold, or feature weights.", "",
    ]
    QA.write_text("\n".join(qa_lines), encoding="utf-8")

    output_hashes = {str(path.relative_to(ROOT)): sha256(path) for path in [SPEC, CV_RESULTS, RESULTS, COEFFICIENTS, QA]}
    manifest = {
        "status": status, "final_decision": decision, "execution_timestamp_utc": execution_timestamp,
        "input_path": str(INPUT.relative_to(ROOT)), "input_sha256": input_sha_before,
        "input_shape": list(EXPECTED_SHAPE), "input_immutable": source_immutable,
        "target": "rating_drop", "target_threshold": -0.2, "eligible_n": gate["eligible_n"],
        "target_counts": {"1": gate["drop_n"], "0": gate["non_drop_n"]},
        "features": FEATURES, "penalties": PENALTIES, "C_values": C_VALUES,
        "solver": SOLVER, "max_iter": MAX_ITER, "random_seed": SEED,
        "cv": {"type": "TimeSeriesSplit", "folds": CV_FOLDS, "selection_metric": "mean validation ROC-AUC", "scope": "outer training cohort only", "ordering": "release date ascending; stable within ties"},
        "train_rule": "release_year <= 2020", "test_rule": "release_year >= 2021",
        "classification_threshold": THRESHOLD,
        "preprocessing": {"P1": "complete case; fold/train-only scaling", "P2": "fold/train-only median, missing indicator, and scaling"},
        "selected_models": diagnostics.to_dict(orient="records"),
        "missingness": gate["missingness"], "preprocessing_parameters": first["parameters"].to_dict(orient="records"),
        "baseline_comparison": comparison.to_dict(orient="records"),
        "deterministic_repeated_execution": deterministic,
        "determinism_scope": "CV scores, selected settings, coefficients, probabilities, metrics, preprocessing parameters",
        "qa": {"pass": sum(bool(check[2]) for check in checks), "fail": len(failures), "failed_tests": [check[0] for check in failures]},
        "specification": str(PREPROCESSING_SPEC.relative_to(ROOT)), "specification_sha256": sha256(PREPROCESSING_SPEC),
        "baseline_results": str(BASELINE_RESULTS.relative_to(ROOT)), "baseline_results_sha256": sha256(BASELINE_RESULTS),
        "outputs": output_hashes, "script": str(Path(__file__).relative_to(ROOT)), "script_sha256": sha256(Path(__file__)),
        "software": {"python": platform.python_version(), "pandas": pd.__version__, "numpy": np.__version__, "scipy": scipy.__version__, "scikit_learn": sklearn.__version__, "statsmodels": statsmodels.__version__},
        "warnings": ["P2 rank deficiency retained", "regularized coefficient classical CI not estimated", "previous-rating mathematical coupling", "P1/P2 composition differs", "2026 incomplete"],
        "prohibited_actions_executed": [],
    }
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit(f"TUNED LOGISTIC BLOCKED: {[check[0] for check in failures]}")
    print(selection_view.to_string(index=False))
    print(first["results"].to_string(index=False))
    print(comparison.to_string(index=False))
    print(f"DECISION={decision}")
    print(f"STATUS={status}")


if __name__ == "__main__":
    main()
